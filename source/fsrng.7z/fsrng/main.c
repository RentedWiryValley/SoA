#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "hash.h"
#include "random.h"
#include "utils.h"

void DisplayUsage(const char* path)
{
  char* file = strrchr(path, '/');
  if (file)
    ++file;
  else
    file = "fsrng";
  printf("Usage 1: %s\n", file);
  printf("Usage 2: %s <NumBytes>\n", file);
  printf("Usage 3: %s <NumBytes> <NumFiles>\n", file);
  printf("Usage 4: %s <NumBytes> <NumFiles> 0\n", file);
  printf("* NumBytes and NumFiles must be positive numbers.\n");
}

void GenerateRandomNumbers(uint8_t* buffer, int size, const char* filename)
{
  SoftwareRandomBuffer(buffer, size);
  FILE* fp = fopen(filename, "wb");
  VERIFY2(fp, "Failed to open output file", filename);
  int write = fwrite(buffer, 1, size, fp);
  VERIFY2(write == size, "Error writing output file", filename);
  fclose(fp);
}

int main(int argc, char* argv[])
{
  printf("Finite-State Random Number Generator\n");

  int size = 0;
  int count = 0;
  BOOL leadingzero = FALSE;

  if (argc == 1)
  {
    size = EnterPositiveInteger("Enter number of bytes:");
    count = EnterPositiveInteger("Enter number of files:");
    char text[256];
    EnterText("Add leading zeros (0 = yes):", text, 256);
    leadingzero = text[0] == '0';
  }
  else if (argc == 2)
  {
    size = atoi(argv[1]);
    count = 1;
  }
  else if (argc == 3)
  {
    size = atoi(argv[1]);
    count = atoi(argv[2]);
  }
  else if (argc == 4)
  {
    size = atoi(argv[1]);
    count = atoi(argv[2]);
    leadingzero = argv[3][0] == '0';
  }

  if (size <= 0 || count <= 0)
  {
    DisplayUsage(argv[0]);
    return -1;
  }

  char format[256];
  if (leadingzero)
  {
    int numdigits = log10(count) + 1;
    sprintf(format, "%%0%dd", numdigits);
  }
  else
  {
    sprintf(format, "%%d");
  }

  uint8_t* buffer = malloc(size);

  char filename[256];
  char first[256];
  for (int i = 0; i < count; ++i)
  {
    char str[256];
    sprintf(str, "Generating %d random numbers in file #%d (of %d)...", size,
            i + 1, count);
    printf("\33[2K\r%s", str);
    fflush(stdout);
    sprintf(filename, format, i + 1);
    if (i == 0)
      strcpy(first, filename);
    GenerateRandomNumbers(buffer, size, filename);
  }

  printf(" Done.\n");

  if (count == 1)
  {
    printf("Random numbers saved in file named %s.\n", first);
    int len = size > 256 ? 256 : size;
    for (int i = 0; i < len; ++i)
      printf("%02x", buffer[i]);
    if (size > len)
      printf("...");
    printf("\n");
  }
  else
  {
    printf("Random numbers saved in files named %s ~ %s.\n", first, filename);
  }

  free(buffer);

  return 0;
}
