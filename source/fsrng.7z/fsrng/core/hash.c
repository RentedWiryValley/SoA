#include <string.h>

#include "hash.h"

#include "common.h"
#include "defines.h"

#include "hash/Whirlpool.h"
#include "hash/blake2.h"
#include "hash/blake3.h"
#include "hash/sha.h"
#include "hash/sha3.h"
#include "hash/siphash.h"
#include "hash/skein.h"

//// Regular hash

// for extended hash algos
const uint8_t ExtendKey1[] = {0x12};
const uint8_t ExtendKey2[] = {0xCD, 0xEF};

// Regular: 128-bit

const HashAlgo Siphash128Hasher = {.OutputSize = Bytes128Bits,
                                   .InitFunc = NULL,
                                   .UpdateFunc = NULL,
                                   .FinalFunc = NULL,
                                   .HashFunc = Siphash_128,
                                   .Name = "Siphash-128"};
void Siphash_128(const uint8_t* input, int input_len, uint8_t* output)
{
  uint8_t key[16];
  ClearMemory(key, sizeof(key));
  siphash(input, input_len, key, output, Siphash128Hasher.OutputSize);
}

// Regular: 256-bit

const HashAlgo Blake2b256Hasher = {.OutputSize = Bytes256Bits,
                                   .InitFunc = Blake2b_256_Init,
                                   .UpdateFunc = Blake2b_256_Update,
                                   .FinalFunc = Blake2b_256_Final,
                                   .HashFunc = Blake2b_256,
                                   .Name = "Blake2b-256"};
static blake2b_state Blake2b_256_Ctx = {0};
void Blake2b_256_Init(void)
{
  VERIFY(blake2b_init(&Blake2b_256_Ctx, Blake2b256Hasher.OutputSize) == 0,
         "Blake2b_256_Init()");
}
void Blake2b_256_Update(const uint8_t* input, int input_len)
{
  VERIFY(blake2b_update(&Blake2b_256_Ctx, input, input_len) == 0,
         "Blake2b_256_Update()");
}
void Blake2b_256_Final(uint8_t* output)
{
  VERIFY(
    blake2b_final(&Blake2b_256_Ctx, output, Blake2b256Hasher.OutputSize) == 0,
    "Blake2b_256_Final()");
}
void Blake2b_256(const uint8_t* input, int input_len, uint8_t* output)
{
  VERIFY(blake2b(output, Blake2b256Hasher.OutputSize, input, input_len, NULL,
                 0) == 0,
         "Blake2b_256()");
}

const HashAlgo Blake2s256Hasher = {.OutputSize = Bytes256Bits,
                                   .InitFunc = Blake2s_256_Init,
                                   .UpdateFunc = Blake2s_256_Update,
                                   .FinalFunc = Blake2s_256_Final,
                                   .HashFunc = Blake2s_256,
                                   .Name = "Blake2s-256"};
static blake2s_state Blake2s_256_Ctx = {0};
void Blake2s_256_Init(void)
{
  VERIFY(blake2s_init(&Blake2s_256_Ctx, Blake2s256Hasher.OutputSize) == 0,
         "Blake2s_256_Init()");
}
void Blake2s_256_Update(const uint8_t* input, int input_len)
{
  VERIFY(blake2s_update(&Blake2s_256_Ctx, input, input_len) == 0,
         "Blake2s_256_Update()");
}
void Blake2s_256_Final(uint8_t* output)
{
  VERIFY(
    blake2s_final(&Blake2s_256_Ctx, output, Blake2s256Hasher.OutputSize) == 0,
    "Blake2s_256_Final()");
}
void Blake2s_256(const uint8_t* input, int input_len, uint8_t* output)
{
  VERIFY(blake2s(output, Blake2s256Hasher.OutputSize, input, input_len, NULL,
                 0) == 0,
         "Blake2s_256()");
}

const HashAlgo Blake3_256Hasher = {.OutputSize = Bytes256Bits,
                                   .InitFunc = Blake3_256_Init,
                                   .UpdateFunc = Blake3_256_Update,
                                   .FinalFunc = Blake3_256_Final,
                                   .HashFunc = Blake3_256,
                                   .Name = "Blake3-256"};
static blake3_hasher Blake3_256_Ctx = {0};
void Blake3_256_Init(void)
{
  blake3_hasher_init(&Blake3_256_Ctx);
}
void Blake3_256_Update(const uint8_t* input, int input_len)
{
  blake3_hasher_update(&Blake3_256_Ctx, input, input_len);
}
void Blake3_256_Final(uint8_t* output)
{
  blake3_hasher_finalize(&Blake3_256_Ctx, output, Blake3_256Hasher.OutputSize);
}
void Blake3_256(const uint8_t* input, int input_len, uint8_t* output)
{
  blake3_hasher ctx = {0};
  blake3_hasher_init(&ctx);
  blake3_hasher_update(&ctx, input, input_len);
  blake3_hasher_finalize(&ctx, output, Blake3_256Hasher.OutputSize);
}

const HashAlgo Sha2_256Hasher = {.OutputSize = Bytes256Bits,
                                 .InitFunc = Sha2_256_Init,
                                 .UpdateFunc = Sha2_256_Update,
                                 .FinalFunc = Sha2_256_Final,
                                 .HashFunc = Sha2_256,
                                 .Name = "SHA2-256"};
static SHA256Context Sha2_256_Ctx = {0};
void Sha2_256_Init(void)
{
  SHA256Reset(&Sha2_256_Ctx);
}
void Sha2_256_Update(const uint8_t* input, int input_len)
{
  SHA256Input(&Sha2_256_Ctx, input, input_len);
}
void Sha2_256_Final(uint8_t* output)
{
  SHA256Result(&Sha2_256_Ctx, output);
}
void Sha2_256(const uint8_t* input, int input_len, uint8_t* output)
{
  SHA256Context ctx = {0};
  SHA256Reset(&ctx);
  SHA256Input(&ctx, input, input_len);
  SHA256Result(&ctx, output);
}

const HashAlgo Sha3_256Hasher = {.OutputSize = Bytes256Bits,
                                 .InitFunc = Sha3_256_Init,
                                 .UpdateFunc = Sha3_256_Update,
                                 .FinalFunc = Sha3_256_Final,
                                 .HashFunc = Sha3_256,
                                 .Name = "SHA3-256"};
static sha3_ctx_t Sha3_256_Ctx = {0};
void Sha3_256_Init(void)
{
  sha3_init(&Sha3_256_Ctx, Sha3_256Hasher.OutputSize);
}
void Sha3_256_Update(const uint8_t* input, int input_len)
{
  sha3_update(&Sha3_256_Ctx, input, input_len);
}
void Sha3_256_Final(uint8_t* output)
{
  sha3_final(output, &Sha3_256_Ctx);
}
void Sha3_256(const uint8_t* input, int input_len, uint8_t* output)
{
  sha3(input, input_len, output, Sha3_256Hasher.OutputSize);
}

const HashAlgo Skein256Hasher = {.OutputSize = Bytes256Bits,
                                 .InitFunc = Skein_256_Init_,
                                 .UpdateFunc = Skein_256_Update_,
                                 .FinalFunc = Skein_256_Final_,
                                 .HashFunc = Skein_256,
                                 .Name = "Skein-256"};
static Skein_256_Ctxt_t Skein_256_Ctx = {0};
void Skein_256_Init_(void)
{
  Skein_256_Init(&Skein_256_Ctx, 256);
}
void Skein_256_Update_(const uint8_t* input, int input_len)
{
  Skein_256_Update(&Skein_256_Ctx, input, input_len);
}
void Skein_256_Final_(uint8_t* output)
{
  Skein_256_Final(&Skein_256_Ctx, output);
}
void Skein_256(const uint8_t* input, int input_len, uint8_t* output)
{
  Skein_256_Ctxt_t ctx = {0};
  Skein_256_Init(&ctx, 256);
  Skein_256_Update(&ctx, input, input_len);
  Skein_256_Final(&ctx, output);
}

const HashAlgo xSiphash256Hasher = {.OutputSize = Bytes256Bits,
                                    .InitFunc = NULL,
                                    .UpdateFunc = NULL,
                                    .FinalFunc = NULL,
                                    .HashFunc = xSiphash_256,
                                    .Name = "xSiphash-256"};
void xSiphash_256(const uint8_t* input, int input_len, uint8_t* output)
{
  uint8_t key[16];
  ClearMemory(key, sizeof(key));
  memcpy(key, ExtendKey1, sizeof(ExtendKey1));
  siphash(input, input_len, key, output, Siphash128Hasher.OutputSize);
  memcpy(key, ExtendKey2, sizeof(ExtendKey2));
  siphash(input, input_len, key, output + Siphash128Hasher.OutputSize,
          Siphash128Hasher.OutputSize);
}

// Regular: 512-bit

const HashAlgo Blake2b512Hasher = {.OutputSize = Bytes512Bits,
                                   .InitFunc = Blake2b_512_Init,
                                   .UpdateFunc = Blake2b_512_Update,
                                   .FinalFunc = Blake2b_512_Final,
                                   .HashFunc = Blake2b_512,
                                   .Name = "Blake2b-512"};
static blake2b_state Blake2b_512_Ctx = {0};
void Blake2b_512_Init(void)
{
  VERIFY(blake2b_init(&Blake2b_512_Ctx, Blake2b512Hasher.OutputSize) == 0,
         "Blake2b_512_Init()");
}
void Blake2b_512_Update(const uint8_t* input, int input_len)
{
  VERIFY(blake2b_update(&Blake2b_512_Ctx, input, input_len) == 0,
         "Blake2b_512_Update()");
}
void Blake2b_512_Final(uint8_t* output)
{
  VERIFY(
    blake2b_final(&Blake2b_512_Ctx, output, Blake2b512Hasher.OutputSize) == 0,
    "Blake2b_512_Final()");
}
void Blake2b_512(const uint8_t* input, int input_len, uint8_t* output)
{
  VERIFY(blake2b(output, Blake2b512Hasher.OutputSize, input, input_len, NULL,
                 0) == 0,
         "Blake2b_512()");
}

const HashAlgo Blake3_512Hasher = {.OutputSize = Bytes512Bits,
                                   .InitFunc = Blake3_512_Init,
                                   .UpdateFunc = Blake3_512_Update,
                                   .FinalFunc = Blake3_512_Final,
                                   .HashFunc = Blake3_512,
                                   .Name = "Blake3-512"};
static blake3_hasher Blake3_512_Ctx = {0};
void Blake3_512_Init(void)
{
  blake3_hasher_init(&Blake3_512_Ctx);
}
void Blake3_512_Update(const uint8_t* input, int input_len)
{
  blake3_hasher_update(&Blake3_512_Ctx, input, input_len);
}
void Blake3_512_Final(uint8_t* output)
{
  blake3_hasher_finalize(&Blake3_512_Ctx, output, Blake3_512Hasher.OutputSize);
}
void Blake3_512(const uint8_t* input, int input_len, uint8_t* output)
{
  blake3_hasher ctx = {0};
  blake3_hasher_init(&ctx);
  blake3_hasher_update(&ctx, input, input_len);
  blake3_hasher_finalize(&ctx, output, Blake3_512Hasher.OutputSize);
}

const HashAlgo Sha2_512Hasher = {.OutputSize = Bytes512Bits,
                                 .InitFunc = Sha2_512_Init,
                                 .UpdateFunc = Sha2_512_Update,
                                 .FinalFunc = Sha2_512_Final,
                                 .HashFunc = Sha2_512,
                                 .Name = "SHA2-512"};
static SHA512Context Sha2_512_Ctx = {0};
void Sha2_512_Init(void)
{
  SHA512Reset(&Sha2_512_Ctx);
}
void Sha2_512_Update(const uint8_t* input, int input_len)
{
  SHA512Input(&Sha2_512_Ctx, input, input_len);
}
void Sha2_512_Final(uint8_t* output)
{
  SHA512Result(&Sha2_512_Ctx, output);
}
void Sha2_512(const uint8_t* input, int input_len, uint8_t* output)
{
  SHA512Context ctx = {0};
  SHA512Reset(&ctx);
  SHA512Input(&ctx, input, input_len);
  SHA512Result(&ctx, output);
}

const HashAlgo Sha3_512Hasher = {.OutputSize = Bytes512Bits,
                                 .InitFunc = Sha3_512_Init,
                                 .UpdateFunc = Sha3_512_Update,
                                 .FinalFunc = Sha3_512_Final,
                                 .HashFunc = Sha3_512,
                                 .Name = "SHA3-512"};
static sha3_ctx_t Sha3_512_Ctx = {0};
void Sha3_512_Init(void)
{
  sha3_init(&Sha3_512_Ctx, Sha3_512Hasher.OutputSize);
}
void Sha3_512_Update(const uint8_t* input, int input_len)
{
  sha3_update(&Sha3_512_Ctx, input, input_len);
}
void Sha3_512_Final(uint8_t* output)
{
  sha3_final(output, &Sha3_512_Ctx);
}
void Sha3_512(const uint8_t* input, int input_len, uint8_t* output)
{
  sha3(input, input_len, output, Sha3_512Hasher.OutputSize);
}

const HashAlgo Skein512Hasher = {.OutputSize = Bytes512Bits,
                                 .InitFunc = Skein_512_Init_,
                                 .UpdateFunc = Skein_512_Update_,
                                 .FinalFunc = Skein_512_Final_,
                                 .HashFunc = Skein_512,
                                 .Name = "Skein-512"};
static Skein_512_Ctxt_t Skein_512_Ctx = {0};
void Skein_512_Init_(void)
{
  Skein_512_Init(&Skein_512_Ctx, 512);
}
void Skein_512_Update_(const uint8_t* input, int input_len)
{
  Skein_512_Update(&Skein_512_Ctx, input, input_len);
}
void Skein_512_Final_(uint8_t* output)
{
  Skein_512_Final(&Skein_512_Ctx, output);
}
void Skein_512(const uint8_t* input, int input_len, uint8_t* output)
{
  Skein_512_Ctxt_t ctx = {0};
  Skein_512_Init(&ctx, 512);
  Skein_512_Update(&ctx, input, input_len);
  Skein_512_Final(&ctx, output);
}

const HashAlgo WhirlpoolHasher = {.OutputSize = Bytes512Bits,
                                  .InitFunc = Whirlpool_Init,
                                  .UpdateFunc = Whirlpool_Update,
                                  .FinalFunc = Whirlpool_Final,
                                  .HashFunc = Whirlpool,
                                  .Name = "Whirlpool"};
static WHIRLPOOL_CTX Whirlpool_Ctx = {0};
void Whirlpool_Init(void)
{
  WHIRLPOOL_init(&Whirlpool_Ctx);
}
void Whirlpool_Update(const uint8_t* input, int input_len)
{
  WHIRLPOOL_add(input, input_len * 8, &Whirlpool_Ctx);
}
void Whirlpool_Final(uint8_t* output)
{
  WHIRLPOOL_finalize(&Whirlpool_Ctx, output);
}
void Whirlpool(const uint8_t* input, int input_len, uint8_t* output)
{
  WHIRLPOOL_CTX ctx = {0};
  WHIRLPOOL_init(&ctx);
  WHIRLPOOL_add(input, input_len * 8, &ctx);
  WHIRLPOOL_finalize(&ctx, output);
}

const HashAlgo xBlake2s512Hasher = {.OutputSize = Bytes512Bits,
                                    .InitFunc = xBlake2s_512_Init,
                                    .UpdateFunc = xBlake2s_512_Update,
                                    .FinalFunc = xBlake2s_512_Final,
                                    .HashFunc = xBlake2s_512,
                                    .Name = "xBlake2s-512"};
static blake2s_state Blake2s_256_Ctx1 = {0};
void xBlake2s_512_Init(void)
{
  VERIFY(blake2s_init_key(&Blake2s_256_Ctx, Blake2s256Hasher.OutputSize,
                          ExtendKey1, sizeof(ExtendKey1)) == 0,
         "Blake2s_512_Init() 1");
  VERIFY(blake2s_init_key(&Blake2s_256_Ctx1, Blake2s256Hasher.OutputSize,
                          ExtendKey2, sizeof(ExtendKey2)) == 0,
         "Blake2s_512_Init() 2");
}
void xBlake2s_512_Update(const uint8_t* input, int input_len)
{
  VERIFY(blake2s_update(&Blake2s_256_Ctx, input, input_len) == 0,
         "Blake2s_512_Update() 1");
  VERIFY(blake2s_update(&Blake2s_256_Ctx1, input, input_len) == 0,
         "Blake2s_512_Update() 2");
}
void xBlake2s_512_Final(uint8_t* output)
{
  VERIFY(
    blake2s_final(&Blake2s_256_Ctx, output, Blake2s256Hasher.OutputSize) == 0,
    "Blake2s_512_Final() 1");
  VERIFY(blake2s_final(&Blake2s_256_Ctx1, output + Blake2s256Hasher.OutputSize,
                       Blake2s256Hasher.OutputSize) == 0,
         "Blake2s_512_Final() 2");
}
void xBlake2s_512(const uint8_t* input, int input_len, uint8_t* output)
{
  xBlake2s_512_Init();
  xBlake2s_512_Update(input, input_len);
  xBlake2s_512_Final(output);
}

// Regular: 1024-bit

const HashAlgo Blake3_1024Hasher = {.OutputSize = Bytes1024Bits,
                                    .InitFunc = Blake3_1024_Init,
                                    .UpdateFunc = Blake3_1024_Update,
                                    .FinalFunc = Blake3_1024_Final,
                                    .HashFunc = Blake3_1024,
                                    .Name = "Blake3-1024"};
static blake3_hasher Blake3_1024_Ctx = {0};
void Blake3_1024_Init(void)
{
  blake3_hasher_init(&Blake3_1024_Ctx);
}
void Blake3_1024_Update(const uint8_t* input, int input_len)
{
  blake3_hasher_update(&Blake3_1024_Ctx, input, input_len);
}
void Blake3_1024_Final(uint8_t* output)
{
  blake3_hasher_finalize(&Blake3_1024_Ctx, output,
                         Blake3_1024Hasher.OutputSize);
}
void Blake3_1024(const uint8_t* input, int input_len, uint8_t* output)
{
  blake3_hasher ctx = {0};
  blake3_hasher_init(&ctx);
  blake3_hasher_update(&ctx, input, input_len);
  blake3_hasher_finalize(&ctx, output, Blake3_1024Hasher.OutputSize);
}

const HashAlgo Skein1024Hasher = {.OutputSize = Bytes1024Bits,
                                  .InitFunc = Skein_1024_Init_,
                                  .UpdateFunc = Skein_1024_Update_,
                                  .FinalFunc = Skein_1024_Final_,
                                  .HashFunc = Skein_1024,
                                  .Name = "Skein-1024"};
static Skein1024_Ctxt_t Skein_1024_Ctx = {0};
void Skein_1024_Init_(void)
{
  Skein1024_Init(&Skein_1024_Ctx, 1024);
}
void Skein_1024_Update_(const uint8_t* input, int input_len)
{
  Skein1024_Update(&Skein_1024_Ctx, input, input_len);
}
void Skein_1024_Final_(uint8_t* output)
{
  Skein1024_Final(&Skein_1024_Ctx, output);
}
void Skein_1024(const uint8_t* input, int input_len, uint8_t* output)
{
  Skein1024_Ctxt_t ctx = {0};
  Skein1024_Init(&ctx, 1024);
  Skein1024_Update(&ctx, input, input_len);
  Skein1024_Final(&ctx, output);
}

const HashAlgo xBlake2b1024Hasher = {.OutputSize = Bytes1024Bits,
                                     .InitFunc = xBlake2b_1024_Init,
                                     .UpdateFunc = xBlake2b_1024_Update,
                                     .FinalFunc = xBlake2b_1024_Final,
                                     .HashFunc = xBlake2b_1024,
                                     .Name = "xBlake2b-1024"};
static blake2b_state Blake2b_512_Ctx1 = {0};
void xBlake2b_1024_Init(void)
{
  VERIFY(blake2b_init_key(&Blake2b_512_Ctx, Blake2b512Hasher.OutputSize,
                          ExtendKey1, sizeof(ExtendKey1)) == 0,
         "xBlake2b_1024_Init() 1");
  VERIFY(blake2b_init_key(&Blake2b_512_Ctx1, Blake2b512Hasher.OutputSize,
                          ExtendKey2, sizeof(ExtendKey2)) == 0,
         "xBlake2b_1024_Init() 2");
}
void xBlake2b_1024_Update(const uint8_t* input, int input_len)
{
  VERIFY(blake2b_update(&Blake2b_512_Ctx, input, input_len) == 0,
         "xBlake2b_1024_Update() 1");
  VERIFY(blake2b_update(&Blake2b_512_Ctx1, input, input_len) == 0,
         "xBlake2b_1024_Update() 2");
}
void xBlake2b_1024_Final(uint8_t* output)
{
  VERIFY(
    blake2b_final(&Blake2b_512_Ctx, output, Blake2b512Hasher.OutputSize) == 0,
    "xBlake2b_1024_Final() 1");
  VERIFY(blake2b_final(&Blake2b_512_Ctx1, output + Blake2b512Hasher.OutputSize,
                       Blake2b512Hasher.OutputSize) == 0,
         "xBlake2b_1024_Final() 2");
}
void xBlake2b_1024(const uint8_t* input, int input_len, uint8_t* output)
{
  xBlake2b_1024_Init();
  xBlake2b_1024_Update(input, input_len);
  xBlake2b_1024_Final(output);
}

const HashAlgo xSha2_1024Hasher = {.OutputSize = Bytes1024Bits,
                                   .InitFunc = xSha2_1024_Init,
                                   .UpdateFunc = xSha2_1024_Update,
                                   .FinalFunc = xSha2_1024_Final,
                                   .HashFunc = xSha2_1024,
                                   .Name = "xSHA2-1024"};
static SHA512Context Sha2_512_Ctx1 = {0};
void xSha2_1024_Init(void)
{
  SHA512Reset(&Sha2_512_Ctx);
  SHA512Input(&Sha2_512_Ctx, ExtendKey1, sizeof(ExtendKey1));
  SHA512Reset(&Sha2_512_Ctx1);
  SHA512Input(&Sha2_512_Ctx1, ExtendKey2, sizeof(ExtendKey2));
}
void xSha2_1024_Update(const uint8_t* input, int input_len)
{
  SHA512Input(&Sha2_512_Ctx, input, input_len);
  SHA512Input(&Sha2_512_Ctx1, input, input_len);
}
void xSha2_1024_Final(uint8_t* output)
{
  SHA512Result(&Sha2_512_Ctx, output);
  SHA512Result(&Sha2_512_Ctx1, output + Sha2_512Hasher.OutputSize);
}
void xSha2_1024(const uint8_t* input, int input_len, uint8_t* output)
{
  xSha2_1024_Init();
  xSha2_1024_Update(input, input_len);
  xSha2_1024_Final(output);
}

const HashAlgo xSha3_1024Hasher = {.OutputSize = Bytes1024Bits,
                                   .InitFunc = xSha3_1024_Init,
                                   .UpdateFunc = xSha3_1024_Update,
                                   .FinalFunc = xSha3_1024_Final,
                                   .HashFunc = xSha3_1024,
                                   .Name = "xSHA3-1024"};
static sha3_ctx_t Sha3_512_Ctx1 = {0};
void xSha3_1024_Init(void)
{
  sha3_init(&Sha3_512_Ctx, Sha3_512Hasher.OutputSize);
  sha3_update(&Sha3_512_Ctx, ExtendKey1, sizeof(ExtendKey1));
  sha3_init(&Sha3_512_Ctx1, Sha3_512Hasher.OutputSize);
  sha3_update(&Sha3_512_Ctx1, ExtendKey2, sizeof(ExtendKey2));
}
void xSha3_1024_Update(const uint8_t* input, int input_len)
{
  sha3_update(&Sha3_512_Ctx, input, input_len);
  sha3_update(&Sha3_512_Ctx1, input, input_len);
}
void xSha3_1024_Final(uint8_t* output)
{
  sha3_final(output, &Sha3_512_Ctx);
  sha3_final(output + Sha3_512Hasher.OutputSize, &Sha3_512_Ctx1);
}
void xSha3_1024(const uint8_t* input, int input_len, uint8_t* output)
{
  xSha3_1024_Init();
  xSha3_1024_Update(input, input_len);
  xSha3_1024_Final(output);
}

const HashAlgo xWhirlpool1024Hasher = {.OutputSize = Bytes1024Bits,
                                       .InitFunc = xWhirlpool_1024_Init,
                                       .UpdateFunc = xWhirlpool_1024_Update,
                                       .FinalFunc = xWhirlpool_1024_Final,
                                       .HashFunc = xWhirlpool_1024,
                                       .Name = "xWhirlpool-1024"};
static WHIRLPOOL_CTX Whirlpool_Ctx1 = {0};
void xWhirlpool_1024_Init(void)
{
  WHIRLPOOL_init(&Whirlpool_Ctx);
  WHIRLPOOL_add(ExtendKey1, sizeof(ExtendKey1) * 8, &Whirlpool_Ctx);
  WHIRLPOOL_init(&Whirlpool_Ctx1);
  WHIRLPOOL_add(ExtendKey2, sizeof(ExtendKey2) * 8, &Whirlpool_Ctx1);
}
void xWhirlpool_1024_Update(const uint8_t* input, int input_len)
{
  WHIRLPOOL_add(input, input_len * 8, &Whirlpool_Ctx);
  WHIRLPOOL_add(input, input_len * 8, &Whirlpool_Ctx1);
}
void xWhirlpool_1024_Final(uint8_t* output)
{
  WHIRLPOOL_finalize(&Whirlpool_Ctx, output);
  WHIRLPOOL_finalize(&Whirlpool_Ctx1, output + WhirlpoolHasher.OutputSize);
}
void xWhirlpool_1024(const uint8_t* input, int input_len, uint8_t* output)
{
  xWhirlpool_1024_Init();
  xWhirlpool_1024_Update(input, input_len);
  xWhirlpool_1024_Final(output);
}

//// Keyed-hash

// Keyed: 256-bit

const KeyedHashAlgo Blake2b256KeyedHasher = {
  .OutputSize = Bytes256Bits, .KeyedHashFunc = Keyed_Blake2b_256};
void Keyed_Blake2b_256(const uint8_t* input, int input_len, const uint8_t* key,
                       int key_len, uint8_t* output)
{
  blake2b(output, Blake2b256KeyedHasher.OutputSize, input, input_len, key,
          key_len);
}

const KeyedHashAlgo Blake2s256KeyedHasher = {
  .OutputSize = Bytes256Bits, .KeyedHashFunc = Keyed_Blake2s_256};
void Keyed_Blake2s_256(const uint8_t* input, int input_len, const uint8_t* key,
                       int key_len, uint8_t* output)
{
  blake2s(output, Blake2s256KeyedHasher.OutputSize, input, input_len, key,
          key_len);
}

const KeyedHashAlgo Blake3_256KeyedHasher = {.OutputSize = Bytes256Bits,
                                             .KeyedHashFunc = Keyed_Blake3_256};
void Keyed_Blake3_256(const uint8_t* input, int input_len, const uint8_t* key,
                      int key_len, uint8_t* output)
{
  uint8_t blake3key[BLAKE3_KEY_LEN];
  ClearMemory(blake3key, sizeof(blake3key));
  key_len = key_len > BLAKE3_KEY_LEN ? BLAKE3_KEY_LEN : key_len;
  memcpy(blake3key, key, key_len);
  blake3_hasher ctx = {0};
  blake3_hasher_init_keyed(&ctx, blake3key);
  blake3_hasher_update(&ctx, input, input_len);
  blake3_hasher_finalize(&ctx, output, Blake3_256KeyedHasher.OutputSize);
  ClearMemory(blake3key, sizeof(blake3key));
}

const KeyedHashAlgo Skein256KeyedHasher = {.OutputSize = Bytes256Bits,
                                           .KeyedHashFunc = Keyed_Skein_256};
void Keyed_Skein_256(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output)
{
  Skein_256_Ctxt_t ctx = {0};
  Skein_256_InitExt(&ctx, 256, 0, key, key_len);
  Skein_256_Update(&ctx, input, input_len);
  Skein_256_Final(&ctx, output);
}

// Keyed: 512-bit

const KeyedHashAlgo Blake2b512KeyedHasher = {
  .OutputSize = Bytes512Bits, .KeyedHashFunc = Keyed_Blake2b_512};
void Keyed_Blake2b_512(const uint8_t* input, int input_len, const uint8_t* key,
                       int key_len, uint8_t* output)
{
  blake2b(output, Blake2b512KeyedHasher.OutputSize, input, input_len, key,
          key_len);
}

const KeyedHashAlgo Blake3_512KeyedHasher = {.OutputSize = Bytes512Bits,
                                             .KeyedHashFunc = Keyed_Blake3_512};
void Keyed_Blake3_512(const uint8_t* input, int input_len, const uint8_t* key,
                      int key_len, uint8_t* output)
{
  uint8_t blake3key[BLAKE3_KEY_LEN];
  ClearMemory(blake3key, sizeof(blake3key));
  key_len = key_len > BLAKE3_KEY_LEN ? BLAKE3_KEY_LEN : key_len;
  memcpy(blake3key, key, key_len);
  blake3_hasher ctx = {0};
  blake3_hasher_init_keyed(&ctx, blake3key);
  blake3_hasher_update(&ctx, input, input_len);
  blake3_hasher_finalize(&ctx, output, Blake3_512KeyedHasher.OutputSize);
  ClearMemory(blake3key, sizeof(blake3key));
}

const KeyedHashAlgo Skein512KeyedHasher = {.OutputSize = Bytes512Bits,
                                           .KeyedHashFunc = Keyed_Skein_512};
void Keyed_Skein_512(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output)
{
  Skein_512_Ctxt_t ctx = {0};
  Skein_512_InitExt(&ctx, 512, 0, key, key_len);
  Skein_512_Update(&ctx, input, input_len);
  Skein_512_Final(&ctx, output);
}

//// PBKDF

void Pbkdf_Display_Progress(const PbkdfHashAlgo* pbkdf, const uint8_t* input,
                            int input_len, const uint8_t* salt, int salt_len,
                            int iterations, uint8_t* output, const char* title)
{
  pbkdf->InitFunc(input, input_len, salt, salt_len);
  int times = iterations / PBKDF_UNIT_ITERATIONS;
  int last = iterations % PBKDF_UNIT_ITERATIONS;
  DisplayPercentage(title, 0.f);
  for (int i = 0; i < times; ++i)
  {
    pbkdf->UpdateFunc(PBKDF_UNIT_ITERATIONS);
    float percent = (i + 1) * (float)PBKDF_UNIT_ITERATIONS / iterations;
    DisplayPercentage(title, percent);
  }
  if (last > 0)
  {
    pbkdf->UpdateFunc(last);
    DisplayPercentage(title, 1.f);
  }
  pbkdf->FinalFunc(output);
}
