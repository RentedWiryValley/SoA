#pragma once

#include "basics.h"

long GetTime();
void DisplayText(const char* text);
void DisplayPercentage(const char* title, float percent);
void DisplayByteArray(const uint8_t* bytes, int len, const char* title);
void ByteArrayToHexString(const uint8_t* array, int length, char* string);
