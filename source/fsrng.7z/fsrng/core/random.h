#pragma once

#include "basics.h"

uint8_t SoftwareRandom8(void);
uint16_t SoftwareRandom16(void);
uint32_t SoftwareRandom32(void);
uint64_t SoftwareRandom64(void);
void SoftwareRandomBuffer(uint8_t* buffer, size_t size);

