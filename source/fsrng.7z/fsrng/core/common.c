#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "common.h"

#include "hash/Whirlpool.h"
#include "hash/blake2.h"
#include "hash/blake3.h"
#include "hash/sha.h"
#include "hash/sha3.h"
#include "hash/skein.h"

long GetTime()
{
  struct timespec t = {0};
  clock_gettime(CLOCK_MONOTONIC, &t);
  long time = t.tv_sec * 1000000000 + t.tv_nsec;
  return time;
}

void DisplayText(const char* text)
{
  printf("%s\n", text);
}

void DisplayPercentage(const char* title, float percent)
{
  char str[256];
  sprintf(str, "%.1f%%", percent * 100);
  printf("\33[2K\r%s: %s", title, str);
  if (percent < 1.0f)
    fflush(stdout);
  else
    printf("\n");
}

void DisplayByteArray(const uint8_t* bytes, int len, const char* title)
{
  if (title && strlen(title) > 0)
    printf("%s: ", title);
  for (int i = 0; i < len; ++i)
    printf("%02x", bytes[i]);
  printf("\n");
}

void ByteArrayToHexString(const uint8_t* bytes, int length, char* string)
{
  for (int i = 0; i < length; ++i)
    string += sprintf(string, "%02x", bytes[i]);
  string[0] = 0;
}
