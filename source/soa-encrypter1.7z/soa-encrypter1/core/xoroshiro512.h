#pragma once

#include "basics.h"
#include "xoroshiro.h"

typedef struct _Xoroshiro512Ctx
{
  uint64_t s[8];
} Xoroshiro512Ctx;

#define XOROSHIRO512_KEY_SIZE ((int)sizeof(((Xoroshiro512Ctx*)0)->s))
