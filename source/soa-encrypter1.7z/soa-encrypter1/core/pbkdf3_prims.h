#pragma message("THIS IS EXAMPLE CODE.")

#pragma once

#include "hash.h"

// 256-bit

#define MainHasher256 Skein256Hasher

// 512-bit

#define MainHasher512 Skein512Hasher
