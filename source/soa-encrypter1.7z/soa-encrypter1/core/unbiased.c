#include "unbiased.h"

uint8_t Unbiased8(GetUint8Func random8func, uint8_t ceiling)
{
  const uint8_t MAXVALUE = -1;
  const uint8_t MIDPOINT = MAXVALUE / 2 + 1;
  if (ceiling == 0)
    return random8func();
  uint8_t maxvalue;
  if (ceiling >= MIDPOINT)
  {
    maxvalue = ceiling;
  }
  else
  {
    maxvalue = MAXVALUE / ceiling * ceiling;
  }
  uint8_t r;
  do
  {
    r = random8func();
  } while (r >= maxvalue);
  r %= ceiling;
  return r;
}

uint16_t Unbiased16(GetUint16Func random16func, uint16_t ceiling)
{
  const uint16_t MAXVALUE = -1;
  const uint16_t MIDPOINT = MAXVALUE / 2 + 1;
  if (ceiling == 0)
    return random16func();
  uint16_t maxvalue;
  if (ceiling >= MIDPOINT)
  {
    maxvalue = ceiling;
  }
  else
  {
    maxvalue = MAXVALUE / ceiling * ceiling;
  }
  uint16_t r;
  do
  {
    r = random16func();
  } while (r >= maxvalue);
  r %= ceiling;
  return r;
}

uint32_t Unbiased32(GetUint32Func random32func, uint32_t ceiling)
{
  const uint32_t MAXVALUE = -1;
  const uint32_t MIDPOINT = MAXVALUE / 2 + 1;
  if (ceiling == 0)
    return random32func();
  uint32_t maxvalue;
  if (ceiling >= MIDPOINT)
  {
    maxvalue = ceiling;
  }
  else
  {
    maxvalue = MAXVALUE / ceiling * ceiling;
  }
  uint32_t r;
  do
  {
    r = random32func();
  } while (r >= maxvalue);
  r %= ceiling;
  return r;
}

uint64_t Unbiased64(GetUint64Func random64func, uint64_t ceiling)
{
  const uint64_t MAXVALUE = -1;
  const uint64_t MIDPOINT = MAXVALUE / 2 + 1;
  if (ceiling == 0)
    return random64func();
  uint64_t maxvalue;
  if (ceiling >= MIDPOINT)
  {
    maxvalue = ceiling;
  }
  else
  {
    maxvalue = MAXVALUE / ceiling * ceiling;
  }
  uint64_t r;
  do
  {
    r = random64func();
  } while (r >= maxvalue);
  r %= ceiling;
  return r;
}
