#include <string.h>

#include "pbkdf3a.h"
#include "pbkdf3a_prims.h"

#include "memxor.h"

// 256-bit

const PbkdfHashAlgo Pbkdf3a_256Hasher = {.OutputSize = Bytes256Bits,
                                         .InitFunc = Pbkdf3a_256_Init,
                                         .UpdateFunc = Pbkdf3a_256_Update,
                                         .FinalFunc = Pbkdf3a_256_Final,
                                         .HashFunc = Pbkdf3a_256};

void Pbkdf3a_256_Init_Ctx(PBKDF3a_256_CTX* ctx, const uint8_t* pass,
                          int pass_len, const uint8_t* salt, int salt_len)
{
  MainHasher256.InitFunc();
  MainHasher256.UpdateFunc(pass, pass_len);
  MainHasher256.UpdateFunc(salt, salt_len);
  Hash256Funcs[0](pass, pass_len, ctx->passhash);
  Hash256Funcs[1](salt, salt_len, ctx->salthash);
}

void Pbkdf3a_256_Update_Ctx(PBKDF3a_256_CTX* ctx, int iterations)
{
  for (int i = 0; i < iterations; ++i)
  {
    MainHasher256.UpdateFunc(ctx->passhash, sizeof(ctx->passhash));
    MainHasher256.UpdateFunc(ctx->salthash, sizeof(ctx->salthash));
    uint32_t* ph = (uint32_t*)ctx->passhash;
    uint32_t* sh = (uint32_t*)ctx->salthash;
    for (int j = 0; j < BYTES_256_BITS / (int)sizeof(uint32_t); ++j)
    {
      ++ph[j];
      ++sh[j];
    }
  }
}

void Pbkdf3a_256_Final_Ctx(PBKDF3a_256_CTX* ctx, uint8_t* key)
{
  uint8_t output[BYTES_256_BITS];
  MainHasher256.FinalFunc(output);
  memcpy(key, output, BYTES_256_BITS);
  memxor(ctx->passhash, output, sizeof(ctx->passhash));
  Hash256Funcs[1](ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  Hash256Funcs[1](ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  memxor(key, ctx->passhash, BYTES_256_BITS);
  memxor(ctx->salthash, output, sizeof(ctx->salthash));
  Hash256Funcs[0](ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  Hash256Funcs[0](ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  memxor(key, ctx->salthash, BYTES_256_BITS);
  ClearMemory(output, sizeof(output));
  ClearMemory(ctx, sizeof(PBKDF3a_256_CTX));
}

static PBKDF3a_256_CTX Pbkdf3a_256_Ctx = {0};

void Pbkdf3a_256_Init(const uint8_t* pass, int pass_len, const uint8_t* salt,
                      int salt_len)
{
  ClearMemory(&Pbkdf3a_256_Ctx, sizeof(Pbkdf3a_256_Ctx));
  Pbkdf3a_256_Init_Ctx(&Pbkdf3a_256_Ctx, pass, pass_len, salt, salt_len);
}

void Pbkdf3a_256_Update(int iterations)
{
  Pbkdf3a_256_Update_Ctx(&Pbkdf3a_256_Ctx, iterations);
}

void Pbkdf3a_256_Final(uint8_t* output)
{
  Pbkdf3a_256_Final_Ctx(&Pbkdf3a_256_Ctx, output);
}

void Pbkdf3a_256(const uint8_t* pass, int pass_len, const uint8_t* salt,
                 int salt_len, int iterations, uint8_t* output)
{
  PBKDF3a_256_CTX ctx = {0};
  ClearMemory(&ctx, sizeof(ctx));
  Pbkdf3a_256_Init_Ctx(&ctx, pass, pass_len, salt, salt_len);
  Pbkdf3a_256_Update_Ctx(&ctx, iterations);
  Pbkdf3a_256_Final_Ctx(&ctx, output);
}

// 512-bit

const PbkdfHashAlgo Pbkdf3a_512Hasher = {.OutputSize = Bytes512Bits,
                                         .InitFunc = Pbkdf3a_512_Init,
                                         .UpdateFunc = Pbkdf3a_512_Update,
                                         .FinalFunc = Pbkdf3a_512_Final,
                                         .HashFunc = Pbkdf3a_512};

void Pbkdf3a_512_Init_Ctx(PBKDF3a_512_CTX* ctx, const uint8_t* pass,
                          int pass_len, const uint8_t* salt, int salt_len)
{
  MainHasher512.InitFunc();
  MainHasher512.UpdateFunc(pass, pass_len);
  MainHasher512.UpdateFunc(salt, salt_len);
  Hash512Funcs[0](pass, pass_len, ctx->passhash);
  Hash512Funcs[1](salt, salt_len, ctx->salthash);
}

void Pbkdf3a_512_Update_Ctx(PBKDF3a_512_CTX* ctx, int iterations)
{
  for (int i = 0; i < iterations; ++i)
  {
    MainHasher512.UpdateFunc(ctx->passhash, sizeof(ctx->passhash));
    MainHasher512.UpdateFunc(ctx->salthash, sizeof(ctx->salthash));
    uint32_t* ph = (uint32_t*)ctx->passhash;
    uint32_t* sh = (uint32_t*)ctx->salthash;
    for (int j = 0; j < BYTES_512_BITS / (int)sizeof(uint32_t); ++j)
    {
      ++ph[j];
      ++sh[j];
    }
  }
}

void Pbkdf3a_512_Final_Ctx(PBKDF3a_512_CTX* ctx, uint8_t* key)
{
  uint8_t output[BYTES_512_BITS];
  MainHasher512.FinalFunc(output);
  memcpy(key, output, BYTES_512_BITS);
  memxor(ctx->passhash, output, sizeof(ctx->passhash));
  Hash512Funcs[1](ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  Hash512Funcs[1](ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  memxor(key, ctx->passhash, BYTES_512_BITS);
  memxor(ctx->salthash, output, sizeof(ctx->salthash));
  Hash512Funcs[0](ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  Hash512Funcs[0](ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  memxor(key, ctx->salthash, BYTES_512_BITS);
  ClearMemory(output, sizeof(output));
  ClearMemory(ctx, sizeof(PBKDF3a_512_CTX));
}

static PBKDF3a_512_CTX Pbkdf3a_512_Ctx = {0};

void Pbkdf3a_512_Init(const uint8_t* pass, int pass_len, const uint8_t* salt,
                      int salt_len)
{
  ClearMemory(&Pbkdf3a_512_Ctx, sizeof(Pbkdf3a_512_Ctx));
  Pbkdf3a_512_Init_Ctx(&Pbkdf3a_512_Ctx, pass, pass_len, salt, salt_len);
}

void Pbkdf3a_512_Update(int iterations)
{
  Pbkdf3a_512_Update_Ctx(&Pbkdf3a_512_Ctx, iterations);
}

void Pbkdf3a_512_Final(uint8_t* output)
{
  Pbkdf3a_512_Final_Ctx(&Pbkdf3a_512_Ctx, output);
}

void Pbkdf3a_512(const uint8_t* pass, int pass_len, const uint8_t* salt,
                 int salt_len, int iterations, uint8_t* output)
{
  PBKDF3a_512_CTX ctx = {0};
  ClearMemory(&ctx, sizeof(ctx));
  Pbkdf3a_512_Init_Ctx(&ctx, pass, pass_len, salt, salt_len);
  Pbkdf3a_512_Update_Ctx(&ctx, iterations);
  Pbkdf3a_512_Final_Ctx(&ctx, output);
}
