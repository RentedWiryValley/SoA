#include <string.h>

#include "bufferedstream.h"

#include "memxor.h"

void RefreshBufferedStream(BufferedStream* stream)
{
  stream->Refresh();
  stream->Index = 0;
}

uint8_t Extract8(BufferedStream* stream)
{
  if (!stream || stream->Size <= 0)
    return 0;

  const int UNIT_SIZE = sizeof(uint8_t);

  if (stream->Index > stream->Size - UNIT_SIZE)
    RefreshBufferedStream(stream);

  uint8_t* Uint8Buffer = (uint8_t*)&stream->Buffer[stream->Index];
  uint8_t r = *Uint8Buffer;
  *Uint8Buffer = 0;
  stream->Index += UNIT_SIZE;

  return r;
}

uint16_t Extract16(BufferedStream* stream)
{
  if (!stream || stream->Size <= 0)
    return 0;

  const int UNIT_SIZE = sizeof(uint16_t);

  if (stream->Index > stream->Size - UNIT_SIZE)
    RefreshBufferedStream(stream);

  uint16_t* Uint16Buffer = (uint16_t*)&stream->Buffer[stream->Index];
  uint16_t r = *Uint16Buffer;
  *Uint16Buffer = 0;
  stream->Index += UNIT_SIZE;

  return r;
}

uint32_t Extract32(BufferedStream* stream)
{
  if (!stream || stream->Size <= 0)
    return 0;

  const int UNIT_SIZE = sizeof(uint32_t);

  if (stream->Index > stream->Size - UNIT_SIZE)
    RefreshBufferedStream(stream);

  uint32_t* Uint32Buffer = (uint32_t*)&stream->Buffer[stream->Index];
  uint32_t r = *Uint32Buffer;
  *Uint32Buffer = 0;
  stream->Index += UNIT_SIZE;

  return r;
}

uint64_t Extract64(BufferedStream* stream)
{
  if (!stream || stream->Size <= 0)
    return 0;

  const int UNIT_SIZE = sizeof(uint64_t);

  if (stream->Index > stream->Size - UNIT_SIZE)
    RefreshBufferedStream(stream);

  uint64_t* Uint64Buffer = (uint64_t*)&stream->Buffer[stream->Index];
  uint64_t r = *Uint64Buffer;
  *Uint64Buffer = 0;
  stream->Index += UNIT_SIZE;

  return r;
}

void ExtractToBuffer(BufferedStream* stream, uint8_t* buffer, int size)
{
  if (!stream || !buffer || size <= 0)
    return;

  if (stream->Size <= 0)
  {
    ClearMemory(buffer, size);
    return;
  }

  while (size > 0)
  {
    if (stream->Index >= stream->Size)
      RefreshBufferedStream(stream);

    int available = stream->Size - stream->Index;
    int extracted = size > available ? available : size;
    memcpy(buffer, &stream->Buffer[stream->Index], extracted);
    stream->Index += extracted;
    buffer += extracted;
    size -= extracted;
  }
}

void ExtractXorBuffer(BufferedStream* stream, uint8_t* buffer, int size)
{
  if (!stream || !buffer || size <= 0)
    return;

  if (stream->Size <= 0)
    return;

  while (size > 0)
  {
    if (stream->Index >= stream->Size)
      RefreshBufferedStream(stream);

    int available = stream->Size - stream->Index;
    int extracted = size > available ? available : size;
    memxor(buffer, &stream->Buffer[stream->Index], extracted);
    stream->Index += extracted;
    buffer += extracted;
    size -= extracted;
  }
}
