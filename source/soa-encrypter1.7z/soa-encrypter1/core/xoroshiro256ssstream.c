#include "xoroshiro256ssstream.h"
#include "xoroshiro256.h"

#include "bufferedstream.h"
#include "hash.h"

const PrngAlgo Xoroshiro256ssPrng = {
  .InitFunc = Xoroshiro256ssInit,
  .DeinitFunc = Xoroshiro256ssDeinit,
  .GetUint8Func = Xoroshiro256ssRand8,
  .GetUint16Func = Xoroshiro256ssRand16,
  .GetUint32Func = Xoroshiro256ssRand32,
  .GetUint64Func = Xoroshiro256ssRand64,
  .BufferFunc = Xoroshiro256ssRandBuffer,
  .XorBufferFunc = Xoroshiro256ssRandXorBuffer};

void GenerateXoroshiro256ssStream(void);

static BufferedStream Xoroshiro256ssBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro256ssStream};

static Xoroshiro256Ctx Ctx = {0};
static BOOL Xoroshiro256ssInitialized = FALSE;

static uint64_t Xoroshiro256ssNext(void)
{
  const uint64_t result = rotl64(Ctx.s[1] * 5, 7) * 9;

  const uint64_t t = Ctx.s[1] << 17;

  Ctx.s[2] ^= Ctx.s[0];
  Ctx.s[3] ^= Ctx.s[1];
  Ctx.s[1] ^= Ctx.s[2];
  Ctx.s[0] ^= Ctx.s[3];

  Ctx.s[2] ^= t;

  Ctx.s[3] = rotl64(Ctx.s[3], 45);

  return result;
}

void Xoroshiro256ssInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro256ssInitialized, "Xoroshiro256** already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro256** key!");

  Sha3_256(key, key_len, (uint8_t*)Ctx.s);

  Xoroshiro256ssBufferedStream.Index = Xoroshiro256ssBufferedStream.Size;

  Xoroshiro256ssInitialized = TRUE;
}

void Xoroshiro256ssDeinit(void)
{
  VERIFY(Xoroshiro256ssInitialized, "Xoroshiro256** not initialized");

  Xoroshiro256ssBufferedStream.Index = Xoroshiro256ssBufferedStream.Size;

  Xoroshiro256ssInitialized = FALSE;
}

void GenerateXoroshiro256ssStream(void)
{
  VERIFY(Xoroshiro256ssInitialized, "Xoroshiro256** not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro256ssBufferedStream.Buffer;
  for (int i = 0; i < Xoroshiro256ssBufferedStream.Size / (int)sizeof(uint64_t);
       ++i)
  {
    *p = Xoroshiro256ssNext();
    ++p;
  }
}

uint8_t Xoroshiro256ssRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro256ssBufferedStream);
  return r;
}

uint16_t Xoroshiro256ssRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro256ssBufferedStream);
  return r;
}

uint32_t Xoroshiro256ssRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro256ssBufferedStream);
  return r;
}

uint64_t Xoroshiro256ssRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro256ssBufferedStream);
  return r;
}

void Xoroshiro256ssRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro256ssBufferedStream, buffer, size);
}

void Xoroshiro256ssRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro256ssBufferedStream, buffer, size);
}
