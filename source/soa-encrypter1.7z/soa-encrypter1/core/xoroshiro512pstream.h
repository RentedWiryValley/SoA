#pragma once

#include "basic_prng.h"

void Xoroshiro512pInit(const uint8_t* key, int key_len);
void Xoroshiro512pDeinit(void);
uint8_t Xoroshiro512pRand8(void);
uint16_t Xoroshiro512pRand16(void);
uint32_t Xoroshiro512pRand32(void);
uint64_t Xoroshiro512pRand64(void);
void Xoroshiro512pRandBuffer(uint8_t* buffer, int size);
void Xoroshiro512pRandXorBuffer(uint8_t* buffer, int size);
