#pragma once

#include "basics.h"
#include "xoroshiro.h"

typedef struct _Xoroshiro256Ctx
{
  uint64_t s[4];
} Xoroshiro256Ctx;

#define XOROSHIRO256_KEY_SIZE ((int)sizeof(((Xoroshiro256Ctx*)0)->s))
