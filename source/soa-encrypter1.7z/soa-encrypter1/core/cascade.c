#include <stdio.h>
#include <string.h>

#include "cascade.h"
#include "cascade_prims.h"

#include "common.h"

#include "cipher.h"
#include "cocktail.h"
#include "hash.h"

#include "alpha_common.h"
#include "bravo_common.h"

#include "debugging.h"

#define KEY_SIZE BYTES_512_BITS
#define KEY_HASH_SIZE BYTES_256_BITS
#define NUM_ALGOS 5
#define OUTPUT_SIZE 1024

/*
  AES
  Chacha20
  Alpha
  Cocktail
  Bravo
*/

void VerifyKey(const uint8_t* key, const uint8_t* keyhash)
{
  uint8_t hash[KEY_HASH_SIZE];
  Sha2_256(key, KEY_SIZE, hash);
  VERIFY(memcmp(keyhash, hash, KEY_HASH_SIZE) == 0, "Error verifying key");
}

void DeriveKeys(char* password, char* pbkdf_salt, int* pbkdf_iterations,
                uint8_t Keys[][KEY_SIZE], uint8_t KeyHashs[][KEY_HASH_SIZE],
                const char* KeySalts[], BOOL Verify)
{
  uint8_t TempKey[KEY_SIZE];

  uint8_t MasterKey[KEY_SIZE];
  uint8_t MasterKeyHash[KEY_HASH_SIZE];
  Pbkdf_Display_Progress(CascadeMasterKeyPbkdfHasher, (uint8_t*)password,
                         strlen(password), (uint8_t*)pbkdf_salt,
                         strlen(pbkdf_salt), *pbkdf_iterations, MasterKey,
                         "Master key");
  if (Verify)
  {
    Pbkdf_Display_Progress(CascadeMasterKeyPbkdfHasher, (uint8_t*)password,
                           strlen(password), (uint8_t*)pbkdf_salt,
                           strlen(pbkdf_salt), *pbkdf_iterations, TempKey,
                           "Master key (verify)");
    VERIFY(memcmp(MasterKey, TempKey, KEY_SIZE) == 0,
           "Error verifying Master key PBKDF");
  }
  Sha2_256(MasterKey, sizeof(MasterKey), MasterKeyHash);

  ClearMemory(password, strlen(password));
  ClearMemory(pbkdf_salt, strlen(pbkdf_salt));

  char str[256];
  for (int i = 0; i < NUM_ALGOS; ++i)
  {
    VerifyKey(MasterKey, MasterKeyHash);
    const char* KeySalt = KeySalts[i];
    HashFunc KeyHashFunc = CascadeKeyHashFuncs[i];
    const PbkdfHashAlgo* KeyPbkdfHasher = CascadeKeyPbkdfHashers[i];
    KeyHashFunc(MasterKey, sizeof(MasterKey), TempKey);
    sprintf(str, "%s key", KeySalt);
    Pbkdf_Display_Progress(KeyPbkdfHasher, TempKey, KEY_SIZE, (uint8_t*)KeySalt,
                           strlen(KeySalt), *pbkdf_iterations, Keys[i], str);
    if (Verify)
    {
      KeyHashFunc(MasterKey, sizeof(MasterKey), TempKey);
      sprintf(str, "%s key (verify)", KeySalt);
      Pbkdf_Display_Progress(KeyPbkdfHasher, TempKey, KEY_SIZE,
                             (uint8_t*)KeySalt, strlen(KeySalt),
                             *pbkdf_iterations, TempKey, str);
      VERIFY(memcmp(Keys[i], TempKey, KEY_SIZE) == 0,
             "Error verifying key PBKDF");
    }
    Sha2_256(Keys[i], KEY_SIZE, KeyHashs[i]);
  }

  ClearMemory(MasterKey, sizeof(MasterKey));
  ClearMemory(MasterKeyHash, sizeof(MasterKeyHash));

  ClearMemory(TempKey, sizeof(TempKey));

  *pbkdf_iterations = 0;
}

int CascadeEncrypt(uint8_t* plaindata, int plaindata_len, char* password,
                   char* pbkdf_salt, int* pbkdf_iterations, uint8_t* aes_iv,
                   uint8_t* chacha20_iv, int* alpha_rounds, int* bravo_rounds,
                   uint8_t* output, int output_size)
{
  if (!plaindata || !password || !pbkdf_salt || !pbkdf_iterations || !aes_iv ||
      !chacha20_iv || !alpha_rounds || !bravo_rounds || !output)
    return -1;
  if (plaindata_len <= 0 || plaindata_len > OUTPUT_SIZE)
    return -1;
  if (strlen(password) == 0)
    return -1;
  if (*pbkdf_iterations <= 0 || *alpha_rounds <= 0 || *bravo_rounds <= 0)
    return -1;
  if (output_size < plaindata_len)
    return -1;

  uint8_t Keys[NUM_ALGOS][KEY_SIZE];
  uint8_t KeyHashs[NUM_ALGOS][KEY_HASH_SIZE];
  const char* KeySalts[NUM_ALGOS] = {
    "AES", "Chacha20", "Alpha", "Cocktail", "Bravo",
  };
  DeriveKeys(password, pbkdf_salt, pbkdf_iterations, Keys, KeyHashs, KeySalts,
             bVerifyEncryption);

  uint8_t* AesKey = Keys[0];
  uint8_t* Chacha20Key = Keys[1];
  uint8_t* AlphaKey = Keys[2];
  uint8_t* CocktailKey = Keys[3];
  uint8_t* BravoKey = Keys[4];

  uint8_t* AesKeyHash = KeyHashs[0];
  uint8_t* Chacha20KeyHash = KeyHashs[1];
  uint8_t* AlphaKeyHash = KeyHashs[2];
  uint8_t* CocktailKeyHash = KeyHashs[3];
  uint8_t* BravoKeyHash = KeyHashs[4];

  uint8_t* Input = plaindata;
  int InputSize = plaindata_len;

  DisplayText("Encrypting AES...");
  uint8_t AesOutput[OUTPUT_SIZE];
  ClearMemory(AesOutput, sizeof(AesOutput));
  VerifyKey(AesKey, AesKeyHash);
  int AesOutputLen =
    Bald_Aes_Cbc_Encrypt(Input, InputSize, AesKey, KEY_SIZE, aes_iv, 16,
                         AesOutput, sizeof(AesOutput));
  VERIFY(AesOutputLen > 0, "Cascade::AES encrypt error");
  ClearMemory(Input, InputSize);
  ClearMemory(AesKey, KEY_SIZE);
  ClearMemory(AesKeyHash, KEY_HASH_SIZE);
  ClearMemory(aes_iv, 16);
  Input = AesOutput;
  InputSize = AesOutputLen;

  DisplayText("Encrypting Chacha20...");
  uint8_t Chacha20Output[OUTPUT_SIZE];
  ClearMemory(Chacha20Output, sizeof(Chacha20Output));
  VerifyKey(Chacha20Key, Chacha20KeyHash);
  int Chacha20OutputLen =
    Bald_Chacha20_Encrypt(Input, InputSize, Chacha20Key, KEY_SIZE, chacha20_iv,
                          12, Chacha20Output, sizeof(Chacha20Output));
  VERIFY(Chacha20OutputLen > 0, "Cascade::Chacha20 encrypt error");
  ClearMemory(Input, InputSize);
  ClearMemory(Chacha20Key, KEY_SIZE);
  ClearMemory(Chacha20KeyHash, KEY_HASH_SIZE);
  ClearMemory(chacha20_iv, 12);
  Input = Chacha20Output;
  InputSize = Chacha20OutputLen;

  DisplayText("Encrypting Alpha...");
  uint8_t AlphaOutput[OUTPUT_SIZE];
  ClearMemory(AlphaOutput, sizeof(AlphaOutput));
  VerifyKey(AlphaKey, AlphaKeyHash);
  int AlphaOutputLen =
    Alpha_Encrypt(Input, InputSize, AlphaKey, KEY_SIZE, *alpha_rounds,
                  AlphaOutput, sizeof(AlphaOutput));
  VERIFY(AlphaOutputLen > 0, "Cascade::Alpha encrypt error");
  *alpha_rounds = 0;
  ClearMemory(Input, InputSize);
  ClearMemory(AlphaKey, KEY_SIZE);
  ClearMemory(AlphaKeyHash, KEY_HASH_SIZE);
  Input = AlphaOutput;
  InputSize = AlphaOutputLen;

  DisplayText("Encrypting Cocktail...");
  uint8_t CocktailOutput[OUTPUT_SIZE];
  ClearMemory(CocktailOutput, sizeof(CocktailOutput));
  VerifyKey(CocktailKey, CocktailKeyHash);
  int CocktailOutputLen =
    Cocktail_Encrypt(Input, InputSize, CocktailKey, KEY_SIZE, NULL, 0,
                     CocktailOutput, sizeof(CocktailOutput));
  VERIFY(CocktailOutputLen > 0, "Cascade::Cocktail encrypt error");
  ClearMemory(Input, InputSize);
  ClearMemory(CocktailKey, KEY_SIZE);
  ClearMemory(CocktailKeyHash, KEY_HASH_SIZE);
  Input = CocktailOutput;
  InputSize = CocktailOutputLen;

  DisplayText("Encrypting Bravo...");
  uint8_t BravoOutput[OUTPUT_SIZE];
  ClearMemory(BravoOutput, sizeof(BravoOutput));
  VerifyKey(BravoKey, BravoKeyHash);
  int BravoOutputLen =
    Bravo_Encrypt(Input, InputSize, BravoKey, KEY_SIZE, *bravo_rounds,
                  BravoOutput, sizeof(BravoOutput));
  VERIFY(BravoOutputLen > 0, "Cascade::Bravo encrypt error");
  *bravo_rounds = 0;
  ClearMemory(Input, InputSize);
  ClearMemory(BravoKey, KEY_SIZE);
  ClearMemory(BravoKeyHash, KEY_HASH_SIZE);
  // Input = BravoOutput;
  // InputSize = BravoOutputLen;

  if (BravoOutputLen > output_size)
    BravoOutputLen = -1;
  else
    memcpy(output, BravoOutput, BravoOutputLen);

  ClearMemory(BravoOutput, BravoOutputLen);

  return BravoOutputLen;
}

int CascadeDecrypt(const uint8_t* cipherdata, int cipherdata_len,
                   char* password, char* pbkdf_salt, int* pbkdf_iterations,
                   uint8_t* aes_iv, uint8_t* chacha20_iv, int* alpha_rounds,
                   int* bravo_rounds, uint8_t* output, int output_size)
{
  if (!cipherdata || !password || !pbkdf_salt || !pbkdf_iterations || !aes_iv ||
      !chacha20_iv || !alpha_rounds || !bravo_rounds || !output)
    return -1;
  if (cipherdata_len <= 0 || cipherdata_len > OUTPUT_SIZE)
    return -1;
  if (strlen(password) == 0)
    return -1;
  if (*pbkdf_iterations <= 0 || *alpha_rounds <= 0 || *bravo_rounds <= 0)
    return -1;
  if (output_size < cipherdata_len)
    return -1;

  uint8_t Keys[NUM_ALGOS][KEY_SIZE];
  uint8_t KeyHashs[NUM_ALGOS][KEY_HASH_SIZE];
  const char* KeySalts[NUM_ALGOS] = {
    "AES", "Chacha20", "Alpha", "Cocktail", "Bravo",
  };
  DeriveKeys(password, pbkdf_salt, pbkdf_iterations, Keys, KeyHashs, KeySalts,
             FALSE);

  uint8_t* AesKey = Keys[0];
  uint8_t* Chacha20Key = Keys[1];
  uint8_t* AlphaKey = Keys[2];
  uint8_t* CocktailKey = Keys[3];
  uint8_t* BravoKey = Keys[4];

  uint8_t* AesKeyHash = KeyHashs[0];
  uint8_t* Chacha20KeyHash = KeyHashs[1];
  uint8_t* AlphaKeyHash = KeyHashs[2];
  uint8_t* CocktailKeyHash = KeyHashs[3];
  uint8_t* BravoKeyHash = KeyHashs[4];

  const uint8_t* Input;
  size_t InputSize;

  Input = cipherdata;
  InputSize = cipherdata_len;

  DisplayText("Decrypting Bravo...");
  uint8_t BravoOutput[OUTPUT_SIZE];
  ClearMemory(BravoOutput, sizeof(BravoOutput));
  VerifyKey(BravoKey, BravoKeyHash);
  int BravoOutputLen =
    Bravo_Decrypt(Input, InputSize, BravoKey, KEY_SIZE, *bravo_rounds,
                  BravoOutput, sizeof(BravoOutput));
  VERIFY(BravoOutputLen > 0, "Cascade::Bravo decrypt error");
  *bravo_rounds = 0;
  ClearMemory(BravoKey, KEY_SIZE);
  ClearMemory(BravoKeyHash, KEY_HASH_SIZE);
  Input = BravoOutput;
  InputSize = BravoOutputLen;

  DisplayText("Decrypting Cocktail...");
  uint8_t CocktailOutput[OUTPUT_SIZE];
  ClearMemory(CocktailOutput, sizeof(CocktailOutput));
  VerifyKey(CocktailKey, CocktailKeyHash);
  int CocktailOutputLen =
    Cocktail_Decrypt(Input, InputSize, CocktailKey, KEY_SIZE, CocktailOutput,
                     sizeof(CocktailOutput));
  VERIFY(CocktailOutputLen > 0, "Cascade::Cocktail decrypt error");
  ClearMemory(CocktailKey, KEY_SIZE);
  ClearMemory(CocktailKeyHash, KEY_HASH_SIZE);
  Input = CocktailOutput;
  InputSize = CocktailOutputLen;

  DisplayText("Decrypting Alpha...");
  uint8_t AlphaOutput[OUTPUT_SIZE];
  ClearMemory(AlphaOutput, sizeof(AlphaOutput));
  VerifyKey(AlphaKey, AlphaKeyHash);
  int AlphaOutputLen =
    Alpha_Decrypt(Input, InputSize, AlphaKey, KEY_SIZE, *alpha_rounds,
                  AlphaOutput, sizeof(AlphaOutput));
  VERIFY(AlphaOutputLen > 0, "Cascade::Alpha decrypt error");
  *alpha_rounds = 0;
  ClearMemory(AlphaKey, KEY_SIZE);
  ClearMemory(AlphaKeyHash, KEY_HASH_SIZE);
  Input = AlphaOutput;
  InputSize = AlphaOutputLen;

  DisplayText("Decrypting Chacha20...");
  uint8_t Chacha20Output[OUTPUT_SIZE];
  ClearMemory(Chacha20Output, sizeof(Chacha20Output));
  VerifyKey(Chacha20Key, Chacha20KeyHash);
  int Chacha20OutputLen =
    Bald_Chacha20_Decrypt(Input, InputSize, Chacha20Key, KEY_SIZE, chacha20_iv,
                          Chacha20Output, sizeof(Chacha20Output));
  VERIFY(Chacha20OutputLen > 0, "Cascade::Chacha20 decrypt error");
  ClearMemory(Chacha20Key, KEY_SIZE);
  ClearMemory(Chacha20KeyHash, KEY_HASH_SIZE);
  Input = Chacha20Output;
  InputSize = Chacha20OutputLen;

  DisplayText("Decrypting AES...");
  uint8_t AesOutput[OUTPUT_SIZE];
  ClearMemory(AesOutput, sizeof(AesOutput));
  VerifyKey(AesKey, AesKeyHash);
  int AesOutputLen = Bald_Aes_Cbc_Decrypt(Input, InputSize, AesKey, KEY_SIZE,
                                          aes_iv, AesOutput, sizeof(AesOutput));
  VERIFY(AesOutputLen > 0, "Cascade::AES decrypt error");
  ClearMemory(AesKey, KEY_SIZE);
  ClearMemory(AesKeyHash, KEY_HASH_SIZE);
  // Input = AesOutput;
  // InputSize = AesOutputLen;

  if (AesOutputLen > output_size)
    AesOutputLen = -1;
  else
    memcpy(output, AesOutput, AesOutputLen);

  ClearMemory(AesOutput, AesOutputLen);

  return AesOutputLen;
}
