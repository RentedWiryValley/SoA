#pragma once

#include "basic_prng.h"

void Pcg32Init(const uint8_t* key, int key_len);
void Pcg32Deinit(void);
uint8_t Pcg32Rand8(void);
uint16_t Pcg32Rand16(void);
uint32_t Pcg32Rand32(void);
uint64_t Pcg32Rand64(void);
void Pcg32RandBuffer(uint8_t* buffer, int size);
void Pcg32RandXorBuffer(uint8_t* buffer, int size);
