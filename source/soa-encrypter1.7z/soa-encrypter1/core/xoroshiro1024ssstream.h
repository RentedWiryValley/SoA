#pragma once

#include "basic_prng.h"

void Xoroshiro1024ssInit(const uint8_t* key, int key_len);
void Xoroshiro1024ssDeinit(void);
uint8_t Xoroshiro1024ssRand8(void);
uint16_t Xoroshiro1024ssRand16(void);
uint32_t Xoroshiro1024ssRand32(void);
uint64_t Xoroshiro1024ssRand64(void);
void Xoroshiro1024ssRandBuffer(uint8_t* buffer, int size);
void Xoroshiro1024ssRandXorBuffer(uint8_t* buffer, int size);
