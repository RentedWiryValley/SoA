#pragma once

#include "basic_hash.h"

typedef struct _PBKDF3b_256_CTX
{
  uint8_t passhash[BYTES_256_BITS];
  uint8_t salthash[BYTES_256_BITS];
  int hashindex;
} PBKDF3b_256_CTX;

typedef struct _PBKDF3b_512_CTX
{
  uint8_t passhash[BYTES_512_BITS];
  uint8_t salthash[BYTES_512_BITS];
  int hashindex;
} PBKDF3b_512_CTX;

extern const PbkdfHashAlgo Pbkdf3b_256Hasher;
void Pbkdf3b_256_Init_Ctx(PBKDF3b_256_CTX* ctx, const uint8_t* input,
                          int input_len, const uint8_t* salt, int salt_len);
void Pbkdf3b_256_Update_Ctx(PBKDF3b_256_CTX* ctx, int iterations);
void Pbkdf3b_256_Final_Ctx(PBKDF3b_256_CTX* ctx, uint8_t* key);

void Pbkdf3b_256_Init(const uint8_t* input, int input_len, const uint8_t* salt,
                      int salt_len);
void Pbkdf3b_256_Update(int iterations);
void Pbkdf3b_256_Final(uint8_t* output);
void Pbkdf3b_256(const uint8_t* input, int input_len, const uint8_t* salt,
                 int salt_len, int iterations, uint8_t* output);

extern const PbkdfHashAlgo Pbkdf3b_512Hasher;
void Pbkdf3b_512_Init_Ctx(PBKDF3b_512_CTX* ctx, const uint8_t* input,
                          int input_len, const uint8_t* salt, int salt_len);
void Pbkdf3b_512_Update_Ctx(PBKDF3b_512_CTX* ctx, int iterations);
void Pbkdf3b_512_Final_Ctx(PBKDF3b_512_CTX* ctx, uint8_t* key);

void Pbkdf3b_512_Init(const uint8_t* input, int input_len, const uint8_t* salt,
                      int salt_len);
void Pbkdf3b_512_Update(int iterations);
void Pbkdf3b_512_Final(uint8_t* output);
void Pbkdf3b_512(const uint8_t* input, int input_len, const uint8_t* salt,
                 int salt_len, int iterations, uint8_t* output);
