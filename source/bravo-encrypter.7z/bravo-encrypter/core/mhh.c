#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mhh.h"

#include "common.h"

#define DISPLAY_UINT_TIMES 1048576

typedef struct _MHH_CTX
{
  const HashAlgo* Hasher;
  int64_t MemorySize;
} MHH_CTX;

static MHH_CTX mhh_ctx = {0};

static void MemoryHardHash(uint8_t* input_output)
{
  uint8_t* buffer = malloc(mhh_ctx.MemorySize);

  int64_t times = mhh_ctx.MemorySize / mhh_ctx.Hasher->OutputSize;

  char str[256];
  sprintf(str, "Generic Memory-Hard Hash with %s", mhh_ctx.Hasher->Name);

  uint8_t* bufferend = buffer + mhh_ctx.MemorySize;
  uint8_t* tempinput = bufferend - mhh_ctx.Hasher->OutputSize;
  memcpy(tempinput, input_output, mhh_ctx.Hasher->OutputSize);
  for (int64_t i = 0; i < times - 1; ++i)
  {
    if (i % DISPLAY_UINT_TIMES == 0)
      DisplayPercentage(str, 0.5f * i / times);
    uint64_t offset = *(uint64_t*)tempinput;
    offset %= bufferend - tempinput;
    uint8_t* randominputbyte = tempinput + offset;
    uint8_t* tempoutput = tempinput - mhh_ctx.Hasher->OutputSize;
    mhh_ctx.Hasher->InitFunc();
    mhh_ctx.Hasher->UpdateFunc(tempinput, mhh_ctx.Hasher->OutputSize);
    mhh_ctx.Hasher->UpdateFunc(randominputbyte, 1);
    mhh_ctx.Hasher->FinalFunc(tempoutput);
    tempinput = tempoutput;
  }

  mhh_ctx.Hasher->InitFunc();
  for (int64_t i = 0; i < times; ++i)
  {
    if (i % DISPLAY_UINT_TIMES == 0)
      DisplayPercentage(str, 0.5f + 0.5f * i / times);
    mhh_ctx.Hasher->UpdateFunc(tempinput, mhh_ctx.Hasher->OutputSize);
    tempinput += mhh_ctx.Hasher->OutputSize;
  }
  mhh_ctx.Hasher->FinalFunc(input_output);

  ClearMemory(buffer, mhh_ctx.MemorySize);

  DisplayPercentage(str, 1);

  ClearMemory(str, sizeof(str));

  free(buffer);
}

void Mhh_Init(const HashAlgo* hasher, int64_t memory_size)
{
  VERIFY(hasher != NULL, "Bad MHH hasher");
  if (memory_size % hasher->OutputSize)
    memory_size = (memory_size / hasher->OutputSize + 1) * hasher->OutputSize;
  VERIFY(memory_size > 0, "Bad MHH memory size");
  mhh_ctx.Hasher = hasher;
  mhh_ctx.MemorySize = memory_size;
  mhh_ctx.Hasher->InitFunc();
}

void Mhh_Update(const uint8_t* input, int input_len)
{
  VERIFY(mhh_ctx.Hasher, "MHH not initialized");
  mhh_ctx.Hasher->UpdateFunc(input, input_len);
}

void Mhh_Final(uint8_t* output)
{
  VERIFY(mhh_ctx.Hasher, "MHH not initialized");
  mhh_ctx.Hasher->FinalFunc(output);
  MemoryHardHash(output);
  ClearMemory(&mhh_ctx, sizeof(mhh_ctx));
}

void Mhh(const HashAlgo* hasher, int64_t memory_size, const uint8_t* input,
         int input_len, uint8_t* output)
{
  Mhh_Init(hasher, memory_size);
  Mhh_Update(input, input_len);
  Mhh_Final(output);
}
