#pragma once

#include "mhh.h"

// Generic Memory-Hard KDF
void Mhkdf(const HashAlgo* algos[], int algo_count, int64_t memory_size,
           const uint8_t* input, int input_len, const uint8_t* salt,
           int salt_len, int rounds, uint8_t* output);
