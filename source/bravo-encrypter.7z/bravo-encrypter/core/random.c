#include <unistd.h>

#include "random.h"

#include "bufferedstream.h"
#include "common.h"
#include "hash.h"
#include "memxor.h"

#define HASH_SIZE 64
#define RANDOM_BUFFER_SIZE HASH_SIZE

#define ENTROPY_BITS_PER_SAMPLE 6
#define NUM_SOURCES \
  ((int)(sizeof(RandomHashFuncs) / sizeof(RandomHashFuncs[0])))
#define TOTAL_ENTROPY_BITS (HASH_SIZE * 8)
#define NUM_SAMPLES_PER_SOURCE \
  (TOTAL_ENTROPY_BITS / ENTROPY_BITS_PER_SAMPLE / NUM_SOURCES + 1)

static void GenerateRandomStream(void);

static BufferedStream RandomStream = {.Size = RANDOM_BUFFER_SIZE,
                                      .Index = RANDOM_BUFFER_SIZE,
                                      .Refresh = GenerateRandomStream};

static HashFunc RandomHashFuncs[] = {Blake2b_512, Blake3_512, Sha2_512,
                                     Sha3_512,    Skein_512,  Whirlpool};

static void GenerateRandomStream(void)
{
  ClearMemory(RandomStream.Buffer, sizeof(RandomStream.Size));

  long SourceBuffer[NUM_SAMPLES_PER_SOURCE];
  uint8_t Hash[HASH_SIZE];

  for (int i = 0; i < NUM_SOURCES; ++i)
  {
    for (int j = 0; j < NUM_SAMPLES_PER_SOURCE; ++j)
    {
      usleep(1);
      SourceBuffer[j] = GetTime();
    }
    RandomHashFuncs[i]((uint8_t*)SourceBuffer, sizeof(SourceBuffer), Hash);
    memxor(RandomStream.Buffer, Hash, HASH_SIZE);
  }

  ClearMemory(SourceBuffer, sizeof(SourceBuffer));
  ClearMemory(Hash, sizeof(Hash));
}

uint8_t SoftwareRandom8(void)
{
  uint8_t r = Extract8(&RandomStream);
  return r;
}

uint16_t SoftwareRandom16(void)
{
  uint16_t r = Extract16(&RandomStream);
  return r;
}

uint32_t SoftwareRandom32(void)
{
  uint32_t r = Extract32(&RandomStream);
  return r;
}

uint64_t SoftwareRandom64(void)
{
  uint64_t r = Extract64(&RandomStream);
  return r;
}

void SoftwareRandomBuffer(uint8_t* buffer, size_t size)
{
  if (!buffer || size <= 0)
    return;
  ExtractToBuffer(&RandomStream, buffer, size);
}
