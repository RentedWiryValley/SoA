#include "pcg32stream.h"

#include "bufferedstream.h"
#include "hash.h"

#include "pcg_variants.h"

const PrngAlgo Pcg32Prng = {.InitFunc = Pcg32Init,
                            .DeinitFunc = Pcg32Deinit,
                            .GetUint8Func = Pcg32Rand8,
                            .GetUint16Func = Pcg32Rand16,
                            .GetUint32Func = Pcg32Rand32,
                            .GetUint64Func = Pcg32Rand64,
                            .BufferFunc = Pcg32RandBuffer,
                            .XorBufferFunc = Pcg32RandXorBuffer};

void GeneratePcg32Stream(void);

static BufferedStream Pcg32BufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GeneratePcg32Stream};

static pcg32_random_t Ctx = {0};
static BOOL Pcg32Initialized = FALSE;

void Pcg32Init(const uint8_t* key, int key_len)
{
  VERIFY(!Pcg32Initialized, "PCG32 already initialized");
  VERIFY(key && key_len > 0, "Bad PCG32 key!");

  uint8_t hash[BYTES_256_BITS];
  Sha2_256(key, key_len, hash);

  pcg32_srandom_r(&Ctx, *((uint64_t*)hash),
                  *((uint64_t*)(hash + sizeof(uint64_t))));

  Pcg32BufferedStream.Index = Pcg32BufferedStream.Size;

  Pcg32Initialized = TRUE;
}

void Pcg32Deinit(void)
{
  VERIFY(Pcg32Initialized, "PCG32 not initialized");

  Pcg32BufferedStream.Index = Pcg32BufferedStream.Size;

  Pcg32Initialized = FALSE;
}

void GeneratePcg32Stream(void)
{
  VERIFY(Pcg32Initialized, "PCG32 not initialized");

  uint32_t* p = (uint32_t*)Pcg32BufferedStream.Buffer;
  for (int i = 0; i < Pcg32BufferedStream.Size / (int)sizeof(uint32_t); ++i)
  {
    *p = pcg32_random_r(&Ctx);
    ++p;
  }
}

uint8_t Pcg32Rand8(void)
{
  uint8_t r = Extract8(&Pcg32BufferedStream);
  return r;
}

uint16_t Pcg32Rand16(void)
{
  uint16_t r = Extract16(&Pcg32BufferedStream);
  return r;
}

uint32_t Pcg32Rand32(void)
{
  uint32_t r = Extract32(&Pcg32BufferedStream);
  return r;
}

uint64_t Pcg32Rand64(void)
{
  uint64_t r = Extract64(&Pcg32BufferedStream);
  return r;
}

void Pcg32RandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Pcg32BufferedStream, buffer, size);
}

void Pcg32RandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Pcg32BufferedStream, buffer, size);
}
