#include <stdio.h>
#include <string.h>

#include "memxor.h"
#include "mhkdf.h"

static void MhkdfSingleRound(const HashAlgo* algos[], int algo_count,
                             int64_t memory_size, const uint8_t* input,
                             int input_len, const uint8_t* salt, int salt_len,
                             uint8_t* output, int output_len)
{
  ClearMemory(output, output_len);

  uint8_t hash[BYTES_1024_BITS];

  for (int i = 0; i < algo_count; ++i)
  {
    const HashAlgo* algo = algos[i];

    algo->InitFunc();
    algo->UpdateFunc(input, input_len);
    algo->UpdateFunc(salt, salt_len);
    algo->UpdateFunc(output, output_len);
    algo->FinalFunc(hash);

    Mhh(algo, memory_size, hash, output_len, hash);

    memxor(output, hash, output_len);
  }

  ClearMemory(hash, sizeof(hash));
}

void Mhkdf(const HashAlgo* algos[], int algo_count, int64_t memory_size,
           const uint8_t* input, int input_len, const uint8_t* salt,
           int salt_len, int rounds, uint8_t* output)
{
  VERIFY(algos && algo_count >= 2, "Bad MHKDF algos!");
  int size = algos[0]->OutputSize;
  for (int i = 1; i < algo_count; ++i)
    VERIFY((int)algos[i]->OutputSize == size, "Mismatched MHKDF hash sizes!");
  VERIFY(rounds > 0, "Bad MHKDF rounds");

  uint8_t hash[BYTES_1024_BITS];

  for (int i = 0; i < rounds; ++i)
  {
    printf("MHKDF round %d of %d:\n", i + 1, rounds);
    MhkdfSingleRound(algos, algo_count, memory_size, input, input_len, salt,
                     salt_len, output, size);
    memcpy(hash, output, size);
    input = hash;
    input_len = size;
  }

  ClearMemory(hash, sizeof(hash));
}
