#pragma once

#include "basic_hash.h"

// Generic Memory-Hard Hash
void Mhh_Init(const HashAlgo* hasher, int64_t memory_size);
void Mhh_Update(const uint8_t* input, int input_len);
void Mhh_Final(uint8_t* output);
void Mhh(const HashAlgo* hasher, int64_t memory_size, const uint8_t* input,
         int input_len, uint8_t* output);
