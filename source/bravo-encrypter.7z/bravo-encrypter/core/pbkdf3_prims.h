#pragma once

#include "hash.h"

// 256-bit

#define MainHasher256 Blake2s256Hasher

// 512-bit

#define MainHasher512 xBlake2s512Hasher
