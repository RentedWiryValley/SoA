#include "xoroshiro512ssstream.h"
#include "xoroshiro512.h"

#include "bufferedstream.h"
#include "hash.h"

const PrngAlgo Xoroshiro512ssPrng = {
  .InitFunc = Xoroshiro512ssInit,
  .DeinitFunc = Xoroshiro512ssDeinit,
  .GetUint8Func = Xoroshiro512ssRand8,
  .GetUint16Func = Xoroshiro512ssRand16,
  .GetUint32Func = Xoroshiro512ssRand32,
  .GetUint64Func = Xoroshiro512ssRand64,
  .BufferFunc = Xoroshiro512ssRandBuffer,
  .XorBufferFunc = Xoroshiro512ssRandXorBuffer};

void GenerateXoroshiro512ssStream(void);

static BufferedStream Xoroshiro512ssBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro512ssStream};

static Xoroshiro512Ctx Ctx = {0};
static BOOL Xoroshiro512ssInitialized = FALSE;

static uint64_t Xoroshiro512ssNext(void)
{
  const uint64_t result = rotl64(Ctx.s[1] * 5, 7) * 9;

  const uint64_t t = Ctx.s[1] << 11;

  Ctx.s[2] ^= Ctx.s[0];
  Ctx.s[5] ^= Ctx.s[1];
  Ctx.s[1] ^= Ctx.s[2];
  Ctx.s[7] ^= Ctx.s[3];
  Ctx.s[3] ^= Ctx.s[4];
  Ctx.s[4] ^= Ctx.s[5];
  Ctx.s[0] ^= Ctx.s[6];
  Ctx.s[6] ^= Ctx.s[7];

  Ctx.s[6] ^= t;

  Ctx.s[7] = rotl64(Ctx.s[7], 21);

  return result;
}

void Xoroshiro512ssInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro512ssInitialized, "Xoroshiro512** already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro512** key!");

  Blake2b_512(key, key_len, (uint8_t*)Ctx.s);

  Xoroshiro512ssBufferedStream.Index = Xoroshiro512ssBufferedStream.Size;

  Xoroshiro512ssInitialized = TRUE;
}

void Xoroshiro512ssDeinit(void)
{
  VERIFY(Xoroshiro512ssInitialized, "Xoroshiro512** not initialized");

  Xoroshiro512ssBufferedStream.Index = Xoroshiro512ssBufferedStream.Size;

  Xoroshiro512ssInitialized = FALSE;
}

void GenerateXoroshiro512ssStream(void)
{
  VERIFY(Xoroshiro512ssInitialized, "Xoroshiro512** not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro512ssBufferedStream.Buffer;
  for (int i = 0; i < Xoroshiro512ssBufferedStream.Size / (int)sizeof(uint64_t);
       ++i)
  {
    *p = Xoroshiro512ssNext();
    ++p;
  }
}

uint8_t Xoroshiro512ssRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro512ssBufferedStream);
  return r;
}

uint16_t Xoroshiro512ssRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro512ssBufferedStream);
  return r;
}

uint32_t Xoroshiro512ssRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro512ssBufferedStream);
  return r;
}

uint64_t Xoroshiro512ssRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro512ssBufferedStream);
  return r;
}

void Xoroshiro512ssRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro512ssBufferedStream, buffer, size);
}

void Xoroshiro512ssRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro512ssBufferedStream, buffer, size);
}
