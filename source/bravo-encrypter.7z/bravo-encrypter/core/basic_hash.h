#pragma once

#include "basics.h"

typedef enum _EHashOutputSize
{
  Bytes64Bits = BYTES_64_BITS,
  Bytes128Bits = BYTES_128_BITS,
  Bytes256Bits = BYTES_256_BITS,
  Bytes512Bits = BYTES_512_BITS,
  Bytes1024Bits = BYTES_1024_BITS,
} EHashOutputBits;

typedef void (*HashInitFunc)(void);
typedef void (*HashUpdateFunc)(const uint8_t* input, int input_len);
typedef void (*HashFinalFunc)(uint8_t* output);
typedef void (*HashFunc)(const uint8_t* input, int input_len, uint8_t* output);

typedef struct _HashAlgo
{
  EHashOutputBits OutputSize;
  HashInitFunc InitFunc;
  HashUpdateFunc UpdateFunc;
  HashFinalFunc FinalFunc;
  HashFunc HashFunc;
  const char* Name;
} HashAlgo;

typedef void (*KeyedHashFunc)(const uint8_t*, int, const uint8_t*, int,
                              uint8_t*);

typedef struct _KeyedHashAlgo
{
  EHashOutputBits OutputSize;
  KeyedHashFunc KeyedHashFunc;
} KeyedHashAlgo;

typedef void (*PbkdfHashInitFunc)(const uint8_t* input, int input_len,
                                  const uint8_t* salt, int salt_len);
typedef void (*PbkdfHashUpdateFunc)(int iterations);
typedef void (*PbkdfHashFinalFunc)(uint8_t* output);
typedef void (*PbkdfHashFunc)(const uint8_t* input, int input_len,
                              const uint8_t* salt, int salt_len, int iterations,
                              uint8_t* output);

typedef struct _PbkdfHashAlgo
{
  EHashOutputBits OutputSize;
  PbkdfHashInitFunc InitFunc;
  PbkdfHashUpdateFunc UpdateFunc;
  PbkdfHashFinalFunc FinalFunc;
  PbkdfHashFunc HashFunc;
} PbkdfHashAlgo;
