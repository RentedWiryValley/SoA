#pragma once

#include "basic_hash.h"

//// Regular hash

extern const HashAlgo Siphash128Hasher;

extern const HashAlgo Blake2b256Hasher;
extern const HashAlgo Blake2s256Hasher;
extern const HashAlgo Blake3_256Hasher;
extern const HashAlgo Sha2_256Hasher;
extern const HashAlgo Sha3_256Hasher;
extern const HashAlgo Skein256Hasher;
// unoriginal; extended from 128-bit algos with keys
extern const HashAlgo xSiphash256Hasher;

extern const HashAlgo Blake2b512Hasher;
extern const HashAlgo Blake3_512Hasher;
extern const HashAlgo Sha2_512Hasher;
extern const HashAlgo Sha3_512Hasher;
extern const HashAlgo Skein512Hasher;
extern const HashAlgo WhirlpoolHasher;
// unoriginal; extended from 256-bit algos with keys
extern const HashAlgo xBlake2s512Hasher;

extern const HashAlgo Blake3_1024Hasher;
extern const HashAlgo Skein1024Hasher;
// unoriginal; extended from 512-bit algos with keys
extern const HashAlgo xBlake2b1024Hasher;
extern const HashAlgo xSha2_1024Hasher;
extern const HashAlgo xSha3_1024Hasher;
extern const HashAlgo xWhirlpool1024Hasher;

// Regular: 128-bit

void Siphash_128(const uint8_t* input, int input_len, uint8_t* output);

// Regular: 256-bit

void Blake2b_256_Init(void);
void Blake2b_256_Update(const uint8_t* input, int input_len);
void Blake2b_256_Final(uint8_t* output);
void Blake2b_256(const uint8_t* input, int input_len, uint8_t* output);

void Blake2s_256_Init(void);
void Blake2s_256_Update(const uint8_t* input, int input_len);
void Blake2s_256_Final(uint8_t* output);
void Blake2s_256(const uint8_t* input, int input_len, uint8_t* output);

void Blake3_256_Init(void);
void Blake3_256_Update(const uint8_t* input, int input_len);
void Blake3_256_Final(uint8_t* output);
void Blake3_256(const uint8_t* input, int input_len, uint8_t* output);

void Sha2_256_Init(void);
void Sha2_256_Update(const uint8_t* input, int input_len);
void Sha2_256_Final(uint8_t* output);
void Sha2_256(const uint8_t* input, int input_len, uint8_t* output);

void Sha3_256_Init(void);
void Sha3_256_Update(const uint8_t* input, int input_len);
void Sha3_256_Final(uint8_t* output);
void Sha3_256(const uint8_t* input, int input_len, uint8_t* output);

void Skein_256_Init_(void);
void Skein_256_Update_(const uint8_t* input, int input_len);
void Skein_256_Final_(uint8_t* output);
void Skein_256(const uint8_t* input, int input_len, uint8_t* output);

void xSiphash_256(const uint8_t* input, int input_len, uint8_t* output);

// Regular: 512-bit

void Blake2b_512_Init(void);
void Blake2b_512_Update(const uint8_t* input, int input_len);
void Blake2b_512_Final(uint8_t* output);
void Blake2b_512(const uint8_t* input, int input_len, uint8_t* output);

void Blake3_512_Init(void);
void Blake3_512_Update(const uint8_t* input, int input_len);
void Blake3_512_Final(uint8_t* output);
void Blake3_512(const uint8_t* input, int input_len, uint8_t* output);

void Sha2_512_Init(void);
void Sha2_512_Update(const uint8_t* input, int input_len);
void Sha2_512_Final(uint8_t* output);
void Sha2_512(const uint8_t* input, int input_len, uint8_t* output);

void Sha3_512_Init(void);
void Sha3_512_Update(const uint8_t* input, int input_len);
void Sha3_512_Final(uint8_t* output);
void Sha3_512(const uint8_t* input, int input_len, uint8_t* output);

void Skein_512_Init_(void);
void Skein_512_Update_(const uint8_t* input, int input_len);
void Skein_512_Final_(uint8_t* output);
void Skein_512(const uint8_t* input, int input_len, uint8_t* output);

void Whirlpool_Init(void);
void Whirlpool_Update(const uint8_t* input, int input_len);
void Whirlpool_Final(uint8_t* output);
void Whirlpool(const uint8_t* input, int input_len, uint8_t* output);

void xBlake2s_512_Init(void);
void xBlake2s_512_Update(const uint8_t* input, int input_len);
void xBlake2s_512_Final(uint8_t* output);
void xBlake2s_512(const uint8_t* input, int input_len, uint8_t* output);

// Regular: 1024-bit

void Blake3_1024_Init(void);
void Blake3_1024_Update(const uint8_t* input, int input_len);
void Blake3_1024_Final(uint8_t* output);
void Blake3_1024(const uint8_t* input, int input_len, uint8_t* output);

void Skein_1024_Init_(void);
void Skein_1024_Update_(const uint8_t* input, int input_len);
void Skein_1024_Final_(uint8_t* output);
void Skein_1024(const uint8_t* input, int input_len, uint8_t* output);

void xBlake2b_1024_Init(void);
void xBlake2b_1024_Update(const uint8_t* input, int input_len);
void xBlake2b_1024_Final(uint8_t* output);
void xBlake2b_1024(const uint8_t* input, int input_len, uint8_t* output);

void xSha2_1024_Init(void);
void xSha2_1024_Update(const uint8_t* input, int input_len);
void xSha2_1024_Final(uint8_t* output);
void xSha2_1024(const uint8_t* input, int input_len, uint8_t* output);

void xSha3_1024_Init(void);
void xSha3_1024_Update(const uint8_t* input, int input_len);
void xSha3_1024_Final(uint8_t* output);
void xSha3_1024(const uint8_t* input, int input_len, uint8_t* output);

void xWhirlpool_1024_Init(void);
void xWhirlpool_1024_Update(const uint8_t* input, int input_len);
void xWhirlpool_1024_Final(uint8_t* output);
void xWhirlpool_1024(const uint8_t* input, int input_len, uint8_t* output);

//// Keyed-hash

extern const KeyedHashAlgo Blake2b256KeyedHasher;
extern const KeyedHashAlgo Blake2s256KeyedHasher;
extern const KeyedHashAlgo Blake3_256KeyedHasher;
extern const KeyedHashAlgo Skein256KeyedHasher;

extern const KeyedHashAlgo Blake2b512KeyedHasher;
extern const KeyedHashAlgo Blake3_512KeyedHasher;
extern const KeyedHashAlgo Skein512KeyedHasher;

// Keyed: 256-bit

void Keyed_Blake2b_256(const uint8_t* input, int input_len, const uint8_t* key,
                       int key_len, uint8_t* output);

void Keyed_Blake2s_256(const uint8_t* input, int input_len, const uint8_t* key,
                       int key_len, uint8_t* output);

void Keyed_Blake3_256(const uint8_t* input, int input_len, const uint8_t* key,
                      int key_len, uint8_t* output);

void Keyed_Skein_256(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output);

// Keyed: 512-bit

void Keyed_Blake2b_512(const uint8_t* input, int input_len, const uint8_t* key,
                       int key_len, uint8_t* output);

void Keyed_Blake3_512(const uint8_t* input, int input_len, const uint8_t* key,
                      int key_len, uint8_t* output);

void Keyed_Skein_512(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output);

//// PBKDF

void Pbkdf_Display_Progress(const PbkdfHashAlgo* pbkdf, const uint8_t* input,
                            int input_len, const uint8_t* salt, int salt_len,
                            int iterations, uint8_t* output, const char* title);
