#include <string.h>

#include "isaac64stream.h"

#include "bufferedstream.h"
#include "isaac/isaac64.h"

/*
Differences between ISAAC64 Buffered Stream and rand() of the original ISAAC64:
1. The former reads the buffer from zero up, while the latter does it
   from RANDSIZ-1 down.
2. ISAAC64 Buffered Stream does not touch randcnt.
*/

const PrngAlgo Isaac64Csprng = {.InitFunc = Isaac64Init,
                                .DeinitFunc = Isaac64Deinit,
                                .GetUint8Func = Isaac64Rand8,
                                .GetUint16Func = Isaac64Rand16,
                                .GetUint32Func = Isaac64Rand32,
                                .GetUint64Func = Isaac64Rand64,
                                .BufferFunc = Isaac64RandBuffer,
                                .XorBufferFunc = Isaac64RandXorBuffer};

#define ISAAC64_BUFFER_SIZE (int)sizeof(((isaac64ctx*)0)->randrsl)

void GenerateIsaac64Stream(void);

static BufferedStream Isaac64BufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateIsaac64Stream};

static isaac64ctx Isaac64Ctx = {0};
static int Isaac64RandrslIndex = 0;
static BOOL Isaac64Initialized = FALSE;

void Isaac64Init(const uint8_t* key, int key_len)
{
  VERIFY(!Isaac64Initialized, "ISAAC64 already initialized");
  VERIFY(key && key_len > 0, "Bad ISAAC64 key!");

  key_len = key_len > ISAAC64_BUFFER_SIZE ? ISAAC64_BUFFER_SIZE : key_len;

  ClearMemory(Isaac64Ctx.randrsl, ISAAC64_BUFFER_SIZE);
  memcpy(&Isaac64Ctx.randrsl, key, key_len);
  isaac64init(&Isaac64Ctx, TRUE);

  memcpy(Isaac64BufferedStream.Buffer, Isaac64Ctx.randrsl,
         MAX_BUFFEREDSTREAM_BUFFER_SIZE);
  Isaac64BufferedStream.Index = 0;

  Isaac64RandrslIndex = MAX_BUFFEREDSTREAM_BUFFER_SIZE;

  Isaac64Initialized = TRUE;
}

void Isaac64Deinit(void)
{
  VERIFY(Isaac64Initialized, "ISAAC64 not initialized");

  Isaac64Initialized = FALSE;
}

void GenerateIsaac64Stream(void)
{
  VERIFY(Isaac64Initialized, "ISAAC64 not initialized");

  if (Isaac64RandrslIndex >= ISAAC64_BUFFER_SIZE)
  {
    isaac64update(&Isaac64Ctx);
    Isaac64RandrslIndex = 0;
  }

  memcpy(Isaac64BufferedStream.Buffer,
         ((uint8_t*)Isaac64Ctx.randrsl) + Isaac64RandrslIndex,
         MAX_BUFFEREDSTREAM_BUFFER_SIZE);

  Isaac64RandrslIndex += MAX_BUFFEREDSTREAM_BUFFER_SIZE;
}

uint8_t Isaac64Rand8(void)
{
  uint8_t r = Extract8(&Isaac64BufferedStream);
  return r;
}

uint16_t Isaac64Rand16(void)
{
  uint16_t r = Extract16(&Isaac64BufferedStream);
  return r;
}

uint32_t Isaac64Rand32(void)
{
  uint32_t r = Extract32(&Isaac64BufferedStream);
  return r;
}

uint64_t Isaac64Rand64(void)
{
  uint64_t r = Extract64(&Isaac64BufferedStream);
  return r;
}

void Isaac64RandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Isaac64BufferedStream, buffer, size);
}

void Isaac64RandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Isaac64BufferedStream, buffer, size);
}
