#include "xoroshiro512ppstream.h"
#include "xoroshiro512.h"

#include "bufferedstream.h"
#include "hash.h"

const PrngAlgo Xoroshiro512ppPrng = {
  .InitFunc = Xoroshiro512ppInit,
  .DeinitFunc = Xoroshiro512ppDeinit,
  .GetUint8Func = Xoroshiro512ppRand8,
  .GetUint16Func = Xoroshiro512ppRand16,
  .GetUint32Func = Xoroshiro512ppRand32,
  .GetUint64Func = Xoroshiro512ppRand64,
  .BufferFunc = Xoroshiro512ppRandBuffer,
  .XorBufferFunc = Xoroshiro512ppRandXorBuffer};

void GenerateXoroshiro512ppStream(void);

static BufferedStream Xoroshiro512ppBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro512ppStream};

static Xoroshiro512Ctx Ctx = {0};
static BOOL Xoroshiro512ppInitialized = FALSE;

static uint64_t Xoroshiro512ppNext(void)
{
  const uint64_t result = rotl64(Ctx.s[0] + Ctx.s[2], 17) + Ctx.s[2];

  const uint64_t t = Ctx.s[1] << 11;

  Ctx.s[2] ^= Ctx.s[0];
  Ctx.s[5] ^= Ctx.s[1];
  Ctx.s[1] ^= Ctx.s[2];
  Ctx.s[7] ^= Ctx.s[3];
  Ctx.s[3] ^= Ctx.s[4];
  Ctx.s[4] ^= Ctx.s[5];
  Ctx.s[0] ^= Ctx.s[6];
  Ctx.s[6] ^= Ctx.s[7];

  Ctx.s[6] ^= t;

  Ctx.s[7] = rotl64(Ctx.s[7], 21);

  return result;
}

void Xoroshiro512ppInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro512ppInitialized, "Xoroshiro512++ already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro512++ key!");

  Sha2_512(key, key_len, (uint8_t*)Ctx.s);

  Xoroshiro512ppBufferedStream.Index = Xoroshiro512ppBufferedStream.Size;

  Xoroshiro512ppInitialized = TRUE;
}

void Xoroshiro512ppDeinit(void)
{
  VERIFY(Xoroshiro512ppInitialized, "Xoroshiro512++ not initialized");

  Xoroshiro512ppBufferedStream.Index = Xoroshiro512ppBufferedStream.Size;

  Xoroshiro512ppInitialized = FALSE;
}

void GenerateXoroshiro512ppStream(void)
{
  VERIFY(Xoroshiro512ppInitialized, "Xoroshiro512++ not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro512ppBufferedStream.Buffer;
  for (int i = 0; i < Xoroshiro512ppBufferedStream.Size / (int)sizeof(uint64_t);
       ++i)
  {
    *p = Xoroshiro512ppNext();
    ++p;
  }
}

uint8_t Xoroshiro512ppRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro512ppBufferedStream);
  return r;
}

uint16_t Xoroshiro512ppRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro512ppBufferedStream);
  return r;
}

uint32_t Xoroshiro512ppRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro512ppBufferedStream);
  return r;
}

uint64_t Xoroshiro512ppRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro512ppBufferedStream);
  return r;
}

void Xoroshiro512ppRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro512ppBufferedStream, buffer, size);
}

void Xoroshiro512ppRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro512ppBufferedStream, buffer, size);
}
