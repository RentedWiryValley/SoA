#pragma once

#include "hash.h"
#include "prng.h"

static const HashAlgo* CocktailHashs[] = {
  &Sha3_512Hasher,
  &Blake3_512Hasher,
  &WhirlpoolHasher,
  &Skein512Hasher,
  &Blake2b512Hasher,
  &Sha2_512Hasher,
};
static const PrngAlgo* CocktailPrngs[] = {
  &IsaacCsprng,
  &Pcg64Prng,
  &Xoroshiro512ppPrng,
};
static const HashAlgo* CocktailKeyHash = &Sha3_256Hasher;
