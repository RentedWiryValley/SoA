#pragma once

#include "hash.h"
#include "pbkdf3.h"

static const PbkdfHashAlgo* CascadeMasterKeyPbkdfHasher = &Pbkdf3_512Hasher;

static const PbkdfHashAlgo* CascadeKeyPbkdfHashers[] = {
  &Pbkdf3_512Hasher,
  &Pbkdf3_512Hasher,
  &Pbkdf3_512Hasher,
  &Pbkdf3_512Hasher,
};

static const HashFunc CascadeKeyHashFuncs[] = {
  Whirlpool,
  Sha2_512,
  Blake2b_512,
  Skein_512,
};
