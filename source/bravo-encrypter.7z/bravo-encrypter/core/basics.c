#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "basics.h"

void ClearMemory(void* buffer, size_t buffer_len)
{
  memset(buffer, 0, buffer_len);
}

void __attribute__((noreturn)) Exit(const char* message)
{
  printf("%s\n", message);
  exit(-1);
}
