/*
------------------------------------------------------------------------------
isaac64.h: definitions for a random number generator
Bob Jenkins, 1996, Public Domain
------------------------------------------------------------------------------
*/
#ifndef ISAAC_STANDARD
#include "standard.h"
#endif

#ifndef ISAAC64
#define ISAAC64

#define RANDSIZL   (8)
#define RANDSIZ    (1<<RANDSIZL)

/* context of random number generator */
struct isaac64ctx
{
  ub8 randcnt;
  ub8 randrsl[RANDSIZ];
  ub8 randmem[RANDSIZ];
  ub8 randa;
  ub8 randb;
  ub8 randc;
};
typedef  struct isaac64ctx  isaac64ctx;

/*
------------------------------------------------------------------------------
 If (flag==TRUE), then use the contents of randrsl[0..255] as the seed.
------------------------------------------------------------------------------
*/
void isaac64init(isaac64ctx *r, word flag);

void isaac64update(isaac64ctx *r);


/*
------------------------------------------------------------------------------
 Call rand() to retrieve a single 64-bit random value
------------------------------------------------------------------------------
*/
#define isaac64rand() \
  (!randcnt-- ? (isaac64update(), randcnt=RANDSIZ-1, randrsl[randcnt]) : \
                randrsl[randcnt])

#endif  /* ISAAC64 */

