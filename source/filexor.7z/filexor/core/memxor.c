#include "memxor.h"

void memxor(void* out, const void* in, int bytes)
{
  if (!out || !in || bytes <= 0)
    return;
  uint64_t* out64 = (uint64_t*)out;
  const uint64_t* in64 = (const uint64_t*)in;
  while (bytes >= (int)sizeof(uint64_t))
  {
    *out64 ^= *in64;
    ++out64;
    ++in64;
    bytes -= sizeof(uint64_t);
  }
  uint32_t* out32 = (uint32_t*)out64;
  const uint32_t* in32 = (const uint32_t*)in64;
  if (bytes >= (int)sizeof(uint32_t))
  {
    *out32 ^= *in32;
    ++out32;
    ++in32;
    bytes -= sizeof(uint32_t);
  }
  uint16_t* out16 = (uint16_t*)out32;
  const uint16_t* in16 = (const uint16_t*)in32;
  if (bytes >= (int)sizeof(uint16_t))
  {
    *out16 ^= *in16;
    ++out16;
    ++in16;
    bytes -= sizeof(uint16_t);
  }
  uint8_t* out8 = (uint8_t*)out16;
  const uint8_t* in8 = (const uint8_t*)in16;
  if (bytes >= (int)sizeof(uint8_t))
  {
    *out8 ^= *in8;
  }
}
