#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "basics.h"

void ClearMemory(void* buffer, size_t buffer_len)
{
  memset(buffer, 0, buffer_len);
}

void __attribute__((noreturn)) Exit(const char* message)
{
  printf("%s\n", message);
  exit(-1);
}

void __attribute__((noreturn)) Exit2(const char* message1, const char* message2)
{
  if (message1 && message2)
    printf("%s (%s)\n", message1, message2);
  else if (message1)
    printf("%s\n", message1);
  else if (message2)
    printf("(%s)\n", message2);
  exit(-1);
}
