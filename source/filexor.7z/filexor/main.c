#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "memxor.h"
#include "utils.h"

void DisplayUsage(const char* path)
{
  char* file = strrchr(path, '/');
  if (file)
    ++file;
  else
    file = "filexor";
  printf("Usage: %s\n", file);
  printf("For security reason, %s does not support command line parameters.\n",
         file);
  printf("Enter '*' to finish adding mask files.\n");
}

uint8_t* ReadFile(const char* path, int* size)
{
  FILE* fp = fopen(path, "rb");
  VERIFY2(fp, "Failed to open input/mask file", path);

  int s = fseek(fp, 0, SEEK_END);
  VERIFY2(s == 0, "Failed to fseek in input/mask file", path);

  long t = ftell(fp);
  VERIFY2(t != -1, "Failed to ftell in input/mask file", path);

  *size = (int)t;

  rewind(fp);

  uint8_t* buffer = malloc(t);

  int read = fread(buffer, 1, t, fp);
  VERIFY2(read == t, "Error reading input/mask file", path);

  fclose(fp);

  return buffer;
}

void CircularShiftLeft(uint8_t* buffer, int size, int shiftbits)
{
  {
    int totalbits = size * 8;
    shiftbits %= totalbits;
  }

  if (shiftbits == 0)
    return;

  uint8_t* temp = malloc(size);

  {
    int shiftbytes = shiftbits / 8;
    memcpy(temp, buffer + shiftbytes, size - shiftbytes);
    if (shiftbytes > 0)
      memcpy(temp + size - shiftbytes, buffer, shiftbytes);
  }

  shiftbits %= 8;

  if (shiftbits > 0)
  {
    uint8_t carry = 0;
    for (int i = size - 1; i >= 0; --i)
    {
      uint8_t u = temp[i] >> (8 - shiftbits);
      temp[i] = temp[i] << shiftbits;
      temp[i] |= carry;
      carry = u;
    }
    temp[size - 1] |= carry;
  }

  memcpy(buffer, temp, size);

  free(temp);
}

int main(int argc, char* argv[])
{
  if (argc > 1)
  {
    DisplayUsage(argv[0]);
    return -1;
  }

  char outfile[256];
  EnterText("Enter output file name:", outfile, sizeof(outfile));

  char infile[256];
  EnterText("Enter input file name:", infile, sizeof(infile));
  int insize;
  uint8_t* inbuffer = ReadFile(infile, &insize);

  int nummasks = 0;
  while (1)
  {
    char prompt[256];
    sprintf(prompt, "Enter mask file name (#%d):", nummasks + 1);
    char maskfile[256];
    EnterText(prompt, maskfile, sizeof(maskfile));
    if (strlen(maskfile) == 0)
      continue;
    if (strchr(maskfile, '*'))
      break;

    int masksize;
    uint8_t* maskbuffer = ReadFile(maskfile, &masksize);
    VERIFY2(masksize >= insize, "Mask file too small", maskfile);
    CircularShiftLeft(maskbuffer, insize, nummasks);
    memxor(inbuffer, maskbuffer, insize);
    free(maskbuffer);

    ++nummasks;
  }

  if (nummasks > 0)
  {
    FILE* outfp = fopen(outfile, "wb");
    VERIFY2(outfp, "Failed to open output file", outfile);
    int write = fwrite(inbuffer, 1, insize, outfp);
    VERIFY2(write == insize, "Error writing output file", outfile);
    fclose(outfp);
    printf("Output file %s is created successfully.\n", outfile);
    printf("%d mask files are used.\n", nummasks);
  }
  else
  {
    printf("No mask file is specified. Aborted.\n");
  }

  free(inbuffer);

  return 0;
}
