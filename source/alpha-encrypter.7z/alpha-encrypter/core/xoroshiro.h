#pragma once

#include "basics.h"

static inline uint64_t rotl64(const uint64_t x, int k)
{
  return (x << k) | (x >> (64 - k));
}
