#pragma once

#include "basic_hash.h"
#include "prng.h"

static const HashAlgo* CocktailHashs[] = {};
static const PrngAlgo* CocktailPrngs[] = {
  &Pcg64Prng,
  &Xoroshiro256ppPrng,
  &FibonacciNrng,
};
static const HashAlgo* CocktailKeyHash = NULL;
