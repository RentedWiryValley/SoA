#pragma once

#include "basic_prng.h"

extern const PrngAlgo Pcg64Prng;
extern const PrngAlgo Xoroshiro256ppPrng;
extern const PrngAlgo FibonacciNrng;
