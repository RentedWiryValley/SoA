#include <string.h>

#include "fibonaccistream.h"

#include "bufferedstream.h"
#include "hash/skein.h"

const PrngAlgo FibonacciNrng = {.InitFunc = FibonacciInit,
                                .DeinitFunc = FibonacciDeinit,
                                .GetUint8Func = FibonacciRand8,
                                .GetUint16Func = FibonacciRand16,
                                .GetUint32Func = FibonacciRand32,
                                .GetUint64Func = FibonacciRand64,
                                .BufferFunc = FibonacciRandBuffer,
                                .XorBufferFunc = FibonacciRandXorBuffer};

void GenerateFibonacciStream(void);

static BufferedStream FibonacciBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateFibonacciStream};

static uint64_t FibonacciNumbers[2];

static BOOL FibonacciInitialized = FALSE;

void FibonacciInit(const uint8_t* key, int key_len)
{
  VERIFY(!FibonacciInitialized, "Fibonacci NRNG already initialized");
  VERIFY(key && key_len > 0, "Bad Fibonacci NRNG key!");

  // key_len = key_len > (int)sizeof(FibonacciNumbers)
  //             ? (int)sizeof(FibonacciNumbers)
  //             : key_len;
  // ClearMemory(FibonacciNumbers, sizeof(FibonacciNumbers));
  // memcpy(FibonacciNumbers, key, key_len);
  uint8_t hash[BYTES_256_BITS];
  Skein_256_Ctxt_t ctx = {0};
  Skein_256_Init(&ctx, 256);
  Skein_256_Update(&ctx, (uint8_t*)"F", 1);
  Skein_256_Update(&ctx, key, key_len);
  Skein_256_Update(&ctx, (uint8_t*)"F", 1);
  Skein_256_Final(&ctx, hash);
  memcpy(FibonacciNumbers, hash, sizeof(FibonacciNumbers));

  FibonacciBufferedStream.Index = FibonacciBufferedStream.Size;

  FibonacciInitialized = TRUE;
}

void FibonacciDeinit(void)
{
  VERIFY(FibonacciInitialized, "Fibonacci NRNG not initialized");

  FibonacciBufferedStream.Index = FibonacciBufferedStream.Size;

  FibonacciInitialized = FALSE;
}

void GenerateFibonacciStream(void)
{
  VERIFY(FibonacciInitialized, "Fibonacci NRNG not initialized");

  // uint8_t hash[BYTES_128_BITS];
  // Siphash_128((uint8_t*)FibonacciNumbers, sizeof(FibonacciNumbers), hash);
  // memcpy(FibonacciNumbers, hash, sizeof(FibonacciNumbers));

  uint64_t* p = (uint64_t*)FibonacciBufferedStream.Buffer;
  for (int i = 0; i < FibonacciBufferedStream.Size / (int)sizeof(uint64_t); ++i)
  {
    *p = FibonacciNumbers[0] + FibonacciNumbers[1];
    FibonacciNumbers[0] = FibonacciNumbers[1];
    FibonacciNumbers[1] = *p;
    ++p;
  }
}

uint8_t FibonacciRand8(void)
{
  uint8_t r = Extract8(&FibonacciBufferedStream);
  return r;
}

uint16_t FibonacciRand16(void)
{
  uint16_t r = Extract16(&FibonacciBufferedStream);
  return r;
}

uint32_t FibonacciRand32(void)
{
  uint32_t r = Extract32(&FibonacciBufferedStream);
  return r;
}

uint64_t FibonacciRand64(void)
{
  uint64_t r = Extract64(&FibonacciBufferedStream);
  return r;
}

void FibonacciRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&FibonacciBufferedStream, buffer, size);
}

void FibonacciRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&FibonacciBufferedStream, buffer, size);
}
