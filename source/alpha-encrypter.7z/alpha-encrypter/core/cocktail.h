#pragma once

#include "basics.h"

// Cocktail
int Cocktail_Encrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, const uint8_t* iv, int iv_len,
                     uint8_t* output, int output_size);
int Cocktail_Decrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output, int output_size);
