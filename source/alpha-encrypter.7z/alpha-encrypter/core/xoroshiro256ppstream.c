#include "xoroshiro256ppstream.h"
#include "xoroshiro256.h"

#include "bufferedstream.h"
#include "hash/skein.h"

const PrngAlgo Xoroshiro256ppPrng = {
  .InitFunc = Xoroshiro256ppInit,
  .DeinitFunc = Xoroshiro256ppDeinit,
  .GetUint8Func = Xoroshiro256ppRand8,
  .GetUint16Func = Xoroshiro256ppRand16,
  .GetUint32Func = Xoroshiro256ppRand32,
  .GetUint64Func = Xoroshiro256ppRand64,
  .BufferFunc = Xoroshiro256ppRandBuffer,
  .XorBufferFunc = Xoroshiro256ppRandXorBuffer};

void GenerateXoroshiro256ppStream(void);

static BufferedStream Xoroshiro256ppBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro256ppStream};

static Xoroshiro256Ctx Ctx = {0};
static BOOL Xoroshiro256ppInitialized = FALSE;

static uint64_t Xoroshiro256ppNext(void)
{
  const uint64_t result = rotl64(Ctx.s[0] + Ctx.s[3], 23) + Ctx.s[0];

  const uint64_t t = Ctx.s[1] << 17;

  Ctx.s[2] ^= Ctx.s[0];
  Ctx.s[3] ^= Ctx.s[1];
  Ctx.s[1] ^= Ctx.s[2];
  Ctx.s[0] ^= Ctx.s[3];

  Ctx.s[2] ^= t;

  Ctx.s[3] = rotl64(Ctx.s[3], 45);

  return result;
}

void Xoroshiro256ppInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro256ppInitialized, "Xoroshiro256++ already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro256++ key!");

  // Sha2_256(key, key_len, (uint8_t*)Ctx.s);
  Skein_256_Ctxt_t ctx = {0};
  Skein_256_Init(&ctx, 256);
  Skein_256_Update(&ctx, (uint8_t*)"X", 1);
  Skein_256_Update(&ctx, key, key_len);
  Skein_256_Update(&ctx, (uint8_t*)"X", 1);
  Skein_256_Final(&ctx, (uint8_t*)Ctx.s);

  Xoroshiro256ppBufferedStream.Index = Xoroshiro256ppBufferedStream.Size;

  Xoroshiro256ppInitialized = TRUE;
}

void Xoroshiro256ppDeinit(void)
{
  VERIFY(Xoroshiro256ppInitialized, "Xoroshiro256++ not initialized");

  Xoroshiro256ppBufferedStream.Index = Xoroshiro256ppBufferedStream.Size;

  Xoroshiro256ppInitialized = FALSE;
}

void GenerateXoroshiro256ppStream(void)
{
  VERIFY(Xoroshiro256ppInitialized, "Xoroshiro256++ not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro256ppBufferedStream.Buffer;
  for (int i = 0; i < Xoroshiro256ppBufferedStream.Size / (int)sizeof(uint64_t);
       ++i)
  {
    *p = Xoroshiro256ppNext();
    ++p;
  }
}

uint8_t Xoroshiro256ppRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro256ppBufferedStream);
  return r;
}

uint16_t Xoroshiro256ppRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro256ppBufferedStream);
  return r;
}

uint32_t Xoroshiro256ppRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro256ppBufferedStream);
  return r;
}

uint64_t Xoroshiro256ppRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro256ppBufferedStream);
  return r;
}

void Xoroshiro256ppRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro256ppBufferedStream, buffer, size);
}

void Xoroshiro256ppRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro256ppBufferedStream, buffer, size);
}
