#pragma once

#include <stddef.h>
#include <stdint.h>

#define BYTES_64_BITS (64 / 8)
#define BYTES_128_BITS (128 / 8)
#define BYTES_160_BITS (160 / 8)
#define BYTES_256_BITS (256 / 8)
#define BYTES_512_BITS (512 / 8)
#define BYTES_1024_BITS (1024 / 8)

#ifndef BOOL
#define BOOL int
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define UNUSED(x) (void)(x)

#define VERIFY(x, m) \
  {                  \
    if (!(x))        \
      Exit(m);       \
  }

typedef uint8_t (*GetUint8Func)(void);
typedef uint16_t (*GetUint16Func)(void);
typedef uint32_t (*GetUint32Func)(void);
typedef uint64_t (*GetUint64Func)(void);

void ClearMemory(void* buffer, size_t buffer_len);

void __attribute__((noreturn)) Exit(const char*);
