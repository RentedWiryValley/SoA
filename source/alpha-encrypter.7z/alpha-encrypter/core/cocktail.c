#include <string.h>

#include "cocktail.h"
#include "cocktail_prims.h"

#include "memxor.h"
#include "pseudorandom.h"

// #include "debugging.h"

int Cocktail_Encrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, const uint8_t* iv, int iv_len,
                     uint8_t* output, int output_size)
{
  VERIFY(input && input_len > 0, "Bad Cocktail input");
  // VERIFY(key_len >= 32, "Bad Cocktail key length");
  UNUSED(iv + iv_len);
  VERIFY(input_len <= output_size, "Bad Cocktail output size");
  PseudorandomInit(
    key, key_len, CocktailHashs,
    sizeof(CocktailHashs) / sizeof(CocktailHashs[0]), CocktailPrngs,
    sizeof(CocktailPrngs) / sizeof(CocktailPrngs[0]), CocktailKeyHash);
  PseudorandomBuffer(output, input_len);
  PseudorandomDeinit();
  memxor(output, input, input_len);
  // // if (bVerifyEncryption)
  // {
  //   VERIFY(input_len <= (int)sizeof(debugDecryptionOutput),
  //          "Cannot verify Cocktail encrypt");
  //   int decrypted_len =
  //     Cocktail_Decrypt(output, input_len, key, key_len, debugDecryptionOutput,
  //                      (int)sizeof(debugDecryptionOutput));
  //   VERIFY(decrypted_len == input_len &&
  //            memcmp(input, debugDecryptionOutput, input_len) == 0,
  //          "Error verifying Cocktail encrypt");
  // }
  return input_len;
}

int Cocktail_Decrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output, int output_size)
{
  VERIFY(input && input_len > 0, "Bad Cocktail input");
  // VERIFY(key_len >= 32, "Bad Cocktail key length");
  VERIFY(input_len <= output_size, "Bad Cocktail output size");
  PseudorandomInit(
    key, key_len, CocktailHashs,
    sizeof(CocktailHashs) / sizeof(CocktailHashs[0]), CocktailPrngs,
    sizeof(CocktailPrngs) / sizeof(CocktailPrngs[0]), CocktailKeyHash);
  PseudorandomBuffer(output, input_len);
  PseudorandomDeinit();
  memxor(output, input, input_len);
  return input_len;
}
