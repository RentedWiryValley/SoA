#include <stdio.h>
#include <string.h>

#include "basics.h"
#include "cocktail.h"
#include "hash/skein.h"
#include "utils.h"

#define MAX_FILE_SIZE 65536

void CocktailEncryptFile(void)
{
  char infilename[256], outfilename[256];
  uint8_t input[MAX_FILE_SIZE], output[MAX_FILE_SIZE];
  int input_len, output_len;
  FILE* fp;

  EnterText("Enter input file name:", infilename, sizeof(infilename));
  fp = fopen(infilename, "rb");
  VERIFY(fp, "Failed opening input file");
  fseek(fp, 0L, SEEK_END);
  input_len = (int)ftell(fp);
  VERIFY(input_len < (int)sizeof(input), "Input file too big");
  fseek(fp, 0L, SEEK_SET);
  int read = (int)fread(input, 1, input_len, fp);
  VERIFY(read == input_len, "Error reading input file");
  fclose(fp);

  EnterText("Enter output file name:", outfilename, sizeof(outfilename));
  fp = fopen(outfilename, "wb");
  VERIFY(fp, "Failed opening output file");

  char pass[256];
  EnterText("Enter password:", pass, sizeof(pass));

  output_len = Cocktail_Encrypt(input, input_len, (uint8_t*)pass, strlen(pass),
                                NULL, 0, output, sizeof(output));
  VERIFY(output_len > 0, "Failed encrypting file");

  int write = fwrite(output, 1, output_len, fp);
  VERIFY(write == output_len, "Error writing output file");
  fclose(fp);

  printf("\nFile %s is successfully encrypted and saved to %s.\n", infilename,
         outfilename);
}

void CocktailDecryptFile(void)
{
  char infilename[256], outfilename[256];
  uint8_t input[MAX_FILE_SIZE], output[MAX_FILE_SIZE];
  int input_len, output_len;
  FILE* fp;

  EnterText("Enter input file name:", infilename, sizeof(infilename));
  fp = fopen(infilename, "rb");
  VERIFY(fp, "Failed opening input file");
  fseek(fp, 0L, SEEK_END);
  input_len = (int)ftell(fp);
  VERIFY(input_len < (int)sizeof(input), "Input file too big");
  fseek(fp, 0L, SEEK_SET);
  int read = (int)fread(input, 1, input_len, fp);
  VERIFY(read == input_len, "Error reading input file");
  fclose(fp);

  EnterText("Enter output file name:", outfilename, sizeof(outfilename));
  fp = fopen(outfilename, "wb");
  VERIFY(fp, "Failed opening output file");

  char pass[256];
  EnterText("Enter password:", pass, sizeof(pass));

  output_len = Cocktail_Decrypt(input, input_len, (uint8_t*)pass, strlen(pass),
                                output, sizeof(output));
  VERIFY(output_len > 0, "Failed decrypting file");

  int write = fwrite(output, 1, output_len, fp);
  VERIFY(write == output_len, "Error writing output file");
  fclose(fp);

  printf("\nFile %s is successfully decrypted and saved to %s.\n", infilename,
         outfilename);
}

int main(void)
{
  printf("File encrypter/decrypter for 'Alpha' cipher code\n");
  printf("\n");
  printf("Options:\n");
  printf("- 'E' or 'e' for encryption\n");
  printf("- 'D' or 'd' for decryption\n");
  printf("\n");

  char option[256];

  EnterText("Choose your option:", option, sizeof(option));

  printf("\n");

  if (option[0] == 'E' || option[0] == 'e')
    CocktailEncryptFile();
  else if (option[0] == 'D' || option[0] == 'd')
    CocktailDecryptFile();

  return 0;
}
