#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utils.h"

void GetUserInput(char* text, int length)
{
#define MAX_LEN 65536
  char str[MAX_LEN];
  str[0] = 0;
  char* rtn = fgets(str, sizeof(str), stdin);
  if (rtn)
  {
    int len = strlen(str);
    if (len > 0 && str[len - 1] == '\n')
    {
      str[len - 1] = 0;
    }
  }
  length = length > MAX_LEN ? MAX_LEN : length;
  str[length - 1] = 0;
  strcpy(text, str);
#undef MAX_LEN
}

void EnterText(const char* prompt, char* text, int len)
{
  printf("%s ", prompt);
  GetUserInput(text, len);
}

int EnterInteger(const char* prompt)
{
  printf("%s ", prompt);
  char str[32];
  GetUserInput(str, sizeof(str));
  int rtn = atoi(str);
  return rtn;
}

int EnterPositiveInteger(const char* prompt)
{
  int rtn = 0;
  do
  {
    rtn = EnterInteger(prompt);
  } while (rtn <= 0);
  return rtn;
}
