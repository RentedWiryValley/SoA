#include <stdio.h>
#include <string.h>

#include "alpha.h"
#include "bravo.h"
#include "cascade.h"

#include "common.h"
#include "defines.h"
#include "utils.h"

void CascadeDecryptFile(void)
{
  char filename[256];
  EnterText("Enter file name:", filename, sizeof(filename));

  uint8_t data[MAX_FILE_DECRYPTION_IN_SIZE];

  FILE* fp = fopen(filename, "rb");
  VERIFY(fp, "Error: Failed opening file");
  fseek(fp, 0L, SEEK_END);
  long size = ftell(fp);
  fseek(fp, 0L, SEEK_SET);
  size_t read = fread(data, 1, size, fp);
  VERIFY((long)read == size, "Error: Failed reading file");
  fclose(fp);

  int input_len = (int)size;

  char pass[256], salt[256], iv[256], nonce[256];
  uint8_t aesiv[128], chachanonce[128];
  int iterations, alpharounds, bravorounds;

  EnterText("Enter password:", pass, sizeof(pass));
  EnterText("Enter PBKDF salt:", salt, sizeof(salt));
  iterations = EnterInteger("Enter PBKDF iterations:");
  EnterText("Enter AES IV:", iv, sizeof(iv));
  int ivlength = HexStringToByteArray(iv, aesiv);
  VERIFY(ivlength >= 16, "AES IV is too short.");
  EnterText("Enter Chacha20 nonce:", nonce, sizeof(nonce));
  int noncelength = HexStringToByteArray(nonce, chachanonce);
  VERIFY(noncelength >= 12, "Chacha20 nonce is too short.");
  alpharounds = EnterPositiveInteger("Enter Alpha rounds:");
  bravorounds = EnterPositiveInteger("Enter Bravo rounds:");

  uint8_t decrypted[MAX_FILE_DECRYPTION_IN_SIZE];
  int len = CascadeDecrypt(data, input_len, pass, salt, &iterations, aesiv,
                           chachanonce, &alpharounds, &bravorounds,
                           (uint8_t*)decrypted, sizeof(decrypted));
  VERIFY(len > 0, "Decryption failed.");
  decrypted[len] = 0;

  printf("\nDecrypted:\n%s\n\n", decrypted);
}

int main(void)
{
  printf("File decrypter for device-encrypted SoA\n\n");

#pragma message("Modify professional primitives need modifying.")
  printf("Professional primitives need modifying.\n\n");

  CascadeDecryptFile();

  return 0;
}
