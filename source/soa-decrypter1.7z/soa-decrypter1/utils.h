#pragma once

#include <stdint.h>

void GetUserInput(char* text, int length);
void EnterText(const char* prompt, char* text, int len);
int EnterInteger(const char* prompt);
int EnterPositiveInteger(const char* prompt);
