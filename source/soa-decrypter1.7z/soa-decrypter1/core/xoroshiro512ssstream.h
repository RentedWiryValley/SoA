#pragma once

#include "basic_prng.h"

void Xoroshiro512ssInit(const uint8_t* key, int key_len);
void Xoroshiro512ssDeinit(void);
uint8_t Xoroshiro512ssRand8(void);
uint16_t Xoroshiro512ssRand16(void);
uint32_t Xoroshiro512ssRand32(void);
uint64_t Xoroshiro512ssRand64(void);
void Xoroshiro512ssRandBuffer(uint8_t* buffer, int size);
void Xoroshiro512ssRandXorBuffer(uint8_t* buffer, int size);
