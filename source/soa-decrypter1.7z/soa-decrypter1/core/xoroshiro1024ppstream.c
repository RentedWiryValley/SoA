#include "xoroshiro1024ppstream.h"
#include "xoroshiro1024.h"

#include "bufferedstream.h"

#include "hash/skein.h"

const PrngAlgo Xoroshiro1024ppPrng = {
  .InitFunc = Xoroshiro1024ppInit,
  .DeinitFunc = Xoroshiro1024ppDeinit,
  .GetUint8Func = Xoroshiro1024ppRand8,
  .GetUint16Func = Xoroshiro1024ppRand16,
  .GetUint32Func = Xoroshiro1024ppRand32,
  .GetUint64Func = Xoroshiro1024ppRand64,
  .BufferFunc = Xoroshiro1024ppRandBuffer,
  .XorBufferFunc = Xoroshiro1024ppRandXorBuffer};

void GenerateXoroshiro1024ppStream(void);

static BufferedStream Xoroshiro1024ppBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro1024ppStream};

static Xoroshiro1024Ctx Ctx = {0};
static BOOL Xoroshiro1024ppInitialized = FALSE;

static uint64_t Xoroshiro1024ppNext(void)
{
  const int q = Ctx.p;
  const uint64_t s0 = Ctx.s[Ctx.p = (Ctx.p + 1) & 15];
  uint64_t s15 = Ctx.s[q];
  const uint64_t result = rotl64(s0 + s15, 23) + s15;

  s15 ^= s0;
  Ctx.s[q] = rotl64(s0, 25) ^ s15 ^ (s15 << 27);
  Ctx.s[Ctx.p] = rotl64(s15, 36);

  return result;
}

void Xoroshiro1024ppInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro1024ppInitialized, "Xoroshiro1024++ already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro1024++ key!");

  Skein1024_Ctxt_t ctx = {0};
  Skein1024_Init(&ctx, 1024);
  Skein1024_Update(&ctx, (uint8_t*)"++", 2);
  Skein1024_Update(&ctx, key, key_len);
  Skein1024_Update(&ctx, (uint8_t*)"++", 2);
  Skein1024_Final(&ctx, (uint8_t*)Ctx.s);

  Xoroshiro1024ppBufferedStream.Index = Xoroshiro1024ppBufferedStream.Size;

  Xoroshiro1024ppInitialized = TRUE;
}

void Xoroshiro1024ppDeinit(void)
{
  VERIFY(Xoroshiro1024ppInitialized, "Xoroshiro1024++ not initialized");

  Xoroshiro1024ppBufferedStream.Index = Xoroshiro1024ppBufferedStream.Size;

  Xoroshiro1024ppInitialized = FALSE;
}

void GenerateXoroshiro1024ppStream(void)
{
  VERIFY(Xoroshiro1024ppInitialized, "Xoroshiro1024++ not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro1024ppBufferedStream.Buffer;
  for (int i = 0;
       i < Xoroshiro1024ppBufferedStream.Size / (int)sizeof(uint64_t); ++i)
  {
    *p = Xoroshiro1024ppNext();
    ++p;
  }
}

uint8_t Xoroshiro1024ppRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro1024ppBufferedStream);
  return r;
}

uint16_t Xoroshiro1024ppRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro1024ppBufferedStream);
  return r;
}

uint32_t Xoroshiro1024ppRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro1024ppBufferedStream);
  return r;
}

uint64_t Xoroshiro1024ppRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro1024ppBufferedStream);
  return r;
}

void Xoroshiro1024ppRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro1024ppBufferedStream, buffer, size);
}

void Xoroshiro1024ppRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro1024ppBufferedStream, buffer, size);
}
