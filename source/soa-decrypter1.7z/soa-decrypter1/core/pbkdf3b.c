#include <string.h>

#include "pbkdf3b.h"
#include "pbkdf3b_prims.h"

#include "memxor.h"

// 256-bit

const PbkdfHashAlgo Pbkdf3b_256Hasher = {.OutputSize = Bytes256Bits,
                                         .InitFunc = Pbkdf3b_256_Init,
                                         .UpdateFunc = Pbkdf3b_256_Update,
                                         .FinalFunc = Pbkdf3b_256_Final,
                                         .HashFunc = Pbkdf3b_256};

void Pbkdf3b_256_Init_Ctx(PBKDF3b_256_CTX* ctx, const uint8_t* pass,
                          int pass_len, const uint8_t* salt, int salt_len)
{
  MainHasher256.InitFunc();
  MainHasher256.UpdateFunc(pass, pass_len);
  MainHasher256.UpdateFunc(salt, salt_len);
  int passhashindex = ctx->hashindex;
  int salthashindex = (passhashindex + 1) % Hash256FuncCount;
  Hash256Funcs[passhashindex](pass, pass_len, ctx->passhash);
  Hash256Funcs[salthashindex](salt, salt_len, ctx->salthash);
  ctx->hashindex = salthashindex;
}

void Pbkdf3b_256_Update_Ctx(PBKDF3b_256_CTX* ctx, int iterations)
{
  for (int i = 0; i < iterations; ++i)
  {
    MainHasher256.UpdateFunc(ctx->passhash, sizeof(ctx->passhash));
    MainHasher256.UpdateFunc(ctx->salthash, sizeof(ctx->salthash));
    int passhashindex = ctx->hashindex;
    int salthashindex = (passhashindex + 1) % Hash256FuncCount;
    Hash256Funcs[passhashindex](ctx->passhash, sizeof(ctx->passhash),
                                ctx->passhash);
    Hash256Funcs[salthashindex](ctx->salthash, sizeof(ctx->salthash),
                                ctx->salthash);
    ctx->hashindex = salthashindex;
  }
}

void Pbkdf3b_256_Final_Ctx(PBKDF3b_256_CTX* ctx, uint8_t* key)
{
  uint8_t output[BYTES_256_BITS];
  MainHasher256.FinalFunc(output);
  memcpy(key, output, BYTES_256_BITS);
  uint8_t hash[BYTES_256_BITS];
  for (int i = 0; i < Hash256FuncCount; ++i)
  {
    Hash256Funcs[i](output, BYTES_256_BITS, hash);
    Hash256Funcs[i](hash, BYTES_256_BITS, hash);
    memxor(key, hash, BYTES_256_BITS);
  }
  ClearMemory(hash, sizeof(hash));
  ClearMemory(output, sizeof(output));
  ClearMemory(ctx, sizeof(PBKDF3b_256_CTX));
}

static PBKDF3b_256_CTX Pbkdf3b_256_Ctx = {0};

void Pbkdf3b_256_Init(const uint8_t* pass, int pass_len, const uint8_t* salt,
                      int salt_len)
{
  ClearMemory(&Pbkdf3b_256_Ctx, sizeof(Pbkdf3b_256_Ctx));
  Pbkdf3b_256_Init_Ctx(&Pbkdf3b_256_Ctx, pass, pass_len, salt, salt_len);
}

void Pbkdf3b_256_Update(int iterations)
{
  Pbkdf3b_256_Update_Ctx(&Pbkdf3b_256_Ctx, iterations);
}

void Pbkdf3b_256_Final(uint8_t* output)
{
  Pbkdf3b_256_Final_Ctx(&Pbkdf3b_256_Ctx, output);
}

void Pbkdf3b_256(const uint8_t* pass, int pass_len, const uint8_t* salt,
                 int salt_len, int iterations, uint8_t* output)
{
  PBKDF3b_256_CTX ctx = {0};
  ClearMemory(&ctx, sizeof(ctx));
  Pbkdf3b_256_Init_Ctx(&ctx, pass, pass_len, salt, salt_len);
  Pbkdf3b_256_Update_Ctx(&ctx, iterations);
  Pbkdf3b_256_Final_Ctx(&ctx, output);
}

// 512-bit

const PbkdfHashAlgo Pbkdf3b_512Hasher = {.OutputSize = Bytes512Bits,
                                         .InitFunc = Pbkdf3b_512_Init,
                                         .UpdateFunc = Pbkdf3b_512_Update,
                                         .FinalFunc = Pbkdf3b_512_Final,
                                         .HashFunc = Pbkdf3b_512};

void Pbkdf3b_512_Init_Ctx(PBKDF3b_512_CTX* ctx, const uint8_t* pass,
                          int pass_len, const uint8_t* salt, int salt_len)
{
  MainHasher512.InitFunc();
  MainHasher512.UpdateFunc(pass, pass_len);
  MainHasher512.UpdateFunc(salt, salt_len);
  int passhashindex = ctx->hashindex;
  int salthashindex = (passhashindex + 1) % Hash512FuncCount;
  Hash512Funcs[passhashindex](pass, pass_len, ctx->passhash);
  Hash512Funcs[salthashindex](salt, salt_len, ctx->salthash);
  ctx->hashindex = salthashindex;
}

void Pbkdf3b_512_Update_Ctx(PBKDF3b_512_CTX* ctx, int iterations)
{
  for (int i = 0; i < iterations; ++i)
  {
    MainHasher512.UpdateFunc(ctx->passhash, sizeof(ctx->passhash));
    MainHasher512.UpdateFunc(ctx->salthash, sizeof(ctx->salthash));
    int passhashindex = ctx->hashindex;
    int salthashindex = (passhashindex + 1) % Hash512FuncCount;
    Hash512Funcs[passhashindex](ctx->passhash, sizeof(ctx->passhash),
                                ctx->passhash);
    Hash512Funcs[salthashindex](ctx->salthash, sizeof(ctx->salthash),
                                ctx->salthash);
    ctx->hashindex = salthashindex;
  }
}

void Pbkdf3b_512_Final_Ctx(PBKDF3b_512_CTX* ctx, uint8_t* key)
{
  uint8_t output[BYTES_512_BITS];
  MainHasher512.FinalFunc(output);
  memcpy(key, output, BYTES_512_BITS);
  uint8_t hash[BYTES_512_BITS];
  for (int i = 0; i < Hash512FuncCount; ++i)
  {
    Hash512Funcs[i](output, BYTES_512_BITS, hash);
    Hash512Funcs[i](hash, BYTES_512_BITS, hash);
    memxor(key, hash, BYTES_512_BITS);
  }
  ClearMemory(hash, sizeof(hash));
  ClearMemory(output, sizeof(output));
  ClearMemory(ctx, sizeof(PBKDF3b_512_CTX));
}

static PBKDF3b_512_CTX Pbkdf3b_512_Ctx = {0};

void Pbkdf3b_512_Init(const uint8_t* pass, int pass_len, const uint8_t* salt,
                      int salt_len)
{
  ClearMemory(&Pbkdf3b_512_Ctx, sizeof(Pbkdf3b_512_Ctx));
  Pbkdf3b_512_Init_Ctx(&Pbkdf3b_512_Ctx, pass, pass_len, salt, salt_len);
}

void Pbkdf3b_512_Update(int iterations)
{
  Pbkdf3b_512_Update_Ctx(&Pbkdf3b_512_Ctx, iterations);
}

void Pbkdf3b_512_Final(uint8_t* output)
{
  Pbkdf3b_512_Final_Ctx(&Pbkdf3b_512_Ctx, output);
}

void Pbkdf3b_512(const uint8_t* pass, int pass_len, const uint8_t* salt,
                 int salt_len, int iterations, uint8_t* output)
{
  PBKDF3b_512_CTX ctx = {0};
  ClearMemory(&ctx, sizeof(ctx));
  Pbkdf3b_512_Init_Ctx(&ctx, pass, pass_len, salt, salt_len);
  Pbkdf3b_512_Update_Ctx(&ctx, iterations);
  Pbkdf3b_512_Final_Ctx(&ctx, output);
}
