#pragma once

#include "basics.h"

void memxor(void* out, const void* in, int bytes);
