#include <string.h>

#include "isaacstream.h"

#include "bufferedstream.h"
#include "isaac/isaac.h"

/*
Differences between ISAAC Buffered Stream and rand() of the original ISAAC:
1. The former reads the buffer from zero up, while the latter does it
   from RANDSIZ-1 down.
2. ISAAC Buffered Stream does not touch randcnt.
*/

const PrngAlgo IsaacCsprng = {.InitFunc = IsaacInit,
                              .DeinitFunc = IsaacDeinit,
                              .GetUint8Func = IsaacRand8,
                              .GetUint16Func = IsaacRand16,
                              .GetUint32Func = IsaacRand32,
                              .GetUint64Func = IsaacRand64,
                              .BufferFunc = IsaacRandBuffer,
                              .XorBufferFunc = IsaacRandXorBuffer};

#define ISAAC_BUFFER_SIZE (int)sizeof(((isaacctx*)0)->randrsl)

void GenerateIsaacStream(void);

static BufferedStream IsaacBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateIsaacStream};

static isaacctx IsaacCtx = {0};
static int IsaacRandrslIndex = 0;
static BOOL IsaacInitialized = FALSE;

void IsaacInit(const uint8_t* key, int key_len)
{
  VERIFY(!IsaacInitialized, "ISAAC already initialized");
  VERIFY(key && key_len > 0, "Bad ISAAC key!");

  key_len = key_len > ISAAC_BUFFER_SIZE ? ISAAC_BUFFER_SIZE : key_len;

  ClearMemory(IsaacCtx.randrsl, ISAAC_BUFFER_SIZE);
  memcpy(&IsaacCtx.randrsl, key, key_len);
  isaacinit(&IsaacCtx, TRUE);

  memcpy(IsaacBufferedStream.Buffer, IsaacCtx.randrsl,
         MAX_BUFFEREDSTREAM_BUFFER_SIZE);
  IsaacBufferedStream.Index = 0;

  IsaacRandrslIndex = MAX_BUFFEREDSTREAM_BUFFER_SIZE;

  IsaacInitialized = TRUE;
}

void IsaacDeinit(void)
{
  VERIFY(IsaacInitialized, "ISAAC not initialized");

  IsaacInitialized = FALSE;
}

void GenerateIsaacStream(void)
{
  VERIFY(IsaacInitialized, "ISAAC not initialized");

  if (IsaacRandrslIndex >= ISAAC_BUFFER_SIZE)
  {
    isaacupdate(&IsaacCtx);
    IsaacRandrslIndex = 0;
  }

  memcpy(IsaacBufferedStream.Buffer,
         ((uint8_t*)IsaacCtx.randrsl) + IsaacRandrslIndex,
         MAX_BUFFEREDSTREAM_BUFFER_SIZE);

  IsaacRandrslIndex += MAX_BUFFEREDSTREAM_BUFFER_SIZE;
}

uint8_t IsaacRand8(void)
{
  uint8_t r = Extract8(&IsaacBufferedStream);
  return r;
}

uint16_t IsaacRand16(void)
{
  uint16_t r = Extract16(&IsaacBufferedStream);
  return r;
}

uint32_t IsaacRand32(void)
{
  uint32_t r = Extract32(&IsaacBufferedStream);
  return r;
}

uint64_t IsaacRand64(void)
{
  uint64_t r = Extract64(&IsaacBufferedStream);
  return r;
}

void IsaacRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&IsaacBufferedStream, buffer, size);
}

void IsaacRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&IsaacBufferedStream, buffer, size);
}
