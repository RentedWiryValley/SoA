#pragma once

#include "basic_prng.h"

void Isaac64Init(const uint8_t* key, int key_len);
void Isaac64Deinit(void);
uint8_t Isaac64Rand8(void);
uint16_t Isaac64Rand16(void);
uint32_t Isaac64Rand32(void);
uint64_t Isaac64Rand64(void);
void Isaac64RandBuffer(uint8_t* buffer, int size);
void Isaac64RandXorBuffer(uint8_t* buffer, int size);
