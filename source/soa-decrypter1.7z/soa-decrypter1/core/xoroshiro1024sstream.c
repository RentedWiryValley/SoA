#include "xoroshiro1024sstream.h"
#include "xoroshiro1024.h"

#include "bufferedstream.h"

#include "hash/skein.h"

const PrngAlgo Xoroshiro1024sPrng = {
  .InitFunc = Xoroshiro1024sInit,
  .DeinitFunc = Xoroshiro1024sDeinit,
  .GetUint8Func = Xoroshiro1024sRand8,
  .GetUint16Func = Xoroshiro1024sRand16,
  .GetUint32Func = Xoroshiro1024sRand32,
  .GetUint64Func = Xoroshiro1024sRand64,
  .BufferFunc = Xoroshiro1024sRandBuffer,
  .XorBufferFunc = Xoroshiro1024sRandXorBuffer};

void GenerateXoroshiro1024sStream(void);

static BufferedStream Xoroshiro1024sBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro1024sStream};

static Xoroshiro1024Ctx Ctx = {0};
static BOOL Xoroshiro1024sInitialized = FALSE;

static uint64_t Xoroshiro1024sNext(void)
{
  const int q = Ctx.p;
  const uint64_t s0 = Ctx.s[Ctx.p = (Ctx.p + 1) & 15];
  uint64_t s15 = Ctx.s[q];
  const uint64_t result = s0 * 0x9e3779b97f4a7c13;

  s15 ^= s0;
  Ctx.s[q] = rotl64(s0, 25) ^ s15 ^ (s15 << 27);
  Ctx.s[Ctx.p] = rotl64(s15, 36);

  return result;
}

void Xoroshiro1024sInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro1024sInitialized, "Xoroshiro1024* already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro1024* key!");

  Skein1024_Ctxt_t ctx = {0};
  Skein1024_Init(&ctx, 1024);
  Skein1024_Update(&ctx, (uint8_t*)"*", 1);
  Skein1024_Update(&ctx, key, key_len);
  Skein1024_Update(&ctx, (uint8_t*)"*", 1);
  Skein1024_Final(&ctx, (uint8_t*)Ctx.s);

  Xoroshiro1024sBufferedStream.Index = Xoroshiro1024sBufferedStream.Size;

  Xoroshiro1024sInitialized = TRUE;
}

void Xoroshiro1024sDeinit(void)
{
  VERIFY(Xoroshiro1024sInitialized, "Xoroshiro1024* not initialized");

  Xoroshiro1024sBufferedStream.Index = Xoroshiro1024sBufferedStream.Size;

  Xoroshiro1024sInitialized = FALSE;
}

void GenerateXoroshiro1024sStream(void)
{
  VERIFY(Xoroshiro1024sInitialized, "Xoroshiro1024* not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro1024sBufferedStream.Buffer;
  for (int i = 0; i < Xoroshiro1024sBufferedStream.Size / (int)sizeof(uint64_t);
       ++i)
  {
    *p = Xoroshiro1024sNext();
    ++p;
  }
}

uint8_t Xoroshiro1024sRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro1024sBufferedStream);
  return r;
}

uint16_t Xoroshiro1024sRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro1024sBufferedStream);
  return r;
}

uint32_t Xoroshiro1024sRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro1024sBufferedStream);
  return r;
}

uint64_t Xoroshiro1024sRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro1024sBufferedStream);
  return r;
}

void Xoroshiro1024sRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro1024sBufferedStream, buffer, size);
}

void Xoroshiro1024sRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro1024sBufferedStream, buffer, size);
}
