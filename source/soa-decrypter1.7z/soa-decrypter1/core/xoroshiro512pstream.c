#include "xoroshiro512pstream.h"
#include "xoroshiro512.h"

#include "bufferedstream.h"
#include "hash.h"

const PrngAlgo Xoroshiro512pPrng = {
  .InitFunc = Xoroshiro512pInit,
  .DeinitFunc = Xoroshiro512pDeinit,
  .GetUint8Func = Xoroshiro512pRand8,
  .GetUint16Func = Xoroshiro512pRand16,
  .GetUint32Func = Xoroshiro512pRand32,
  .GetUint64Func = Xoroshiro512pRand64,
  .BufferFunc = Xoroshiro512pRandBuffer,
  .XorBufferFunc = Xoroshiro512pRandXorBuffer};

void GenerateXoroshiro512pStream(void);

static BufferedStream Xoroshiro512pBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro512pStream};

static Xoroshiro512Ctx Ctx = {0};
static BOOL Xoroshiro512pInitialized = FALSE;

static uint64_t Xoroshiro512pNext(void)
{
  const uint64_t result = Ctx.s[0] + Ctx.s[2];

  const uint64_t t = Ctx.s[1] << 11;

  Ctx.s[2] ^= Ctx.s[0];
  Ctx.s[5] ^= Ctx.s[1];
  Ctx.s[1] ^= Ctx.s[2];
  Ctx.s[7] ^= Ctx.s[3];
  Ctx.s[3] ^= Ctx.s[4];
  Ctx.s[4] ^= Ctx.s[5];
  Ctx.s[0] ^= Ctx.s[6];
  Ctx.s[6] ^= Ctx.s[7];

  Ctx.s[6] ^= t;

  Ctx.s[7] = rotl64(Ctx.s[7], 21);

  return result;
}

void Xoroshiro512pInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro512pInitialized, "Xoroshiro512+ already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro512+ key!");

  Sha3_512(key, key_len, (uint8_t*)Ctx.s);

  Xoroshiro512pBufferedStream.Index = Xoroshiro512pBufferedStream.Size;

  Xoroshiro512pInitialized = TRUE;
}

void Xoroshiro512pDeinit(void)
{
  VERIFY(Xoroshiro512pInitialized, "Xoroshiro512+ not initialized");

  Xoroshiro512pBufferedStream.Index = Xoroshiro512pBufferedStream.Size;

  Xoroshiro512pInitialized = FALSE;
}

void GenerateXoroshiro512pStream(void)
{
  VERIFY(Xoroshiro512pInitialized, "Xoroshiro512+ not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro512pBufferedStream.Buffer;
  for (int i = 0; i < Xoroshiro512pBufferedStream.Size / (int)sizeof(uint64_t);
       ++i)
  {
    *p = Xoroshiro512pNext();
    ++p;
  }
}

uint8_t Xoroshiro512pRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro512pBufferedStream);
  return r;
}

uint16_t Xoroshiro512pRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro512pBufferedStream);
  return r;
}

uint32_t Xoroshiro512pRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro512pBufferedStream);
  return r;
}

uint64_t Xoroshiro512pRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro512pBufferedStream);
  return r;
}

void Xoroshiro512pRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro512pBufferedStream, buffer, size);
}

void Xoroshiro512pRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro512pBufferedStream, buffer, size);
}
