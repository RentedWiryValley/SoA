#pragma once

#include "basic_prng.h"

void Xoroshiro1024sInit(const uint8_t* key, int key_len);
void Xoroshiro1024sDeinit(void);
uint8_t Xoroshiro1024sRand8(void);
uint16_t Xoroshiro1024sRand16(void);
uint32_t Xoroshiro1024sRand32(void);
uint64_t Xoroshiro1024sRand64(void);
void Xoroshiro1024sRandBuffer(uint8_t* buffer, int size);
void Xoroshiro1024sRandXorBuffer(uint8_t* buffer, int size);
