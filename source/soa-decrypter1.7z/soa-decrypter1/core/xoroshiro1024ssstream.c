#include "xoroshiro1024ssstream.h"
#include "xoroshiro1024.h"

#include "bufferedstream.h"

#include "hash/skein.h"

const PrngAlgo Xoroshiro1024ssPrng = {
  .InitFunc = Xoroshiro1024ssInit,
  .DeinitFunc = Xoroshiro1024ssDeinit,
  .GetUint8Func = Xoroshiro1024ssRand8,
  .GetUint16Func = Xoroshiro1024ssRand16,
  .GetUint32Func = Xoroshiro1024ssRand32,
  .GetUint64Func = Xoroshiro1024ssRand64,
  .BufferFunc = Xoroshiro1024ssRandBuffer,
  .XorBufferFunc = Xoroshiro1024ssRandXorBuffer};

void GenerateXoroshiro1024ssStream(void);

static BufferedStream Xoroshiro1024ssBufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GenerateXoroshiro1024ssStream};

static Xoroshiro1024Ctx Ctx = {0};
static BOOL Xoroshiro1024ssInitialized = FALSE;

static uint64_t Xoroshiro1024ssNext(void)
{
  const int q = Ctx.p;
  const uint64_t s0 = Ctx.s[Ctx.p = (Ctx.p + 1) & 15];
  uint64_t s15 = Ctx.s[q];
  const uint64_t result = rotl64(s0 * 5, 7) * 9;

  s15 ^= s0;
  Ctx.s[q] = rotl64(s0, 25) ^ s15 ^ (s15 << 27);
  Ctx.s[Ctx.p] = rotl64(s15, 36);

  return result;
}

void Xoroshiro1024ssInit(const uint8_t* key, int key_len)
{
  VERIFY(!Xoroshiro1024ssInitialized, "Xoroshiro1024** already initialized");
  VERIFY(key && key_len > 0, "Bad Xoroshiro1024** key!");

  Skein1024_Ctxt_t ctx = {0};
  Skein1024_Init(&ctx, 1024);
  Skein1024_Update(&ctx, (uint8_t*)"**", 2);
  Skein1024_Update(&ctx, key, key_len);
  Skein1024_Update(&ctx, (uint8_t*)"**", 2);
  Skein1024_Final(&ctx, (uint8_t*)Ctx.s);

  Xoroshiro1024ssBufferedStream.Index = Xoroshiro1024ssBufferedStream.Size;

  Xoroshiro1024ssInitialized = TRUE;
}

void Xoroshiro1024ssDeinit(void)
{
  VERIFY(Xoroshiro1024ssInitialized, "Xoroshiro1024** not initialized");

  Xoroshiro1024ssBufferedStream.Index = Xoroshiro1024ssBufferedStream.Size;

  Xoroshiro1024ssInitialized = FALSE;
}

void GenerateXoroshiro1024ssStream(void)
{
  VERIFY(Xoroshiro1024ssInitialized, "Xoroshiro1024** not initialized");

  uint64_t* p = (uint64_t*)Xoroshiro1024ssBufferedStream.Buffer;
  for (int i = 0;
       i < Xoroshiro1024ssBufferedStream.Size / (int)sizeof(uint64_t); ++i)
  {
    *p = Xoroshiro1024ssNext();
    ++p;
  }
}

uint8_t Xoroshiro1024ssRand8(void)
{
  uint8_t r = Extract8(&Xoroshiro1024ssBufferedStream);
  return r;
}

uint16_t Xoroshiro1024ssRand16(void)
{
  uint16_t r = Extract16(&Xoroshiro1024ssBufferedStream);
  return r;
}

uint32_t Xoroshiro1024ssRand32(void)
{
  uint32_t r = Extract32(&Xoroshiro1024ssBufferedStream);
  return r;
}

uint64_t Xoroshiro1024ssRand64(void)
{
  uint64_t r = Extract64(&Xoroshiro1024ssBufferedStream);
  return r;
}

void Xoroshiro1024ssRandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Xoroshiro1024ssBufferedStream, buffer, size);
}

void Xoroshiro1024ssRandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Xoroshiro1024ssBufferedStream, buffer, size);
}
