#pragma once

#include "basics.h"
#include "defines.h"

// #define QUICK_TEST

extern BOOL bVerifyEncryption;

extern uint8_t debugDecryptionOutput[MAX_FILE_DECRYPTION_OUT_SIZE];
