#pragma message("THIS IS EXAMPLE CODE.")

#pragma once

#include "hash.h"
#include "prng.h"

static const HashAlgo* CocktailHashs[] = {
  &Blake2b256Hasher,
  &Blake2b256Hasher,
  &Blake2s256Hasher,
  &Blake2s256Hasher,
  &Blake3_256Hasher,
  &Blake3_256Hasher,
  &Sha2_256Hasher,
  &Sha2_256Hasher,
  &Sha3_256Hasher,
  &Sha3_256Hasher,
  &Skein256Hasher,
  &Skein256Hasher,
};
static const PrngAlgo* CocktailPrngs[] = {
  &Isaac64Csprng,
  &Pcg64Prng,
  &Xoroshiro256ppPrng,
  &Xoroshiro512ppPrng,
  &Xoroshiro1024ppPrng,
};
static const HashAlgo* CocktailKeyHash = &Blake2b256Hasher;
