#include <string.h>

#include "cipher.h"

#include "aes/aes.h"

#include "chacha/ecrypt-portable.h"
#include "chacha/ecrypt-sync.h"

#include "debugging.h"

// AES CBC
// AES CBC chooses to use a 32-byte key and uses a 16-byte IV

#define IV16 16

int GetPkcsPaddedLength(int input_len, int block_size)
{
  int quotient = input_len / block_size;
  int r = (quotient + 1) * block_size;
  return r;
}

int AddPkcsPadding(uint8_t* input, int input_len, int block_size)
{
  int remainder = input_len % block_size;
  uint8_t paddingvalue = block_size - remainder;
  for (uint8_t i = 0; i < paddingvalue; ++i)
  {
    input[input_len + i] = paddingvalue;
  }
  return paddingvalue;
}

void VerifyPkcsPadding(uint8_t* buffer, int buffer_len, int block_size)
{
  uint8_t paddingvalue = buffer[buffer_len - 1];
  VERIFY(paddingvalue > 0 && paddingvalue <= block_size,
         "Bad PKCS padding value");
  for (uint8_t i = 1; i < paddingvalue; ++i)
  {
    VERIFY(buffer[buffer_len - 1 - i] == paddingvalue, "Bad PKCS padding");
  }
}

int Aes_Cbc_Encrypt(const uint8_t* input, int input_len, const uint8_t* key,
                    int key_len, const uint8_t* iv, int iv_len, uint8_t* output,
                    int output_size)
{
  VERIFY(input && input_len > 0, "Bad AES input");
  VERIFY(key && key_len >= 32, "Bad AES key");
  VERIFY(iv && iv_len >= IV16, "Bad AES IV");
  int input_padded_len = GetPkcsPaddedLength(input_len, AES_BLOCK_SIZE);
  VERIFY(input_padded_len + IV16 <= output_size, "Bad AES output size");
  VERIFY(input_padded_len <= MAX_FILE_ENCRYPTION_IN_SIZE, "Cannot AES encrypt");
  uint8_t input_padded[MAX_FILE_ENCRYPTION_IN_SIZE];
  memcpy(input_padded, input, input_len);
  AddPkcsPadding(input_padded, input_len, AES_BLOCK_SIZE);
  int output_len = input_padded_len;
  memcpy(output, iv, IV16);  // copy IV to the beginning of output
  output += IV16;            // make sure cipherdata is stored after IV
  output_len += IV16;        // length of IV plus length of cipherdata
  aes_encrypt_ctx ctx = {0};
  aes_encrypt_key256(key, &ctx);
  uint8_t iv_write[IV16];
  memcpy(iv_write, iv, IV16);
  aes_cbc_encrypt(input_padded, output, input_padded_len, iv_write, &ctx);
  // if (bVerifyEncryption)
  {
    VERIFY(output_len <= MAX_FILE_DECRYPTION_IN_SIZE,
           "Cannot verify AES encrypt");
    int decrypted_len = Aes_Cbc_Decrypt(output - IV16, output_len, key, key_len,
                                        debugDecryptionOutput,
                                        (int)sizeof(debugDecryptionOutput));
    VERIFY(decrypted_len == input_len &&
             memcmp(input, debugDecryptionOutput, input_len) == 0,
           "Error verifying AES encrypt");
  }
  return output_len;
}

int Aes_Cbc_Decrypt(const uint8_t* input, int input_len, const uint8_t* key,
                    int key_len, uint8_t* output, int output_size)
{
  VERIFY(input && input_len >= 32 && input_len % IV16 == 0, "Bad AES input");
  VERIFY(key && key_len >= 32, "Bad AES key");
  VERIFY(input_len - IV16 <= output_size, "Bad AES output size");
  aes_decrypt_ctx ctx = {0};
  aes_decrypt_key256(key, &ctx);
  uint8_t iv_write[IV16];
  memcpy(iv_write, input, IV16);  // the beginning of input is IV
  input += IV16;                  // make sure cipherdata is passed
  input_len -= IV16;              // make sure length of cipherdata is correct
  AES_RETURN r = aes_cbc_decrypt(input, output, input_len, iv_write, &ctx);
  VERIFY(r == EXIT_SUCCESS, "AES decryption failed");
  VerifyPkcsPadding(output, input_len, AES_BLOCK_SIZE);
  int output_len = input_len - output[input_len - 1];
  return output_len;
}

int Bald_Aes_Cbc_Encrypt(const uint8_t* input, int input_len,
                         const uint8_t* key, int key_len, const uint8_t* iv,
                         int iv_len, uint8_t* output, int output_size)
{
  VERIFY(input && input_len > 0, "Bad AES input");
  VERIFY(key && key_len >= 32, "Bad AES key");
  VERIFY(iv && iv_len >= IV16, "Bad AES IV");
  int input_padded_len = GetPkcsPaddedLength(input_len, AES_BLOCK_SIZE);
  VERIFY(input_padded_len <= output_size, "Bad AES output size");
  VERIFY(input_padded_len <= MAX_FILE_ENCRYPTION_IN_SIZE, "Cannot AES encrypt");
  uint8_t input_padded[MAX_FILE_ENCRYPTION_IN_SIZE];
  memcpy(input_padded, input, input_len);
  AddPkcsPadding(input_padded, input_len, AES_BLOCK_SIZE);
  int output_len = input_padded_len;
  aes_encrypt_ctx ctx = {0};
  aes_encrypt_key256(key, &ctx);
  uint8_t iv_write[IV16];
  memcpy(iv_write, iv, IV16);
  aes_cbc_encrypt(input_padded, output, input_padded_len, iv_write, &ctx);
  // if (bVerifyEncryption)
  {
    VERIFY(output_len <= MAX_FILE_DECRYPTION_IN_SIZE,
           "Cannot verify AES encrypt");
    int decrypted_len = Bald_Aes_Cbc_Decrypt(
      output, output_len, key, key_len, iv, debugDecryptionOutput,
      (int)sizeof(debugDecryptionOutput));
    VERIFY(decrypted_len == input_len &&
             memcmp(input, debugDecryptionOutput, input_len) == 0,
           "Error verifying AES encrypt");
  }
  return output_len;
}

int Bald_Aes_Cbc_Decrypt(const uint8_t* input, int input_len,
                         const uint8_t* key, int key_len, const uint8_t* iv,
                         uint8_t* output, int output_size)
{
  VERIFY(input && input_len >= 16 && input_len % IV16 == 0, "Bad AES input");
  VERIFY(key && key_len >= 32, "Bad AES key");
  VERIFY(input_len <= output_size, "Bad AES output size");
  aes_decrypt_ctx ctx = {0};
  aes_decrypt_key256(key, &ctx);
  uint8_t iv_write[IV16];
  memcpy(iv_write, iv, IV16);
  AES_RETURN r = aes_cbc_decrypt(input, output, input_len, iv_write, &ctx);
  VERIFY(r == EXIT_SUCCESS, "AES decryption failed");
  VerifyPkcsPadding(output, input_len, AES_BLOCK_SIZE);
  int output_len = input_len - output[input_len - 1];
  return output_len;
}

// Chacha20
// Chacha20 uses a 32-byte key and a 12-byte IV/nonce

#define IV12 12

int Chacha20_Encrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, const uint8_t* iv, int iv_len,
                     uint8_t* output, int output_size)
{
  VERIFY(input && input_len > 0, "Bad Chacha20 input");
  VERIFY(key && key_len >= 32, "Bad Chacha20 key");
  VERIFY(iv && iv_len >= IV12, "Bad Chacha20 IV");
  VERIFY(input_len + IV12 <= output_size, "Bad Chacha20 output size");
  int output_len;
  memcpy(output, iv, IV12);       // copy IV to the beginning of output
  output += IV12;                 // make sure cipherdata is stored after IV
  output_len = IV12 + input_len;  // length of IV plus length of cipherdata
  ECRYPT_ctx ctx = {0};
  ECRYPT_keysetup(&ctx, key, 256, 16);
  ctx.input[12] = 1;
  ctx.input[13] = U8TO32_LITTLE(iv + 0);
  ctx.input[14] = U8TO32_LITTLE(iv + 4);
  ctx.input[15] = U8TO32_LITTLE(iv + 8);
  ECRYPT_encrypt_bytes(&ctx, input, output, input_len);
  // if (bVerifyEncryption)
  {
    VERIFY(input_len <= (int)sizeof(debugDecryptionOutput),
           "Cannot verify Chacha20 encrypt");
    output -= IV12;
    int decrypted_len =
      Chacha20_Decrypt(output, output_len, key, key_len, debugDecryptionOutput,
                       (int)sizeof(debugDecryptionOutput));
    VERIFY(decrypted_len == input_len &&
             memcmp(input, debugDecryptionOutput, input_len) == 0,
           "Error verifying Chacha20 encrypt");
  }
  return output_len;
}

int Chacha20_Decrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output, int output_size)
{
  VERIFY(input && input_len > IV12, "Bad Chacha20 input");
  VERIFY(key && key_len >= 32, "Bad Chacha20 key");
  VERIFY(input_len - IV12 <= output_size, "Bad Chacha20 output size");
  ECRYPT_ctx ctx = {0};
  ECRYPT_keysetup(&ctx, key, 256, 16);
  ctx.input[12] = 1;
  ctx.input[13] = U8TO32_LITTLE(input + 0);
  ctx.input[14] = U8TO32_LITTLE(input + 4);
  ctx.input[15] = U8TO32_LITTLE(input + 8);
                      // the beginning of input is IV
  input += IV12;      // make sure cipherdata is passed
  input_len -= IV12;  // make sure length of cipherdata is correct
  ECRYPT_decrypt_bytes(&ctx, input, output, input_len);
  return input_len;
}

int Bald_Chacha20_Encrypt(const uint8_t* input, int input_len,
                          const uint8_t* key, int key_len, const uint8_t* iv,
                          int iv_len, uint8_t* output, int output_size)
{
  VERIFY(input && input_len > 0, "Bad Chacha20 input");
  VERIFY(key && key_len >= 32, "Bad Chacha20 key");
  VERIFY(iv && iv_len >= IV12, "Bad Chacha20 IV");
  VERIFY(input_len <= output_size, "Bad Chacha20 output size");
  int output_len = input_len;
  ECRYPT_ctx ctx = {0};
  ECRYPT_keysetup(&ctx, key, 256, 16);
  ctx.input[12] = 1;
  ctx.input[13] = U8TO32_LITTLE(iv + 0);
  ctx.input[14] = U8TO32_LITTLE(iv + 4);
  ctx.input[15] = U8TO32_LITTLE(iv + 8);
  ECRYPT_encrypt_bytes(&ctx, input, output, input_len);
  // if (bVerifyEncryption)
  {
    VERIFY(input_len <= (int)sizeof(debugDecryptionOutput),
           "Cannot verify Chacha20 encrypt");
    int decrypted_len = Bald_Chacha20_Decrypt(
      output, output_len, key, key_len, iv, debugDecryptionOutput,
      (int)sizeof(debugDecryptionOutput));
    VERIFY(decrypted_len == input_len &&
             memcmp(input, debugDecryptionOutput, input_len) == 0,
           "Error verifying Chacha20 encrypt");
  }
  return output_len;
}

int Bald_Chacha20_Decrypt(const uint8_t* input, int input_len,
                          const uint8_t* key, int key_len, const uint8_t* iv,
                          uint8_t* output, int output_size)
{
  VERIFY(input && input_len > 0, "Bad Chacha20 input");
  VERIFY(key && key_len >= 32, "Bad Chacha20 key");
  VERIFY(input_len <= output_size, "Bad Chacha20 output size");
  ECRYPT_ctx ctx = {0};
  ECRYPT_keysetup(&ctx, key, 256, 16);
  ctx.input[12] = 1;
  ctx.input[13] = U8TO32_LITTLE(iv + 0);
  ctx.input[14] = U8TO32_LITTLE(iv + 4);
  ctx.input[15] = U8TO32_LITTLE(iv + 8);
  ECRYPT_decrypt_bytes(&ctx, input, output, input_len);
  return input_len;
}
