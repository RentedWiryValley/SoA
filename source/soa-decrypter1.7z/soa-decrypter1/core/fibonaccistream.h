#pragma once

#include "basic_prng.h"

void FibonacciInit(const uint8_t* key, int key_len);
void FibonacciDeinit(void);
uint8_t FibonacciRand8(void);
uint16_t FibonacciRand16(void);
uint32_t FibonacciRand32(void);
uint64_t FibonacciRand64(void);
void FibonacciRandBuffer(uint8_t* buffer, int size);
void FibonacciRandXorBuffer(uint8_t* buffer, int size);
