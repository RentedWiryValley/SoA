#pragma once

#include "basic_cipher.h"

// AES CBC
int Aes_Cbc_Encrypt(const uint8_t* input, int input_len, const uint8_t* key,
                    int key_len, const uint8_t* iv, int iv_len, uint8_t* output,
                    int output_size);
int Aes_Cbc_Decrypt(const uint8_t* input, int input_len, const uint8_t* key,
                    int key_len, uint8_t* output, int output_size);
// output without IV
int Bald_Aes_Cbc_Encrypt(const uint8_t* input, int input_len,
                         const uint8_t* key, int key_len, const uint8_t* iv,
                         int iv_len, uint8_t* output, int output_size);
int Bald_Aes_Cbc_Decrypt(const uint8_t* input, int input_len,
                         const uint8_t* key, int key_len, const uint8_t* iv,
                         uint8_t* output, int output_size);

// Chacha20
int Chacha20_Encrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, const uint8_t* iv, int iv_len,
                     uint8_t* output, int output_size);
int Chacha20_Decrypt(const uint8_t* input, int input_len, const uint8_t* key,
                     int key_len, uint8_t* output, int output_size);
// output without IV
int Bald_Chacha20_Encrypt(const uint8_t* input, int input_len,
                          const uint8_t* key, int key_len, const uint8_t* iv,
                          int iv_len, uint8_t* output, int output_size);
int Bald_Chacha20_Decrypt(const uint8_t* input, int input_len,
                          const uint8_t* key, int key_len, const uint8_t* iv,
                          uint8_t* output, int output_size);

