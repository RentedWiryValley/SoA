#pragma once

#include "basic_prng.h"

void Pcg64Init(const uint8_t* key, int key_len);
void Pcg64Deinit(void);
uint8_t Pcg64Rand8(void);
uint16_t Pcg64Rand16(void);
uint32_t Pcg64Rand32(void);
uint64_t Pcg64Rand64(void);
void Pcg64RandBuffer(uint8_t* buffer, int size);
void Pcg64RandXorBuffer(uint8_t* buffer, int size);
