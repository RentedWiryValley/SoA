#pragma once

#include "basics.h"
#include "xoroshiro.h"

typedef struct _Xoroshiro1024Ctx
{
  int p;
  uint64_t s[16];
} Xoroshiro1024Ctx;

#define XOROSHIRO1024_KEY_SIZE ((int)sizeof(((Xoroshiro1024Ctx*)0)->s))
