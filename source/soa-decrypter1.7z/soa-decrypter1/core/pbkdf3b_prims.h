#pragma message("THIS IS EXAMPLE CODE.")

#pragma once

#include "hash.h"

// 256-bit

#define MainHasher256 Skein256Hasher
static const HashFunc Hash256Funcs[] = {Blake2b_256, Blake3_256, Sha2_256};
static const int Hash256FuncCount = sizeof(Hash256Funcs) / sizeof(Hash256Funcs[0]);

// 512-bit

#define MainHasher512 Skein512Hasher
static const HashFunc Hash512Funcs[] = {Blake2b_512, Blake3_512, Sha2_512};
static const int Hash512FuncCount = sizeof(Hash512Funcs) / sizeof(Hash512Funcs[0]);
