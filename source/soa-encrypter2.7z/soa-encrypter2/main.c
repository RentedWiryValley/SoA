#include <stdio.h>
#include <string.h>

#include "cascade.h"
#include "cipher.h"
#include "cocktail.h"
#include "common.h"
#include "hash.h"
#include "mhkdf.h"
#include "utils.h"

#define MAX_FILE_SIZE 65536
#define UNIT_MEMORY_SIZE (1024 * 1024)

static const HashAlgo* MhkdfHashers[] = {
  &Sha2_512Hasher,    &WhirlpoolHasher,  &Blake2b512Hasher, &Skein512Hasher,
  &xBlake2s512Hasher, &Blake3_512Hasher, &Sha3_512Hasher,
};

void GetParameters(char* pass, char* salt, int* iterations, int* alpharounds,
                   int* bravorounds)
{
  EnterText("Enter password:", pass, sizeof(pass));

  EnterText("Enter KDF salt:", salt, sizeof(salt));

  uint64_t memorysize = EnterPositiveInteger("Enter MHKDF memory size (MB):");
  memorysize *= UNIT_MEMORY_SIZE;

  int rounds = EnterPositiveInteger("Enter MHKDF rounds:");

  *iterations = EnterPositiveInteger("Enter PBKDF iterations:");

  *alpharounds = EnterPositiveInteger("Enter Alpha rounds:");

  *bravorounds = EnterPositiveInteger("Enter Bravo rounds:");

  printf("Deriving key with %ld MB / %ld GB of memory...\n",
         memorysize / UNIT_MEMORY_SIZE, memorysize / UNIT_MEMORY_SIZE / 1024);
  uint8_t key[BYTES_1024_BITS];
  Mhkdf(MhkdfHashers, sizeof(MhkdfHashers) / sizeof(MhkdfHashers[0]),
        memorysize, (uint8_t*)pass, strlen(pass), (uint8_t*)salt, strlen(salt),
        rounds, key);
  ByteArrayToHexString(key, MhkdfHashers[0]->OutputSize, pass);
  ClearMemory(key, sizeof(key));
}

void CascadeEncryptFile(void)
{
  char infilename[256], outfilename[256];
  uint8_t input[MAX_FILE_SIZE], output[MAX_FILE_SIZE];
  int input_len, output_len;
  FILE* fp;

  EnterText("Enter input file name:", infilename, sizeof(infilename));
  fp = fopen(infilename, "rb");
  VERIFY(fp, "Failed opening input file");
  fseek(fp, 0L, SEEK_END);
  input_len = (int)ftell(fp);
  VERIFY(input_len < (int)sizeof(input), "Input file too big");
  fseek(fp, 0L, SEEK_SET);
  int read = (int)fread(input, 1, input_len, fp);
  VERIFY(read == input_len, "Error reading input file");
  fclose(fp);

  EnterText("Enter output file name:", outfilename, sizeof(outfilename));
  fp = fopen(outfilename, "wb");
  VERIFY(fp, "Failed opening output file");

  char pass[256], salt[256];
  int iterations, alpharounds, bravorounds;
  GetParameters(pass, salt, &iterations, &alpharounds, &bravorounds);

  output_len =
    CascadeEncrypt(input, input_len, pass, salt, &iterations, &alpharounds,
                   &bravorounds, output, sizeof(output));
  VERIFY(output_len > 0, "Cascade encryption failed");

  int write = fwrite(output, 1, output_len, fp);
  VERIFY(write == output_len, "Error writing output file");
  fclose(fp);

  printf("\nFile %s is successfully encrypted and saved to %s.\n", infilename,
         outfilename);
}

void CascadeDecryptFile(void)
{
  char infilename[256], outfilename[256];
  uint8_t input[MAX_FILE_SIZE], output[MAX_FILE_SIZE];
  int input_len, output_len;
  FILE* fp;

  EnterText("Enter input file name:", infilename, sizeof(infilename));
  fp = fopen(infilename, "rb");
  VERIFY(fp, "Failed opening input file");
  fseek(fp, 0L, SEEK_END);
  input_len = (int)ftell(fp);
  VERIFY(input_len < (int)sizeof(input), "Input file too big");
  fseek(fp, 0L, SEEK_SET);
  int read = (int)fread(input, 1, input_len, fp);
  VERIFY(read == input_len, "Error reading input file");
  fclose(fp);

  EnterText("Enter output file name:", outfilename, sizeof(outfilename));
  fp = fopen(outfilename, "wb");
  VERIFY(fp, "Failed opening output file");

  char pass[256], salt[256];
  int iterations, alpharounds, bravorounds;
  GetParameters(pass, salt, &iterations, &alpharounds, &bravorounds);

  output_len =
    CascadeDecrypt(input, input_len, pass, salt, &iterations, &alpharounds,
                   &bravorounds, output, sizeof(output));
  VERIFY(output_len > 0, "Cascade decryption failed");

  int write = fwrite(output, 1, output_len, fp);
  VERIFY(write == output_len, "Error writing output file");
  fclose(fp);

  printf("\nFile %s is successfully decrypted and saved to %s.\n", infilename,
         outfilename);
}

int main(void)
{
  printf("File encrypter/decrypter 2 for SoA\n");
  printf("\n");
  printf("Options:\n");
  printf("- 'E' or 'e' for encryption\n");
  printf("- 'D' or 'd' for decryption\n");
  printf("\n");

  char option[256];

  EnterText("Choose your option:", option, sizeof(option));

  printf("\n");

  if (option[0] == 'E' || option[0] == 'e')
    CascadeEncryptFile();
  else if (option[0] == 'D' || option[0] == 'd')
    CascadeDecryptFile();

  return 0;
}
