#pragma once

#include "basic_prng.h"

void Xoroshiro256ppInit(const uint8_t* key, int key_len);
void Xoroshiro256ppDeinit(void);
uint8_t Xoroshiro256ppRand8(void);
uint16_t Xoroshiro256ppRand16(void);
uint32_t Xoroshiro256ppRand32(void);
uint64_t Xoroshiro256ppRand64(void);
void Xoroshiro256ppRandBuffer(uint8_t* buffer, int size);
void Xoroshiro256ppRandXorBuffer(uint8_t* buffer, int size);
