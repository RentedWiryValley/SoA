#pragma once

#include "basics.h"

typedef int (*EncryptFunc)(const uint8_t* input, int input_len,
                           const uint8_t* key, int key_len, const uint8_t* iv,
                           int iv_len, uint8_t* output, int output_size);
typedef int (*DecryptFunc)(const uint8_t* input, int input_len,
                           const uint8_t* key, int key_len, uint8_t* output,
                           int output_size);
