#pragma once

#include "basic_prng.h"

extern const PrngAlgo Isaac64Csprng;
extern const PrngAlgo IsaacCsprng;
extern const PrngAlgo Pcg32Prng;
extern const PrngAlgo Pcg64Prng;
extern const PrngAlgo Xoroshiro256ppPrng;
extern const PrngAlgo Xoroshiro256ssPrng;
extern const PrngAlgo Xoroshiro512ppPrng;
extern const PrngAlgo Xoroshiro512pPrng;
extern const PrngAlgo Xoroshiro512ssPrng;
extern const PrngAlgo Xoroshiro1024ppPrng;
extern const PrngAlgo Xoroshiro1024ssPrng;
extern const PrngAlgo Xoroshiro1024sPrng;
extern const PrngAlgo FibonacciNrng;
extern const PrngAlgo DummyNrng;
