#include <string.h>

#include "pbkdf3.h"
#include "pbkdf3_prims.h"

#include "memxor.h"

// 256-bit

const PbkdfHashAlgo Pbkdf3_256Hasher = {.OutputSize = Bytes256Bits,
                                        .InitFunc = Pbkdf3_256_Init,
                                        .UpdateFunc = Pbkdf3_256_Update,
                                        .FinalFunc = Pbkdf3_256_Final,
                                        .HashFunc = Pbkdf3_256};

void Pbkdf3_256_Init_Ctx(PBKDF3_256_CTX* ctx, const uint8_t* pass, int pass_len,
                         const uint8_t* salt, int salt_len)
{
  MainHasher256.HashFunc(pass, pass_len, ctx->passhash);
  MainHasher256.HashFunc(salt, salt_len, ctx->salthash);
  MainHasher256.InitFunc();
  MainHasher256.UpdateFunc(pass, pass_len);
  MainHasher256.UpdateFunc(salt, salt_len);
}

void Pbkdf3_256_Update_Ctx(PBKDF3_256_CTX* ctx, int iterations)
{
  for (int i = 0; i < iterations; ++i)
  {
    MainHasher256.UpdateFunc(ctx->passhash, sizeof(ctx->passhash));
    MainHasher256.UpdateFunc(ctx->salthash, sizeof(ctx->salthash));
  }
}

void Pbkdf3_256_Final_Ctx(PBKDF3_256_CTX* ctx, uint8_t* key)
{
  uint8_t output[BYTES_256_BITS];
  MainHasher256.FinalFunc(output);
  memcpy(key, output, BYTES_256_BITS);
  memxor(ctx->passhash, output, sizeof(ctx->passhash));
  MainHasher256.HashFunc(ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  MainHasher256.HashFunc(ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  memxor(key, ctx->passhash, BYTES_256_BITS);
  memxor(ctx->salthash, output, sizeof(ctx->salthash));
  MainHasher256.HashFunc(ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  MainHasher256.HashFunc(ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  memxor(key, ctx->salthash, BYTES_256_BITS);
  ClearMemory(output, sizeof(output));
  ClearMemory(ctx, sizeof(PBKDF3_256_CTX));
}

static PBKDF3_256_CTX Pbkdf3_256_Ctx = {0};

void Pbkdf3_256_Init(const uint8_t* pass, int pass_len, const uint8_t* salt,
                     int salt_len)
{
  ClearMemory(&Pbkdf3_256_Ctx, sizeof(Pbkdf3_256_Ctx));
  Pbkdf3_256_Init_Ctx(&Pbkdf3_256_Ctx, pass, pass_len, salt, salt_len);
}

void Pbkdf3_256_Update(int iterations)
{
  Pbkdf3_256_Update_Ctx(&Pbkdf3_256_Ctx, iterations);
}

void Pbkdf3_256_Final(uint8_t* output)
{
  Pbkdf3_256_Final_Ctx(&Pbkdf3_256_Ctx, output);
}

void Pbkdf3_256(const uint8_t* pass, int pass_len, const uint8_t* salt,
                int salt_len, int iterations, uint8_t* output)
{
  PBKDF3_256_CTX ctx = {0};
  ClearMemory(&ctx, sizeof(ctx));
  Pbkdf3_256_Init_Ctx(&ctx, pass, pass_len, salt, salt_len);
  Pbkdf3_256_Update_Ctx(&ctx, iterations);
  Pbkdf3_256_Final_Ctx(&ctx, output);
}

// 512-bit

const PbkdfHashAlgo Pbkdf3_512Hasher = {.OutputSize = Bytes512Bits,
                                        .InitFunc = Pbkdf3_512_Init,
                                        .UpdateFunc = Pbkdf3_512_Update,
                                        .FinalFunc = Pbkdf3_512_Final,
                                        .HashFunc = Pbkdf3_512};

void Pbkdf3_512_Init_Ctx(PBKDF3_512_CTX* ctx, const uint8_t* pass, int pass_len,
                         const uint8_t* salt, int salt_len)
{
  MainHasher512.HashFunc(pass, pass_len, ctx->passhash);
  MainHasher512.HashFunc(salt, salt_len, ctx->salthash);
  MainHasher512.InitFunc();
  MainHasher512.UpdateFunc(pass, pass_len);
  MainHasher512.UpdateFunc(salt, salt_len);
}

void Pbkdf3_512_Update_Ctx(PBKDF3_512_CTX* ctx, int iterations)
{
  for (int i = 0; i < iterations; ++i)
  {
    MainHasher512.UpdateFunc(ctx->passhash, sizeof(ctx->passhash));
    MainHasher512.UpdateFunc(ctx->salthash, sizeof(ctx->salthash));
  }
}

void Pbkdf3_512_Final_Ctx(PBKDF3_512_CTX* ctx, uint8_t* key)
{
  uint8_t output[BYTES_512_BITS];
  MainHasher512.FinalFunc(output);
  memcpy(key, output, BYTES_512_BITS);
  memxor(ctx->passhash, output, sizeof(ctx->passhash));
  MainHasher512.HashFunc(ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  MainHasher512.HashFunc(ctx->passhash, sizeof(ctx->passhash), ctx->passhash);
  memxor(key, ctx->passhash, BYTES_512_BITS);
  memxor(ctx->salthash, output, sizeof(ctx->salthash));
  MainHasher512.HashFunc(ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  MainHasher512.HashFunc(ctx->salthash, sizeof(ctx->salthash), ctx->salthash);
  memxor(key, ctx->salthash, BYTES_512_BITS);
  ClearMemory(output, sizeof(output));
  ClearMemory(ctx, sizeof(PBKDF3_512_CTX));
}

static PBKDF3_512_CTX Pbkdf3_512_Ctx = {0};

void Pbkdf3_512_Init(const uint8_t* pass, int pass_len, const uint8_t* salt,
                     int salt_len)
{
  ClearMemory(&Pbkdf3_512_Ctx, sizeof(Pbkdf3_512_Ctx));
  Pbkdf3_512_Init_Ctx(&Pbkdf3_512_Ctx, pass, pass_len, salt, salt_len);
}

void Pbkdf3_512_Update(int iterations)
{
  Pbkdf3_512_Update_Ctx(&Pbkdf3_512_Ctx, iterations);
}

void Pbkdf3_512_Final(uint8_t* output)
{
  Pbkdf3_512_Final_Ctx(&Pbkdf3_512_Ctx, output);
}

void Pbkdf3_512(const uint8_t* pass, int pass_len, const uint8_t* salt,
                int salt_len, int iterations, uint8_t* output)
{
  PBKDF3_512_CTX ctx = {0};
  ClearMemory(&ctx, sizeof(ctx));
  Pbkdf3_512_Init_Ctx(&ctx, pass, pass_len, salt, salt_len);
  Pbkdf3_512_Update_Ctx(&ctx, iterations);
  Pbkdf3_512_Final_Ctx(&ctx, output);
}
