#pragma once

#include "hash.h"
#include "prng.h"

static const HashAlgo* CocktailHashs[] = {
  &Skein256Hasher,
  &Sha2_256Hasher,
  &Blake3_256Hasher,
  &Blake2b256Hasher,
  &Blake2s256Hasher,
  &Sha3_256Hasher,
  &Skein256Hasher,
  &Sha2_256Hasher,
  &Blake3_256Hasher,
  &Blake2b256Hasher,
  &Blake2s256Hasher,
  &Sha3_256Hasher,
};
static const PrngAlgo* CocktailPrngs[] = {
  &IsaacCsprng,
  &Xoroshiro1024ssPrng,
};
static const HashAlgo* CocktailKeyHash = &Blake2b256Hasher;
