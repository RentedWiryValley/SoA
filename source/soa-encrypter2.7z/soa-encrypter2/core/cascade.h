#pragma once

#include "basics.h"

// All inputs, except cipherdata, are cleared in the process of encryption and
// decryption.

int CascadeEncrypt(uint8_t* plaindata, int plaindata_len, char* password,
                   char* pbkdf_salt, int* pbkdf_iterations, int* alpha_rounds,
                   int* bravo_rounds, uint8_t* output, int output_size);
int CascadeDecrypt(const uint8_t* cipherdata, int cipherdata_len,
                   char* password, char* pbkdf_salt, int* pbkdf_iterations,
                   int* alpha_rounds, int* bravo_rounds, uint8_t* output,
                   int output_size);
