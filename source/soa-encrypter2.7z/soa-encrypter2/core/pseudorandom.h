#pragma once

#include "basic_cipher.h"
#include "basic_hash.h"
#include "basic_prng.h"

// At least two primitives are required.
// Order of hash algos matters. Repitition is OK.
// Order of PRNGs matters. Repitition is OK.
void PseudorandomInit(const uint8_t* key, int key_len, const HashAlgo* hashs[],
                      int hash_count, const PrngAlgo* prngs[], int prng_count,
                      const HashAlgo* key_hash);
void PseudorandomDeinit(void);

uint8_t Pseudorandom8(void);
uint16_t Pseudorandom16(void);
uint32_t Pseudorandom32(void);
uint64_t Pseudorandom64(void);

uint8_t UnbiasedPseudorandom8(uint8_t ceiling);
uint16_t UnbiasedPseudorandom16(uint16_t ceiling);
uint32_t UnbiasedPseudorandom32(uint32_t ceiling);
uint64_t UnbiasedPseudorandom64(uint64_t ceiling);

void PseudorandomBuffer(uint8_t* buffer, size_t size);
