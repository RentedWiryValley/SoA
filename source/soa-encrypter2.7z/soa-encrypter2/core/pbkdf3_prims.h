#pragma once

#include "hash.h"

// 256-bit

#define MainHasher256 Sha3_256Hasher

// 512-bit

#define MainHasher512 Sha3_512Hasher
