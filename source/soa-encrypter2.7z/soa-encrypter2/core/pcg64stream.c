#include "pcg64stream.h"

#include "bufferedstream.h"
#include "hash.h"

#include "pcg_variants.h"

const PrngAlgo Pcg64Prng = {.InitFunc = Pcg64Init,
                            .DeinitFunc = Pcg64Deinit,
                            .GetUint8Func = Pcg64Rand8,
                            .GetUint16Func = Pcg64Rand16,
                            .GetUint32Func = Pcg64Rand32,
                            .GetUint64Func = Pcg64Rand64,
                            .BufferFunc = Pcg64RandBuffer,
                            .XorBufferFunc = Pcg64RandXorBuffer};

void GeneratePcg64Stream(void);

static BufferedStream Pcg64BufferedStream = {
  .Size = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Index = MAX_BUFFEREDSTREAM_BUFFER_SIZE,
  .Refresh = GeneratePcg64Stream};

static pcg64_random_t Ctx = {0};
static BOOL Pcg64Initialized = FALSE;

void Pcg64Init(const uint8_t* key, int key_len)
{
  VERIFY(!Pcg64Initialized, "PCG64 already initialized");
  VERIFY(key && key_len > 0, "Bad PCG64 key!");

  uint8_t hash[BYTES_256_BITS];
  Sha3_256(key, key_len, hash);

  pcg64_srandom_r(&Ctx, *((pcg128_t*)hash),
                  *((pcg128_t*)(hash + sizeof(pcg128_t))));

  Pcg64BufferedStream.Index = Pcg64BufferedStream.Size;

  Pcg64Initialized = TRUE;
}

void Pcg64Deinit(void)
{
  VERIFY(Pcg64Initialized, "PCG64 not initialized");

  Pcg64BufferedStream.Index = Pcg64BufferedStream.Size;

  Pcg64Initialized = FALSE;
}

void GeneratePcg64Stream(void)
{
  VERIFY(Pcg64Initialized, "PCG64 not initialized");

  uint64_t* p = (uint64_t*)Pcg64BufferedStream.Buffer;
  for (int i = 0; i < Pcg64BufferedStream.Size / (int)sizeof(uint64_t); ++i)
  {
    *p = pcg64_random_r(&Ctx);
    ++p;
  }
}

uint8_t Pcg64Rand8(void)
{
  uint8_t r = Extract8(&Pcg64BufferedStream);
  return r;
}

uint16_t Pcg64Rand16(void)
{
  uint16_t r = Extract16(&Pcg64BufferedStream);
  return r;
}

uint32_t Pcg64Rand32(void)
{
  uint32_t r = Extract32(&Pcg64BufferedStream);
  return r;
}

uint64_t Pcg64Rand64(void)
{
  uint64_t r = Extract64(&Pcg64BufferedStream);
  return r;
}

void Pcg64RandBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractToBuffer(&Pcg64BufferedStream, buffer, size);
}

void Pcg64RandXorBuffer(uint8_t* buffer, int size)
{
  if (size <= 0)
    return;
  ExtractXorBuffer(&Pcg64BufferedStream, buffer, size);
}
