#pragma once

#include "basic_prng.h"

void IsaacInit(const uint8_t* key, int key_len);
void IsaacDeinit(void);
uint8_t IsaacRand8(void);
uint16_t IsaacRand16(void);
uint32_t IsaacRand32(void);
uint64_t IsaacRand64(void);
void IsaacRandBuffer(uint8_t* buffer, int size);
void IsaacRandXorBuffer(uint8_t* buffer, int size);
