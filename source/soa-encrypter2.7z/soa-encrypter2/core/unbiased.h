#pragma once

#include "basics.h"

uint8_t Unbiased8(GetUint8Func random8func, uint8_t ceiling);
uint16_t Unbiased16(GetUint16Func random16func, uint16_t ceiling);
uint32_t Unbiased32(GetUint32Func random32func, uint32_t ceiling);
uint64_t Unbiased64(GetUint64Func random64func, uint64_t ceiling);
