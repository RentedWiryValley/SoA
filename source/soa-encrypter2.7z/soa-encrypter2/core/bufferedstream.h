#pragma once

#include "basics.h"

#define MAX_BUFFEREDSTREAM_BUFFER_SIZE 512

typedef void (*RefreshBufferedStreamFunc)(void);

typedef struct _BufferedStream
{
  uint8_t Buffer[MAX_BUFFEREDSTREAM_BUFFER_SIZE];
  int Size;
  int Index;
  RefreshBufferedStreamFunc Refresh;
} BufferedStream;

uint8_t Extract8(BufferedStream* stream);
uint16_t Extract16(BufferedStream* stream);
uint32_t Extract32(BufferedStream* stream);
uint64_t Extract64(BufferedStream* stream);

void ExtractToBuffer(BufferedStream* stream, uint8_t* buffer, int size);
void ExtractXorBuffer(BufferedStream* stream, uint8_t* buffer, int size);
