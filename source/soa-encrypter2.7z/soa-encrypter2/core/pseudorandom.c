#include <string.h>

#include "pseudorandom.h"

#include "bufferedstream.h"
#include "memxor.h"
#include "unbiased.h"

#define MAX_HASH_SIZE BYTES_1024_BITS
#define PSEUDORANDOM_BUFFER_SIZE MAX_HASH_SIZE

#define HASH_INPUT_SIZE 16

#if MAX_HASH_SIZE < HASH_INPUT_SIZE
#error MAX_HASH_SIZE < HASH_INPUT_SIZE
#endif

struct PseudorandomCtx
{
  const HashAlgo** HashAlgos;
  int HashAlgoCount;
  const PrngAlgo** PrngAlgos;
  int PrngAlgoCount;
  BufferedStream HashStream;
  uint32_t HashIndex;
  uint8_t HashKey[HASH_INPUT_SIZE];
  uint8_t HashExt[HASH_INPUT_SIZE];
  const HashAlgo* HashExtAlgo;
};

static struct PseudorandomCtx PseudorandomCtx = {0};
static BOOL PseudorandomInitialized = FALSE;

void GeneratePseudorandomHashStream(void)
{
  VERIFY(PseudorandomInitialized, "Pseudorandom not initialized");

  ClearMemory(PseudorandomCtx.HashStream.Buffer,
              PseudorandomCtx.HashStream.Size);

  uint8_t hash[MAX_HASH_SIZE];

  ClearMemory(hash, sizeof(hash));
  *((uint32_t*)hash) = PseudorandomCtx.HashIndex;

  for (int i = 0; i < PseudorandomCtx.HashAlgoCount; ++i)
  {
    const HashAlgo* hasher = PseudorandomCtx.HashAlgos[i];
    hasher->InitFunc();

    /*
    - With different HashIndex values as input, every algo works independently.
    - With the last hash value as input, the order of the algos matters.
    - With HashIndex and the last hash value, repitition of algos is OK.
    - With different values on both sides of the key (HashIndex and the last
    hash value), the dependence on avalanche effect's potency is minimized.
    - With HashExt, it withstands state compromise extensions.
    */
    hasher->UpdateFunc((uint8_t*)&PseudorandomCtx.HashIndex,
                       sizeof(PseudorandomCtx.HashIndex));
    hasher->UpdateFunc(PseudorandomCtx.HashKey,
                       sizeof(PseudorandomCtx.HashKey));
    hasher->UpdateFunc(hash, sizeof(PseudorandomCtx.HashIndex) + 1);
    hasher->UpdateFunc(PseudorandomCtx.HashExt,
                       sizeof(PseudorandomCtx.HashExt));

    hasher->FinalFunc(hash);

    memxor(PseudorandomCtx.HashStream.Buffer, hash,
           PseudorandomCtx.HashStream.Size);

    ++PseudorandomCtx.HashIndex;
  }

  PseudorandomCtx.HashExtAlgo->HashFunc(PseudorandomCtx.HashExt,
                                        sizeof(PseudorandomCtx.HashExt), hash);
  memcpy(PseudorandomCtx.HashExt, hash, sizeof(PseudorandomCtx.HashExt));

  ClearMemory(hash, sizeof(hash));
}

void PseudorandomInit(const uint8_t* key, int key_len, const HashAlgo* hashs[],
                      int hash_count, const PrngAlgo* prngs[], int prng_count,
                      const HashAlgo* key_hash)
{
  PseudorandomInitialized = FALSE;

  VERIFY(key && key_len > 0, "Bad pseudorandom key!");
  VERIFY(hashs || hash_count <= 0, "Bad pseudorandom hash algos!");
  VERIFY(prngs || prng_count <= 0, "Bad pseudorandom prng algos!");
  VERIFY(key_hash, "Bad pseudorandom key hash algo!");
  VERIFY(hash_count + prng_count >= 2, "Bad pseudorandom parameters!");

  int hash_size = 0;
  if (hash_count > 0)
  {
    hash_size = hashs[0]->OutputSize;
    VERIFY(hash_size >= HASH_INPUT_SIZE, "Bad pseudorandom hash size!");
    for (int i = 1; i < hash_count; ++i)
      VERIFY((int)hashs[i]->OutputSize == hash_size,
             "Mismatched pseudorandom hash sizes!");
  }

  ClearMemory(&PseudorandomCtx, sizeof(PseudorandomCtx));
  PseudorandomCtx.HashAlgos = hashs;
  PseudorandomCtx.HashAlgoCount = hash_count;
  PseudorandomCtx.PrngAlgos = prngs;
  PseudorandomCtx.PrngAlgoCount = prng_count;
  PseudorandomCtx.HashStream.Size = hash_size;
  PseudorandomCtx.HashStream.Index = PseudorandomCtx.HashStream.Size;
  PseudorandomCtx.HashStream.Refresh = GeneratePseudorandomHashStream;
  PseudorandomCtx.HashIndex = 0;
  PseudorandomCtx.HashExtAlgo = key_hash;

  uint8_t hash[MAX_HASH_SIZE];
  ClearMemory(hash, sizeof(hash));

  if (hash_count > 0)
  {
    PseudorandomCtx.HashAlgos[0]->HashFunc(key, key_len, hash);
    for (int i = 1; i < hash_count; ++i)
    {
      PseudorandomCtx.HashAlgos[i]->HashFunc(
        hash, hash_size,
        hash);  // chained ==> permutation when bruteforced
    }
    memcpy(PseudorandomCtx.HashKey, hash, sizeof(PseudorandomCtx.HashKey));

    const uint8_t ExtendKey[] = {0x12};
    key_hash->InitFunc();
    key_hash->UpdateFunc(ExtendKey, sizeof(ExtendKey));
    key_hash->UpdateFunc(hash, hash_size);
    key_hash->UpdateFunc(ExtendKey, sizeof(ExtendKey));
    key_hash->FinalFunc(hash);
    memcpy(PseudorandomCtx.HashExt, hash, sizeof(PseudorandomCtx.HashExt));
  }

  if (prng_count > 0)
  {
    const uint8_t ExtendKey[] = {0xCD, 0xEF};
    key_hash->InitFunc();
    key_hash->UpdateFunc(ExtendKey, sizeof(ExtendKey));
    key_hash->UpdateFunc(key, key_len);
    key_hash->UpdateFunc(ExtendKey, sizeof(ExtendKey));
    key_hash->FinalFunc(hash);
    key_hash->HashFunc(hash, key_hash->OutputSize, hash);

    for (int i = 0; i < PseudorandomCtx.PrngAlgoCount; ++i)
    {
      PseudorandomCtx.PrngAlgos[i]->InitFunc(hash, key_hash->OutputSize);
      key_hash->HashFunc(hash, key_hash->OutputSize,
                         hash);  // permutation when bruteforced; repitition OK
    }
  }

  ClearMemory(hash, sizeof(hash));

  PseudorandomInitialized = TRUE;
}

void PseudorandomDeinit(void)
{
  for (int i = 0; i < PseudorandomCtx.PrngAlgoCount; ++i)
  {
    PseudorandomCtx.PrngAlgos[i]->DeinitFunc();
  }

  ClearMemory(&PseudorandomCtx, sizeof(PseudorandomCtx));
  PseudorandomCtx.HashStream.Index = PSEUDORANDOM_BUFFER_SIZE;

  PseudorandomInitialized = FALSE;
}

uint8_t Pseudorandom8(void)
{
  uint8_t r = Extract8(&PseudorandomCtx.HashStream);
  for (int i = 0; i < PseudorandomCtx.PrngAlgoCount; ++i)
  {
    r ^= PseudorandomCtx.PrngAlgos[i]->GetUint8Func();
  }
  return r;
}

uint16_t Pseudorandom16(void)
{
  uint16_t r = Extract16(&PseudorandomCtx.HashStream);
  for (int i = 0; i < PseudorandomCtx.PrngAlgoCount; ++i)
  {
    r ^= PseudorandomCtx.PrngAlgos[i]->GetUint16Func();
  }
  return r;
}

uint32_t Pseudorandom32(void)
{
  uint32_t r = Extract32(&PseudorandomCtx.HashStream);
  for (int i = 0; i < PseudorandomCtx.PrngAlgoCount; ++i)
  {
    r ^= PseudorandomCtx.PrngAlgos[i]->GetUint32Func();
  }
  return r;
}

uint64_t Pseudorandom64(void)
{
  uint64_t r = Extract64(&PseudorandomCtx.HashStream);
  for (int i = 0; i < PseudorandomCtx.PrngAlgoCount; ++i)
  {
    r ^= PseudorandomCtx.PrngAlgos[i]->GetUint64Func();
  }
  return r;
}

void PseudorandomBuffer(uint8_t* buffer, size_t size)
{
  if (!buffer || size <= 0)
    return;
  ExtractToBuffer(&PseudorandomCtx.HashStream, buffer, size);
  for (int i = 0; i < PseudorandomCtx.PrngAlgoCount; ++i)
  {
    PseudorandomCtx.PrngAlgos[i]->XorBufferFunc(buffer, size);
  }
}

uint8_t UnbiasedPseudorandom8(uint8_t ceiling)
{
  return Unbiased8(Pseudorandom8, ceiling);
}

uint16_t UnbiasedPseudorandom16(uint16_t ceiling)
{
  return Unbiased16(Pseudorandom16, ceiling);
}

uint32_t UnbiasedPseudorandom32(uint32_t ceiling)
{
  return Unbiased32(Pseudorandom32, ceiling);
}

uint64_t UnbiasedPseudorandom64(uint64_t ceiling)
{
  return Unbiased64(Pseudorandom64, ceiling);
}
