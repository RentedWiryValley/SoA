#pragma once

#include "basic_prng.h"

void Xoroshiro512ppInit(const uint8_t* key, int key_len);
void Xoroshiro512ppDeinit(void);
uint8_t Xoroshiro512ppRand8(void);
uint16_t Xoroshiro512ppRand16(void);
uint32_t Xoroshiro512ppRand32(void);
uint64_t Xoroshiro512ppRand64(void);
void Xoroshiro512ppRandBuffer(uint8_t* buffer, int size);
void Xoroshiro512ppRandXorBuffer(uint8_t* buffer, int size);
