#pragma once

#include "basics.h"

long GetTime();
void DisplayText(const char* text);
void DisplayPercentage(const char* title, float percent);
void ByteArrayToHexString(const uint8_t* array, int length, char* string);
