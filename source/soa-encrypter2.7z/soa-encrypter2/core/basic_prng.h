#pragma once

#include "basics.h"

typedef void (*PrngInitFunc)(const uint8_t* key, int key_len);
typedef void (*PrngDeinitFunc)(void);
typedef void (*PrngBufferFunc)(uint8_t* buffer, int size);
typedef void (*PrngXorBufferFunc)(uint8_t* buffer, int size);

typedef struct _PrngAlgo
{
  PrngInitFunc InitFunc;
  PrngDeinitFunc DeinitFunc;
  GetUint8Func GetUint8Func;
  GetUint16Func GetUint16Func;
  GetUint32Func GetUint32Func;
  GetUint64Func GetUint64Func;
  PrngBufferFunc BufferFunc;
  PrngXorBufferFunc XorBufferFunc;
} PrngAlgo;
