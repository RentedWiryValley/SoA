#pragma once

#include "basic_prng.h"

void Xoroshiro256ssInit(const uint8_t* key, int key_len);
void Xoroshiro256ssDeinit(void);
uint8_t Xoroshiro256ssRand8(void);
uint16_t Xoroshiro256ssRand16(void);
uint32_t Xoroshiro256ssRand32(void);
uint64_t Xoroshiro256ssRand64(void);
void Xoroshiro256ssRandBuffer(uint8_t* buffer, int size);
void Xoroshiro256ssRandXorBuffer(uint8_t* buffer, int size);
