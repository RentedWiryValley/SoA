#include "debugging.h"

BOOL bVerifyEncryption = FALSE;

uint8_t debugDecryptionOutput[MAX_FILE_DECRYPTION_OUT_SIZE];
