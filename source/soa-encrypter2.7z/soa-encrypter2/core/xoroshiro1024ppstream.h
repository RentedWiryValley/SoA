#pragma once

#include "basic_prng.h"

void Xoroshiro1024ppInit(const uint8_t* key, int key_len);
void Xoroshiro1024ppDeinit(void);
uint8_t Xoroshiro1024ppRand8(void);
uint16_t Xoroshiro1024ppRand16(void);
uint32_t Xoroshiro1024ppRand32(void);
uint64_t Xoroshiro1024ppRand64(void);
void Xoroshiro1024ppRandBuffer(uint8_t* buffer, int size);
void Xoroshiro1024ppRandXorBuffer(uint8_t* buffer, int size);
